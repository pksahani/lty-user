import { Component, OnInit } from '@angular/core';
import { AutologoutService } from 'src/app/_services/autologout.service';
@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  constructor(private autologout: AutologoutService){}
  ngOnInit() {
    
}


}
