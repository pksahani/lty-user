import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { AngularFireDatabase, AngularFireObject } from '@angular/fire/compat/database';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { v4 as uuidv4 } from 'uuid';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  currentUser: any;
  fdbFromUserId: any;
  fdbToUserId: any;
  conversationNgObj: AngularFireObject<any>;
  userNgObj: AngularFireObject<any>;
  messageList: any;
  PartnerDetail: any=[];
  _getAccount: any;
  chatForm = new FormGroup({
    message: new FormControl('', [
      Validators.required
    ])
  });
  PLastMessageData: any=[];
  usersList: string[];
  fdbToAgentId: any;
  AgentDetail: any=[];
  ALastMessageData: any;
  @ViewChild('chatBox') private chatBox!: ElementRef;
  showPartnerBox: boolean=true;
  showAgentBox: boolean=false;
  userArray: any;
  partneris: boolean=false;
  agentis: boolean=false;
  CurrentChatUser: any=[];
  NonChatuserArray: any=[];
constructor(private angularFireDatabase: AngularFireDatabase, private userAuthService:UserAuthService ){

}
 async ngOnInit() {
  //this.getCurrentUser();
 // this.getConversations();
  //this.getUserIdByEmailFromFirebase();
   // this.getChat();
  this.currentUser = await this.GetProfileDetail();
 // this.currentUser=JSON.parse(this.currentUser);
  this.getMyConversations(this.currentUser.userId);

  
  }

 

  GetProfileDetail(): any {
    return new Promise((resolve, reject) => { 
    this._getAccount = this.userAuthService.getuserDByToken().subscribe({
      next: (x: any) => {
       let res=x.data;
	// console.log(res);
   this.currentUser=res;
   return resolve(res);
      },
      error: (err: Error) => {
        return reject(err);

      },
      complete: () => {
        
      },
    });
  });
console.log("hello");

   
     
   
  }

  showPartnerChat(user:any){
    //console.log(PartnerId);
    this.CurrentChatUser=user;
    console.log(this.CurrentChatUser);
    this.getChat(this.CurrentChatUser.location);
  }

  showAgentChat(conversationId:any){
    this.showPartnerBox=false;
    this.showAgentBox=true;
    this.getChat(conversationId);
  }

  getChat(conversationId:any){
   if(conversationId!=''){
    this.getMessagesFromFDBByLocation(conversationId);
   } else {
    this.messageList=[];
   }
      
      
  }


  



  getMessagesFromFDBByLocation(location: string) {
    
    this.angularFireDatabase.list("conversations", ref => ref.child(location)).valueChanges(["child_added", "child_changed", "child_moved", "child_removed"]).subscribe((snapshot: any) => {
      let tmpSnapshot: any = snapshot;
      

      console.log(tmpSnapshot);
      if(this.CurrentChatUser.location==location){
      this.messageList = tmpSnapshot;
 }
      setTimeout(() => {
        //this.messageScrollContainer.nativeElement.scrolltop = this.messageScrollContainer.nativeElement.scrollHeight;
        this.chatBox.nativeElement.scrollTo(0, this.chatBox.nativeElement.scrollHeight);
      }, 0);
    });
   
  }

  async sendMessageAction(CurrentChatUser:any) {
console.log(CurrentChatUser);

    let conversationId: string = '';
    let ToUserId: string = CurrentChatUser.ID;
    let FromUserId: string = this.currentUser.userId;
    let conversation: any = {};
    let conversations: any = {};

    let currentTimeInSeconds = Math.floor(Date.now() / 1000); //unix timestamp in seconds
    let currentTimeInMilliseconds = Date.now().toString(); // unix timestamp in milliseconds

   let existsFag: boolean = true;
      if (CurrentChatUser.location!='') {
        //console.log('value exists');
        //console.log(snapshot.val());
        conversationId = CurrentChatUser.location;
        existsFag = true;
      } else {
        let userData= await this.getUserIdByEncryptedIdFromFirebasePromise(CurrentChatUser.ID);
        this.angularFireDatabase.list("Users").update(CurrentChatUser.ID, {
          name: CurrentChatUser.name,
          type:CurrentChatUser.type
        }).then(() => {
         // window.location.href = "/user";
        }).catch(() => {
          //this.toastrService.error("Firebase error occured.");
         // window.location.href = "/user";
        });

        if(userData){
          this.CurrentChatUser.fcmKey=userData.fcmKey?userData.fcmKey:'';
        }
        //console.log("No data available");
        conversationId = uuidv4();
        this.CurrentChatUser.location=conversationId;
        existsFag = false;
      }

      conversation = {
        location: conversationId,
        lastMessage: this.chatForm.getRawValue().message,
        timestamp: currentTimeInMilliseconds,
        // metaData: {
        //   user: {
        //     name: this.currentUser.name
        //   },
        //   partner: {
        //     name: this.PartnerDetail.name
        //   }
        // }
      };

      conversations = {
        content: this.chatForm.getRawValue().message,
        fromID: FromUserId,
        isRead: false,
        timestamp: currentTimeInMilliseconds,
        toID: ToUserId,
        type: "text",
      };

      console.log(conversations);

      this.angularFireDatabase.list("Users", (ref: any) => ref.child(FromUserId).child('conversations').child(ToUserId).update(conversation));
      this.angularFireDatabase.list("Users", (ref: any) => ref.child(ToUserId).child('conversations').child(FromUserId).update(conversation));
      this.angularFireDatabase.list("conversations", (ref: any) => ref.child(conversationId).push().update(conversations));

      this.chatForm.reset();
      if (!existsFag) {
        console.log('raghabbbbb');
        this.getMessagesFromFDBByLocation(conversationId);
      }
console.log(this.CurrentChatUser);
      if (this.CurrentChatUser.fcmKey != null && this.CurrentChatUser.fcmKey != "") {
        this.sendPushNotification({
          message: this.chatForm.getRawValue().message,
          fcmKeys: [this.CurrentChatUser.fcmKey]
        });
      }


  }

  sendPushNotification(obj: any): void {

    if (!obj) {
      return;
    }

    if (!Array.isArray(obj.fcmKeys)) {
      return;
    }

    let notificationData: any = {
      registration_ids: obj.fcmKeys,
      notification: {
        title: this.currentUser.firstName+' '+this.currentUser.lastName + " has sent you a new message",
        body: obj.message,
        sound: "default",
      },
      data: {
        icon: "app_icon",
        body: obj.message,
        title: this.currentUser.firstName+' '+this.currentUser.lastName + " has sent you a new message",
      },
      priority: "high"
    };
    console.log(notificationData);

    this.userAuthService.sendPushNotification(notificationData).subscribe({
      next: (x: any) => {
        let res: any = x;
        console.log('gyi');
      },
      error: (err: Error) => {
        console.log('nhi gyi');
      },
      complete: () => {

      },
    });
  }

  async getMyConversations(currentUserId:any) {
   
    this.angularFireDatabase.list("Users", ref => ref.child(currentUserId).child("conversations").orderByChild("timestamp")).snapshotChanges(["child_added", "child_changed", "child_moved", "child_removed"]).subscribe(async (snapshot: any) => {
    this.userArray= snapshot.reverse();
   // console.log(this.userArray);
    if(this.userArray.length>0){
      //console.log(this.userArray.val());

       for(let i=0; i<this.userArray.length;i++){
       // console.log(this.userArray[i].payload?.val());
     let userinfo= await this.getUserIdByEncryptedIdFromFirebasePromise(this.userArray[i].key);
     console.log(userinfo);
        this.userArray[i]['ID']=this.userArray[i].key;
        this.userArray[i]['lastMessage']=this.userArray[i]?.payload?.val().lastMessage?this.userArray[i].payload.val().lastMessage:'';
        this.userArray[i]['timestamp']=this.userArray[i].payload?.val().timestamp;
        this.userArray[i]['location']=this.userArray[i].payload?.val().location;
          this.userArray[i]['name']=userinfo.name?userinfo.name:'';
          this.userArray[i]['pic']=userinfo.pic?userinfo.pic:'';
          this.userArray[i]['type']=userinfo.type?userinfo.type:'';
          this.userArray[i]['fcmKey']=userinfo.fcmKey?userinfo.fcmKey:'';
        // }
        // if(this.fdbToAgentId ==this.userArray[i].key){
        //   this.agentis=true;
        //   this.userArray[i]['name']=this.AgentDetail.name?this.AgentDetail.name:this.currentUser.agentName;
        //   this.userArray[i]['pic']=this.AgentDetail.pic?this.AgentDetail.pic:'';
        //   this.userArray[i]['type']='AGENT';

        // }
       }
      } 
        //console.log(this.currentUser);
        let partnerData={
          ID:this.currentUser.partnerId,
          key:this.currentUser.partnerId,
          lastMessage:'',
          timestamp:'',
          location:'',
          name:this.currentUser.partnerName,
          pic:'',
          type:'PARTNER',
          fcmKey:'',
        }
        let agentData={
          ID:this.currentUser.agentId,
          key:this.currentUser.agentId,
          lastMessage:'',
          timestamp:'',
          location:'',
          name:this.currentUser.agentName,
          pic:'',
          type:'AGENT',
          fcmKey:'',
        }
        let Nonchatragh=[];
        this.NonChatuserArray=[];
        if(this.currentUser.partnerId!='' && this.currentUser.partnerId!=null){
        Nonchatragh.push(partnerData);
        }
        if(this.currentUser.agentId!='' && this.currentUser.agentId!=null){
        Nonchatragh.push(agentData);
      }
        //console.log(Nonchatragh[0].ID);
       for(let i=0; i<Nonchatragh.length;i++){
      const getUserData = this.userArray.find(
     // console.log()
        (element: any) => element.key == Nonchatragh[i].ID
      ) 
      if(!getUserData){
        this.NonChatuserArray.push(Nonchatragh[i]);
      }
    
       } 
    
  //      if(this.agentis==false){
  //  let userObj = {
  //         ID:this.currentUser.agentId,
  //         key:this.currentUser.agentId,
  //         name:this.currentUser.agentName,
  //         lastMessage:'',
  //         timestamp:'',
  //         location:'',
  //         email:'',
  //         pic:'',
  //         type:'AGENT'
  //       }
  //       this.userArray.push(userObj);
  //     }
console.log(this.userArray);

    
    });
  }

  getUserIdByEncryptedIdFromFirebasePromise(encryptedId: string): Promise<any> {
    //console.log(encryptedId);
    return new Promise((resolve, reject) => {
      this.angularFireDatabase.list("Users", (ref: any) => ref.child(encryptedId).once('value', (snapshot: any) => {
        if (snapshot.exists()) {
          //console.log(snapshot.key);
          //return resolve(Object.keys(snapshot.val())[0]);
          return resolve(snapshot.val());
        }
      }, (error: any) => {
        return reject(error);
      }));
    });
  }

}
