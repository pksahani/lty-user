import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule, NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';

import { GeneralOfferRoutingModule } from './general-offer-routing.module';
import { ListComponent } from './list/list.component';
import { ViewComponent } from './view/view.component';
//import { ListComponent } from './list/list.component';


@NgModule({
  declarations: [
    ListComponent,
    ViewComponent
  ],
  imports: [
    CommonModule,
    GeneralOfferRoutingModule,
    NgbModule,
    NgbAccordionModule 
  ]
})
export class GeneralOfferModule { }
