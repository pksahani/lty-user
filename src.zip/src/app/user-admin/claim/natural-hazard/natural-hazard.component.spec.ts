import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NaturalHazardComponent } from './natural-hazard.component';

describe('NaturalHazardComponent', () => {
  let component: NaturalHazardComponent;
  let fixture: ComponentFixture<NaturalHazardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NaturalHazardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NaturalHazardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
