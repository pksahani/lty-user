import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateFireComponent } from './corporate-fire.component';

describe('CorporateFireComponent', () => {
  let component: CorporateFireComponent;
  let fixture: ComponentFixture<CorporateFireComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateFireComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateFireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
