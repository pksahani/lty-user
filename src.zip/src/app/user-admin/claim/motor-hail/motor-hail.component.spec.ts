import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorHailComponent } from './motor-hail.component';

describe('MotorHailComponent', () => {
  let component: MotorHailComponent;
  let fixture: ComponentFixture<MotorHailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorHailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MotorHailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
