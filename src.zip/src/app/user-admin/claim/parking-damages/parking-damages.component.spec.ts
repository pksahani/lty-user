import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkingDamagesComponent } from './parking-damages.component';

describe('ParkingDamagesComponent', () => {
  let component: ParkingDamagesComponent;
  let fixture: ComponentFixture<ParkingDamagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParkingDamagesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ParkingDamagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
