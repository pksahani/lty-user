import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GlassBreakageComponent } from './glass-breakage.component';

describe('GlassBreakageComponent', () => {
  let component: GlassBreakageComponent;
  let fixture: ComponentFixture<GlassBreakageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GlassBreakageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GlassBreakageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
