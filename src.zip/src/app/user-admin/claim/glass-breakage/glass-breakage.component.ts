import { Component, OnInit, ViewChild } from '@angular/core';
import {FormControl, Validators, FormGroup, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-glass-breakage',
  templateUrl: './glass-breakage.component.html',
  styleUrls: ['./glass-breakage.component.css']
})
export class GlassBreakageComponent implements OnInit {

  ngOnInit():void{
    window.scroll(0, 0);
  }

  active = 'top';
  mmtOptions:any;
  mmtBrokerOptions:any;
  policeReportOptions:any;
  vehicleDetailsR:any;
  tipOption:any;
  otherDamageName:any;
  options:any='';
  options1:any='';


  glassTypeForm = this._formBuilder.group({
    glassType:'',
  });

  PolicyholderForm = this._formBuilder.group({
    mmtOptions:'',
    policyHolderSdate:'',
    policyHolderStime:''
  });

  reportedBy = this._formBuilder.group({
    mmtBrokerOptions:'',
  });

  incidentForm = this._formBuilder.group({
    incidentDate:'',
    incidentTime:'',
  });

  addressForm = this._formBuilder.group({
    whereAddress:''
  });

  howFormG = this._formBuilder.group({
    howGTextarea:''
  });

  vehicleDetails = this._formBuilder.group({
    VdVehicleType:'',
    Vdmake:'',
    VdModel:'',
    VdLicencePlate:'',
    VdmoreDetail:'',
  });

  keeperVehicleForm = this._formBuilder.group({
  });

  reporterContactForm = this._formBuilder.group({
    repoterContactName:'',
    reporterFirstName:'',
    reporterLastName:'',
    reporterEmail:'',
    reporterPhone:'',
    reporterAddress:'',
    reporterCompany:'',
    reporterContactMethod:'',
    reporterDob:'',
  });

  reporterAddressForm = this._formBuilder.group({
    reporterAddressText:''
  });

  policyNumberForm = this._formBuilder.group({
    policyNumber:''
  });

  policyHolderContactForm = this._formBuilder.group({
    policyHolderContactName:'',
    policyHolderFirstName:'',
    policyHolderLastName:'',
    policyHolderDateBirth:'',
    policyHolderEmail:'',
    policyHolderPhone:'',
    policyHolderAddress:'',
  });

  docAttachment = this._formBuilder.group({
    docAttachmentFile:'',
    docAttachmentFile1:'',
    docAttachmentFile2:'',
    docAttachmentFile3:'',
    docAttachmentSelect1:'',
    docAttachmentSelect2:'',
    docAttachmentSelect3:'',
  });

  fixedGlassForm = this._formBuilder.group({
  });

  contactMethodForm = this._formBuilder.group({
    contactMethodName:'',
  });

  partnerContactForm = this._formBuilder.group({
    partnerContactName:'',
  });

  partnerInfoContactForm = this._formBuilder.group({
    partnerInfoName:'',
    partnerInfoFName:'',
    partnerInfoLName:'',
    partnerInfoEmail:'',
    partnerInfoPhone:'',
    partnerInfoOption:'',
    partnerCompany:'',
  });

  helpPointAppointmentForm = this._formBuilder.group({
    policyHolderAddress:'',
  });

  bookAppointmentForm = this._formBuilder.group({
    bookAppointmentLocation:'',
    bookAppointmentDate:'',
    bookAppointmentTime:'',
  });

  withoutAppointmentForm = this._formBuilder.group({
    withoutAppointmentFormRadio:'',
    wafCompanyName:'',
    wafEmail:'',
    stfPhone:'',
    garageAddressText:''
  });


  isOptional = false;

  checked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;


  @ViewChild('stepper') stepper:any;

  constructor(private _formBuilder: FormBuilder) {}

  showMyContainer: boolean = false;

  move(index: number) {
    this.stepper.selectedIndex = index;
  }

  selectionChange(event: any) {
    console.log(event.selectedStep.label);
    let stepLabel = event.selectedStep.label;
    if (stepLabel == "Step 0") {
      console.log("CLICKED STEP 0");
      this.stepper.selectedIndex = 4;
    }

  }

}
