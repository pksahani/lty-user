import { Component, ViewChild, OnInit } from '@angular/core';
import {FormControl, Validators, FormGroup, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-collision',
  templateUrl: './collision.component.html',
  styleUrls: ['./collision.component.css']
})
export class CollisionComponent implements OnInit {

  ngOnInit():void{
    window.scroll(0, 0);
  }

  active = 'top';
  mmtOptions:any;
  mmtBrokerOptions:any;
  policeReportOptions:any;
  vehicleDetailsR:any;
  tipOption:any;
  otherDamageName:any;
  options:any='';
  options1:any='';


  PolicyholderForm = this._formBuilder.group({
    mmtOptions:'',
    policyHolderSdate:'',
    policyHolderStime:''
  });

  reportedBy = this._formBuilder.group({
    mmtBrokerOptions:'',
    whenSelectDate:'',
    whenSelectTime:'',
    whenSelectDateOne:'',
    whenSelectDateTwo:'',
    whenSelectDateThree:'',
    whenSelectDateFour:'',
  });

  disclaimerFormGroup = this._formBuilder.group({
    disclaimerContent:''
  });

 incidentForm = this._formBuilder.group({
    mmtOptions:'',
    incidentFormDate:'',
    incidentFormTime:''
  });

  addressForm = this._formBuilder.group({
    whereAddress:''
  });

  howFormG = this._formBuilder.group({
    howGTextarea:''
  });

  driverForm = this._formBuilder.group({
    driverType:''
  });

  driverContactFrom = this._formBuilder.group({
    driverContact:'',
    driverFirstName:'',
    driverLastName:'',
    driverDob:'',
  });

  policeReport = this._formBuilder.group({
    policeReport_R:''
  });

  vehicleDetails = this._formBuilder.group({
    vehicleDetailsR:'',
    VdVehicleType:'',
    Vdmake:'',
    VdModel:'',
    VdLicencePlate:'',
    VdmoreDetail:'',
  });

  keeperVehiclesForm = this._formBuilder.group({

  });

  driverTwoForm = this._formBuilder.group({
    whoDriveName:''
  });

  driverContactTwoB = this._formBuilder.group({

  });

  treatInjuredPerson = this._formBuilder.group({
    tipOption:'',
    treatInjured1PersonText:'',
  });


  treatInjured1Person = this._formBuilder.group({
    tipOption:'',
    treatInjured1PersonText:''
  });

  otherDamage = this._formBuilder.group({
    otherDamageNameone:'',
    otherDamageNametwo:'',
    otherDamageNamethree:'',
    otherDamageNamefour:'',
  });

  damageItemFrom = this._formBuilder.group({
    damageItemDescribe:''
  });

  thirdPartyVehicleDetails = this._formBuilder.group({
    thirdPartyVehicleMake:'',
    thirdPartyVehicleModel:'',
    thirdPartyVehicleLicence:'',
    thirdPartyVehicleTextarea:'',
  });

  otherDriveContact = this._formBuilder.group({
    otherDContact:'',
    otherDContactFName:'',
    otherDContactLName:'',
    otherDContactDateBirth:'',
    otherDContactEmail:'',
    otherDContactPhone:''
  });

  otherPersonContactD = this._formBuilder.group({
    otherPersonC:'',
    otherPersonCFname:'',
    otherPersonCLname:'',
    otherPersonCEmail:'',
    otherPersonCPhone:'',
  });

  otherPersonTreatment = this._formBuilder.group({
  });

  thirdPartyInjury = this._formBuilder.group({
    thirdPartyInjuryText:'',
  });

  animalForm = this._formBuilder.group({
    animalFormText:'',
  });

  animalOwnerContactForm = this._formBuilder.group({
    animalOwnerContact:'',
    animalOwnerFName:'',
    animalOwnerLName:'',
    animalOwnerEmail:'',
    animalOwnerPhone:'',
    animalCompanyLName:'',
  });

  buildingForm = this._formBuilder.group({
    buildingTextarea:'',
  });

  buildingOwnerContactForm = this._formBuilder.group({
    buildingOwnerRadio:'',
    buildingOwnerFName:'',
    buildingOwnerLName:'',
    buildingOwnerEmail:'',
    buildingOwnerPhone:'',
  });

  reporterContactForm = this._formBuilder.group({
    repoterContactName:'',
    reporterFirstName:'',
    reporterLastName:'',
    reporterEmail:'',
    reporterPhone:'',
    reporterAddress:'',
    reporterCompany:'',
    reporterContactMethod:'',
  });

  reporterAddressForm = this._formBuilder.group({
    reporterAddress:''
  });

  policyNumberForm = this._formBuilder.group({
    policyNumber:''
  });

  licencePlate = this._formBuilder.group({
    licencePlate:''
  });

  policyHolderContactForm = this._formBuilder.group({
    policyHolderContactName:'',
    policyHolderFirstName:'',
    policyHolderLastName:'',
    policyHolderDateBirth:'',
    policyHolderEmail:'',
    policyHolderPhone:'',
    policyHolderAddress:'',
  });

  policyHolderAddressForm = this._formBuilder.group({
    policyHolderAddress:'',
  });

  docAttachment = this._formBuilder.group({
    docAttachmentFile:'',
    docAttachmentFile1:'',
    docAttachmentFile2:'',
    docAttachmentFile3:'',
    docAttachmentSelect1:'',
    docAttachmentSelect2:'',
    docAttachmentSelect3:'',
  });

  helpPointAppointmentForm = this._formBuilder.group({
  });

  bookAppointmentForm = this._formBuilder.group({
    bookAppointmentLocation:'',
    bookAppointmentDate:'',
    bookAppointmentTime:'',
  });

  bookAppointmentComfirmForm = this._formBuilder.group({
  });

  withoutAppointmentForm = this._formBuilder.group({
    withoutAppointmentFormRadio:'',
    wafCompanyName:'',
    wafEmail:'',
    stfPhone:'',
    wafAddress:'',
  });

  garageAddressForm = this._formBuilder.group({
    garageAddressText:''
  });

  finalSubmitForm = this._formBuilder.group({
  });





  isOptional = false;

  checked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;


  @ViewChild('stepper') stepper:any;

  constructor(private _formBuilder: FormBuilder) {}

  // showYesPoliceReport(){
  //   var a =  document.getElementById('policeReportContainer') as HTMLElement
  //   a.style.display = 'block';
  //   // var b =  document.getElementById('claimTravelRoadsideContainer')  as HTMLElement;
  //   // b.style.display = 'none';
  // }

  showMyContainer: boolean = false;

  move(index: number) {
    this.stepper.selectedIndex = index;
  }

  selectionChange(event: any) {
    console.log(event.selectedStep.label);
    let stepLabel = event.selectedStep.label;
    if (stepLabel == "Step 0") {
      console.log("CLICKED STEP 0");
      this.stepper.selectedIndex = 4;
    }

  }


}

