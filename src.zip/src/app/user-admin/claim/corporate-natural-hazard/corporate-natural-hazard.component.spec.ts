import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateNaturalHazardComponent } from './corporate-natural-hazard.component';

describe('CorporateNaturalHazardComponent', () => {
  let component: CorporateNaturalHazardComponent;
  let fixture: ComponentFixture<CorporateNaturalHazardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateNaturalHazardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateNaturalHazardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
