import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateParkingDamagesComponent } from './corporate-parking-damages.component';

describe('ParkingDamagesComponent', () => {
  let component: CorporateParkingDamagesComponent;
  let fixture: ComponentFixture<CorporateParkingDamagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateParkingDamagesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateParkingDamagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
