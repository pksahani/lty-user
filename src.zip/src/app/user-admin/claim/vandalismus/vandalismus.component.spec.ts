import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VandalismusComponent } from './vandalismus.component';

describe('VandalismusComponent', () => {
  let component: VandalismusComponent;
  let fixture: ComponentFixture<VandalismusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VandalismusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VandalismusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
