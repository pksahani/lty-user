import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClaimComponent } from './claim/claim.component';
import { CollisionComponent } from './collision/collision.component';
import { MotorHailComponent } from './motor-hail/motor-hail.component';
import { GlassBreakageComponent } from './glass-breakage/glass-breakage.component';
import { ParkingDamagesComponent } from './parking-damages/parking-damages.component';
import { MartenComponent } from './marten/marten.component';
import { TheftComponent } from './theft/theft.component';
import { VandalismusComponent } from './vandalismus/vandalismus.component';
import { FireComponent } from './fire/fire.component';
import { CollisionAnimalsComponent } from './collision-animals/collision-animals.component';
import { NaturalHazardComponent } from './natural-hazard/natural-hazard.component';
import { BreakdownComponent } from './breakdown/breakdown.component';
import { CompanyCarCollisionComponent } from './company-car-collision/company-car-collision.component';
import { CorporateHailComponent } from './corporate-hail/corporate-hail.component';
import { CorporateGlassBreakageComponent } from './corporate-glass-breakage/corporate-glass-breakage.component';
import { CorporateParkingDamagesComponent } from './corporate-parking-damages/corporate-parking-damages.component';
import { CorporateMartenComponent } from './corporate-marten/corporate-marten.component';
import { CorporateTheftComponent } from './corporate-theft/corporate-theft.component';
import { CorporateFireComponent } from './corporate-fire/corporate-fire.component';
import { CorporateVandalismusComponent } from './corporate-vandalismus/corporate-vandalismus.component';
import { CorporateNaturalHazardComponent } from './corporate-natural-hazard/corporate-natural-hazard.component';
import { CorporateCollisionAnimalsComponent } from './corporate-collision-animals/corporate-collision-animals.component';

const routes: Routes = [
  {
    path: '',
    component: ClaimComponent
  },
  {
    path: 'claim',
    component: ClaimComponent
  },
  {
    path: 'collision',
    component: CollisionComponent
  },
  {
    path: 'motor-hail',
    component: MotorHailComponent
  },
  {
    path: 'glass-breakage',
    component: GlassBreakageComponent
  },
  {
    path: 'parking-damages',
    component: ParkingDamagesComponent
  },
  {
    path: 'marten',
    component: MartenComponent
  },
  {
    path: 'theft',
    component: TheftComponent
  },
  {
    path: 'vandalismus',
    component: VandalismusComponent
  },
  {
    path: 'fire',
    component: FireComponent
  },
  {
    path: 'collision-animals',
    component: CollisionAnimalsComponent
  },
  {
    path: 'natural-hazard',
    component: NaturalHazardComponent
  },
  {
    path: 'breakdown',
    component: BreakdownComponent
  },
  {
    path: 'company-car-collision',
    component: CompanyCarCollisionComponent
  },
  {
    path: 'corporate-hail',
    component: CorporateHailComponent
  },
  {
    path: 'corporate-hail',
    component: CorporateHailComponent
  },
  {
    path: 'corporate-glass-breakage',
    component: CorporateGlassBreakageComponent
  },
  {
    path: 'corporate-parking-damage',
    component: CorporateParkingDamagesComponent
  },
  {
    path: 'corporate-marten',
    component: CorporateMartenComponent
  },
  {
    path: 'corporate-theft',
    component: CorporateTheftComponent
  },
  {
    path: 'corporate-fire',
    component: CorporateFireComponent
  },
  {
    path: 'corporate-vandalismus',
    component: CorporateVandalismusComponent
  },
  {
    path: 'corporate-natural-hazard',
    component: CorporateNaturalHazardComponent
  },
  {
    path: 'corporate-collision-animal',
    component: CorporateCollisionAnimalsComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClaimRoutingModule { }
