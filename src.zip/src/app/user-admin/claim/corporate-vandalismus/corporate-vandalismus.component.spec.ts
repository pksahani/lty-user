import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateVandalismusComponent } from './corporate-vandalismus.component';

describe('CorporateVandalismusComponent', () => {
  let component: CorporateVandalismusComponent;
  let fixture: ComponentFixture<CorporateVandalismusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateVandalismusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateVandalismusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
