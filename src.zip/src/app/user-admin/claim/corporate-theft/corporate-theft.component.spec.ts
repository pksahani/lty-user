import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateTheftComponent } from './corporate-theft.component';

describe('CorporateTheftComponent', () => {
  let component: CorporateTheftComponent;
  let fixture: ComponentFixture<CorporateTheftComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateTheftComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateTheftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
