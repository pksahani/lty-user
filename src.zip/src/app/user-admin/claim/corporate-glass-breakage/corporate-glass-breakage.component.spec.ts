import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateGlassBreakageComponent } from './corporate-glass-breakage.component';

describe('GlassBreakageComponent', () => {
  let component: CorporateGlassBreakageComponent;
  let fixture: ComponentFixture<CorporateGlassBreakageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateGlassBreakageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateGlassBreakageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
