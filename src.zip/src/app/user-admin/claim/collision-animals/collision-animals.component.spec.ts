import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CollisionAnimalsComponent } from './collision-animals.component';

describe('CollisionAnimalsComponent', () => {
  let component: CollisionAnimalsComponent;
  let fixture: ComponentFixture<CollisionAnimalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CollisionAnimalsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CollisionAnimalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
