import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CorporateHailComponent } from './corporate-hail.component';

describe('CorporateHailComponent', () => {
  let component: CorporateHailComponent;
  let fixture: ComponentFixture<CorporateHailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateHailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateHailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
