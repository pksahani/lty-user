import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbPaginationModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { NgxOtpInputModule } from "ngx-otp-input";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatStepperModule} from '@angular/material/stepper';
import { MatCheckboxModule} from '@angular/material/checkbox';
//import { NgScrollbarModule } from 'ngx-scrollbar';
import { ClaimRoutingModule } from './claim-routing.module';
//import { ClaimPropertyLiabilityModule } from '../claim-property-liability/claim-property-liability.module';
import { ClaimComponent } from './claim/claim.component';
import { CollisionComponent } from './collision/collision.component';
import { MotorHailComponent } from './motor-hail/motor-hail.component';
import { GlassBreakageComponent } from './glass-breakage/glass-breakage.component';
import { ParkingDamagesComponent } from './parking-damages/parking-damages.component';
import { MartenComponent } from './marten/marten.component';
import { TheftComponent } from './theft/theft.component';
import { VandalismusComponent } from './vandalismus/vandalismus.component';
import { FireComponent } from './fire/fire.component';
import { CollisionAnimalsComponent } from './collision-animals/collision-animals.component';
import { NaturalHazardComponent } from './natural-hazard/natural-hazard.component';
import { BreakdownComponent } from './breakdown/breakdown.component';
import { CompanyCarCollisionComponent } from './company-car-collision/company-car-collision.component';
import { CorporateHailComponent } from './corporate-hail/corporate-hail.component';
import { CorporateGlassBreakageComponent } from './corporate-glass-breakage/corporate-glass-breakage.component';
import { CorporateParkingDamagesComponent } from './corporate-parking-damages/corporate-parking-damages.component';
import { CorporateMartenComponent } from './corporate-marten/corporate-marten.component';
import { CorporateTheftComponent } from './corporate-theft/corporate-theft.component';
import { CorporateFireComponent } from './corporate-fire/corporate-fire.component';
import { CorporateVandalismusComponent } from './corporate-vandalismus/corporate-vandalismus.component';
import { CorporateNaturalHazardComponent } from './corporate-natural-hazard/corporate-natural-hazard.component';
import { CorporateCollisionAnimalsComponent } from './corporate-collision-animals/corporate-collision-animals.component';


@NgModule({
  declarations: [
    ClaimComponent,
    CollisionComponent,
    MotorHailComponent,
    GlassBreakageComponent,
    ParkingDamagesComponent,
    MartenComponent,
    TheftComponent,
    VandalismusComponent,
    FireComponent,
    CollisionAnimalsComponent,
    NaturalHazardComponent,
    BreakdownComponent,
    CompanyCarCollisionComponent,
    CorporateHailComponent,
    CorporateGlassBreakageComponent,
    CorporateParkingDamagesComponent,
    CorporateMartenComponent,
    CorporateTheftComponent,
    CorporateFireComponent,
    CorporateVandalismusComponent,
    CorporateNaturalHazardComponent,
    CorporateCollisionAnimalsComponent
  ],
  imports: [
    CommonModule,
    NgbModule,
    NgbPaginationModule,
    NgbAlertModule,
    NgbTypeaheadModule,
    NgbTypeahead,
    NgxOtpInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatStepperModule,
    MatCheckboxModule,
   // NgScrollbarModule,
    ClaimRoutingModule,
   // ClaimPropertyLiabilityModule
  ],

  exports : [MatStepperModule],

  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]

})
export class ClaimModule { }
