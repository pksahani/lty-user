import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateMartenComponent } from './corporate-marten.component';

describe('CorporateMartenComponent', () => {
  let component: CorporateMartenComponent;
  let fixture: ComponentFixture<CorporateMartenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateMartenComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateMartenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
