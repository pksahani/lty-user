import { Component } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-claim',
  templateUrl: './claim.component.html',
  styleUrls: ['./claim.component.css']
})
export class ClaimComponent {
  PolicyholderForm = this._formBuilder.group({
    // policyHolder: ['']
  });
  reportedBy = this._formBuilder.group({
    incidentDate: '',
    incidentTime: ''
  });
  disclaimerForm = this._formBuilder.group({
    // policyHolder: ['']
  });

  incidentForm = this._formBuilder.group({
    // policyHolder: ['']
  });

  addressForm = this._formBuilder.group({
    // policyHolder: ['']
  });

  howFormG = this._formBuilder.group({
    // policyHolder: ['']
  });

  driverForm = this._formBuilder.group({
    // policyHolder: ['']
  });

  policeReport = this._formBuilder.group({
    // policyHolder: ['']
  });

  vehicleDetails = this._formBuilder.group({
    // policyHolder: ['']
  });


  isOptional = false;

  checked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;

  constructor(private _formBuilder: FormBuilder) {}

  ReadMore:boolean = true

  //hiding info box
  visible:boolean = false;

  options:any='';
  options1:any='';
  options2:any='';

  test:any;

}
