import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyCarCollisionComponent } from './company-car-collision.component';

describe('CompanyCarCollisionComponent', () => {
  let component: CompanyCarCollisionComponent;
  let fixture: ComponentFixture<CompanyCarCollisionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanyCarCollisionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompanyCarCollisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
