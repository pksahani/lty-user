import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateCollisionAnimalsComponent } from './corporate-collision-animals.component';

describe('CorporateCollisionAnimalsComponent', () => {
  let component: CorporateCollisionAnimalsComponent;
  let fixture: ComponentFixture<CorporateCollisionAnimalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateCollisionAnimalsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateCollisionAnimalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
