import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MartenComponent } from './marten.component';

describe('MartenComponent', () => {
  let component: MartenComponent;
  let fixture: ComponentFixture<MartenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MartenComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MartenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
