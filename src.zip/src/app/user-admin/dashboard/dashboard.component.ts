import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/_services/user-auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})

export class DashboardComponent implements OnInit {
  _getDasboard: any;
  _user: any;
  Dashboarddata: any;
  __ProposalList: any;
  proposal_List: any;
  constructor(private userAuthService:UserAuthService){
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    
    }
  }

  ngOnInit(): void {
    this.GetDashboardDetail();
    this.getLeadList();
  }

  GetDashboardDetail(): any {
   
    this._getDasboard = this.userAuthService.getuserDashboardInfo(
      {
        userId: this._user.userId
      }
    ).subscribe({
      next: (x: any) => {
       this.Dashboarddata=x.data;
      
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
       // localStorage.removeItem('user')
       // this.router.navigate(['/signin']);
        //this.logoutErrorMessage = errRes.error.message;
      },
      complete: () => {
        
      },
    });
console.log("hello");

   
     
   
  }

  getLeadList(): void {
    this.__ProposalList = this.userAuthService.getLeadList({
      status:'',
      pageSize:5,
      pageCount:1
    }).subscribe({
     next: (x: any) => {
      this.proposal_List=x.data.leadsList;
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
       console.error(err)
       
     },
     complete: () => {
       //this.registerSubmitted = false;
     },
   });
   
 }

}
