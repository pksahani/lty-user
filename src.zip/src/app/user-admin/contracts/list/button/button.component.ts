import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent implements OnInit {
  params: any;
  content: any;
  delete: any;
  assign: any;
  constructor() { }
  agInit(params: any): void {
    this.params=params;
  }
  refresh(params: ICellRendererParams) {
    return false;
  }
  _changeStatus(params:any,type:any) {
    this.params.context.componentParent._changeStatus(params, type);
  }

  ApproveModal(params:any) {
    console.log("hello");
    this.params.context.componentParent.ApproveModal(params);
  }

  BlockModal(params:any) {
    console.log("hello");
    this.params.context.componentParent.BlockModal(params);
  }
  UnBlockModal(params:any) {
    console.log("hello");
    this.params.context.componentParent.UnBlockModal(params);
  }
  open(content:any, category:any) {
    this.params.context.componentParent.open(content,category);
  }
  ngOnInit(): void {
  }

}
