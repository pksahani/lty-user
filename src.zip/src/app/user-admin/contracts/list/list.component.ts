import { Component, OnInit, ViewChild } from '@angular/core';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { ButtonComponent } from './button/button.component';
import { AgGridAngular} from 'ag-grid-angular';
import {FormControl, Validators, FormGroup, FormBuilder, EmailValidator} from '@angular/forms';
import { CellClickedEvent, ColDef, GridReadyEvent, GridOptions,ValueGetterParams,ValueSetterParams} from 'ag-grid-community';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  __List:any;
  all_List:any;
  paginationPageSize = 10;
  context: any;
  params: any;
  gridOptions: any;
  all_partnerList:any;
  AssignUserId:any;
  modalReference:any;
  closeResult:any;
  gridApi: any;
  searchsource:any='';
  columnDefs = [
		
		{headerName: 'Policy ID', headerCheckboxSelection: true,
    checkboxSelection: true,
    showDisabledCheckboxes: true,
    valueGetter: (params: ValueGetterParams) => {
      return params.data.policyDetails.policyId;
    } },

    {headerName: 'User Name', field:'memberDetails.firstName',
    cellRenderer: (params: ValueGetterParams) => {
      return params.data.memberDetails.firstName+' '+params.data.memberDetails.lastName;
    } },

		//{headerName: 'DOB', field: 'dob', width: 140 },
		{headerName: 'Member/relation', field: '',
    cellRenderer: (params: ValueGetterParams) => {
        return params.data.leadDetails.memberName+'<span>'+params.data.leadDetails.relation+'</span>';
    } },

		{headerName: 'Category', field: 'policyDetails.categoryDetails.categoryName',
    cellRenderer: (params: ValueGetterParams) => {
        return '<span>'+params.data.policyDetails.categoryDetails.categoryName+'</span>';
    } },

		{headerName: 'Sub-Category', cellRenderer: (params: ValueGetterParams) => {
      return params.data.policyDetails.categoryDetails.categoryName+'<span>'+params.data.policyDetails.categoryDetails.subCategoryName+'</span>';
    }},
    {headerName: 'Start date/ End date', cellRenderer: (params: ValueGetterParams) => {
     
    return this.datepipe.transform(params.data.policyDetails.startDate, 'MMM d, y')+'<span>'+this.datepipe.transform(params.data.policyDetails.endDate, 'MMM d, y')+'</span>';
 
  
}},
		{field:'Action', cellRenderer: ButtonComponent,resizable: false,cellClass:'actionDot', sortable: false}
	];

  public defaultColDef: ColDef = {
    filter: true,
    resizable: true,
    autoHeight: true
  };

  rowData = [
		{ make: 'Toyota', model: 'Celica', price: 35000 },
		{ make: 'Ford', model: 'Mondeo', price: 32000 },
		{ make: 'Porsche', model: 'Boxster', price: 72000 }
	];
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  

  AssignPartnerForm: FormGroup = new FormGroup({
    partnerId: new FormControl('', [
      Validators.required
    ])
  });
  gridColumnApi: any;
  constructor(private userAuthService:UserAuthService, public datepipe: DatePipe, private toastrService:ToastrService, private _FormBuilder:FormBuilder) {
    this.context = {componentParent: this};
    this.gridOptions=<GridOptions>{
      
    }

  }

  ngOnInit(): void {
    this.getList();
  }
  getList(){
    this.__List = this.userAuthService.getGeneralOfferLists({
      proposalState: "POLICY_CREATED",
      pageSize: 200,
      pageCount: 1,
      entityType:'MEMBER_ID',
      offerType:""
    }).subscribe({
      next: (x: any) => {
       this.all_List=x.data.proposalsList;
      }, 
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        
      },
      complete: () => {
        //this.registerSubmitted = false;
      },
    });
  }

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;
       this.gridApi.sizeColumnsToFit(); 
   }
  onCellClicked( e: CellClickedEvent): void {
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(
      (document.getElementById('filter-text-box') as HTMLInputElement).value
    );
  }
}
