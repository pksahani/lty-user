import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserAuthService } from 'src/app/_services/user-auth.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit{
  _getDetail: any;
  OfferId: string;
  policydata: any=[];
constructor(private userAuthService:UserAuthService, private route:ActivatedRoute){

}
ngOnInit(): void {
  this.OfferId=this.route.snapshot.paramMap.get('OfferId');
  
  if(this.OfferId!=''){
    this.GetPolicyDetail();
  }
}

  GetPolicyDetail(): any {
   
    this._getDetail = this.userAuthService.GetProposalDetail({
      proposalId: this.OfferId
    }).subscribe({
      next: (x: any) => {
       this.policydata=x.data;
       
      //  let res=x.data;
      //  this.CriminalFileType=this.getExtension(res.companyDetails.privateCriminalRecord);
      //  this.CriminalFile=res.companyDetails.privateCriminalRecord;
      //  this.PrivateOPFileType=this.getExtension(res.companyDetails.privateOp);
      //  this.PrivateOPFile=res.companyDetails.privateOp;
      //  this.CompanyPoFileType=this.getExtension(res.companyDetails.companyPo);
      //  this.CompanyPoFile=res.companyDetails.companyPo;
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        
      },
      complete: () => {
        
      },
    });
console.log("hello");

   
     
   
  }

}
