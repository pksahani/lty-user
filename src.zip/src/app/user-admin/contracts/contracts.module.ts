import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ContractsRoutingModule } from './contracts-routing.module';
import { ListComponent } from './list/list.component';
import { ViewComponent } from './view/view.component';
import { ButtonComponent } from './list/button/button.component';


@NgModule({
  declarations: [
    ListComponent,
    ViewComponent,
    ButtonComponent
  ],
  imports: [
    CommonModule,
    ContractsRoutingModule,
    AgGridModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers:  [DatePipe]
})
export class ContractsModule { }
