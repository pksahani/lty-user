import { Component } from '@angular/core';
import { Router} from '@angular/router';
import { UserAuthService } from '../../_services/user-auth.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  _isUserLoggedIn:any;
  _user:any;
  _signOutSub:any;
  _getProfile:any;
  _getLoggedInuser:any={
    firstName:''
  };
  logoutErrorMessage:any;
  constructor( private router:Router, private userAuthService:UserAuthService){
   

  }
  ngOnInit(): void {
    window.scrollTo(0, 0);

    if (this.isUserLoggedIn()) {
      this.getCurrentUser();
      this.GetProfileDetail();
      //this.router.navigate(['/user']);
    }
  }
  isUserLoggedIn(): boolean {
    let data = localStorage.getItem('user');
    
    if (data != null) {
      return this._isUserLoggedIn = true;
    }
    return this._isUserLoggedIn = false;
  }
  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
   
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this._getLoggedInuser=x.data;
        //console.log(this._getLoggedInuser);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
        //this.logoutErrorMessage = errRes.error.message;
      },
      complete: () => {
        
      },
    });
  }

  SignOut(): any {
    localStorage.removeItem('user');
    this._signOutSub = this.userAuthService.signout(
      {
        token:this._user.token,
        hardSignOut:true
      }
    ).subscribe({
      next: (x: any) => {
        localStorage.removeItem('user');
        localStorage.clear();

        setTimeout(() => {
          this.router.navigate(['/signin']);
      }, 2000);
        
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        localStorage.clear();
        this.router.navigate(['/signin']);
        this.logoutErrorMessage = errRes.error.message;
      },
      complete: () => {
        localStorage.removeItem('user');
      },
    });
  }

}
