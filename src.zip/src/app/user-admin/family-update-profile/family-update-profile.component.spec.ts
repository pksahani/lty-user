import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FamilyUpdateProfileComponent } from './family-update-profile.component';

describe('FamilyUpdateProfileComponent', () => {
  let component: FamilyUpdateProfileComponent;
  let fixture: ComponentFixture<FamilyUpdateProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FamilyUpdateProfileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FamilyUpdateProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
