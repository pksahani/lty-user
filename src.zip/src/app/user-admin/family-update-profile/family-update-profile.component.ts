import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd} from '@angular/router';
import {FormControl, Validators, FormGroup, FormBuilder, ValidationErrors, EmailValidator} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../confirm-dialog/confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';
declare var $: any;

@Component({
  selector: 'app-family-update-profile',
  templateUrl: './family-update-profile.component.html',
  styleUrls: ['./family-update-profile.component.css']
})


export class FamilyUpdateProfileComponent implements OnInit {
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  __MemberList:any;
  __MemberDelete:any;
  memberType:any="";
  member_List:any=[];
  memberSuccessMessage:any;
  result:any;
  country_List:any=[];
  _user: any;
  myProfile: any;

  selectedFiles: any;
  profilePic: File;
  _UploadPic: any;
  fileName: any;
  profile_image: string | ArrayBuffer;
  regIdType: any;
  regIdTypeBack: any;
  regIdFront:any="";
  regIdBack:any="";
  regIdFront1:any="";
  regIdBack1:any="";
  form_type:any="";

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";
 
  constructor(private dialog:MatDialog, private formBuilder: FormBuilder, private toastrService: ToastrService, private router: Router, private userAuthService:UserAuthService){}

  familyMemberForm: FormGroup = new FormGroup({
    userfirstname: new FormControl('', [Validators.required]),
    userlastname: new FormControl('', [Validators.required]),
    usermemberType: new FormControl('', [Validators.required]),
    userEmail: new FormControl('', [Validators.required, Validators.email]),
    usergender: new FormControl("Male", [Validators.required]),
    userdob: new FormControl('', [Validators.required,Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    countryCode: new FormControl(""),
    usermobile: new FormControl("", [Validators.required]),
    registrationId: new FormControl("",[Validators.required]),
    registrationIdBack: new FormControl("",[Validators.required]),
    //useraddress: new FormControl('', [Validators.required])
  },{
    updateOn: "change",
  });

  familyMemberFormEdit = new FormGroup({
    familyMemberId: new FormControl('', [Validators.required]),
    userfirstname: new FormControl('', [Validators.required]),
    userlastname: new FormControl('', [Validators.required]),
    usermemberType: new FormControl('', [Validators.required]),
    userEmail: new FormControl('', [Validators.required, Validators.email]),
    usergender: new FormControl("Male", [Validators.required]),
    userdob: new FormControl('', [Validators.required,Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    countryCode: new FormControl(""),
    usermobile: new FormControl("", [Validators.required]),
    registrationId: new FormControl("",[Validators.required]),
    registrationIdBack: new FormControl("",[Validators.required])
  },{
    updateOn: "change",
  });


  
  async ngOnInit():Promise<void>{
    window.scroll(0, 0);
    this.getCurrentUser();
    this.GetProfileDetail();
    //this.getCountries();
    this.country_List=await this.getCountries();
    this.getFamilymembers();
  }
  
  get fmemberError() { return this.familyMemberForm.controls; }
  get fmemberEError() { return this.familyMemberFormEdit.controls; }

  getFamilymembers(): void {
    this.__MemberList = this.userAuthService.getFamilymembers({
      relation:this.memberType
    }).subscribe({
     next: (x: any) => {
      this.member_List=x.data.familyMemberList;
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
     },
     complete: () => {
     },
   });
  }

  addFamilymembers(): void {
    if (this.familyMemberForm.invalid) {
      this.toastrService.error('Please fill All required Field.');
      return;
    }
    var phone:any=this.familyMemberForm.getRawValue().usermobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;
    var regId:any=[];
    regId.push(this.familyMemberForm.getRawValue().registrationId);
    regId.push(this.familyMemberForm.getRawValue().registrationIdBack);

    this.__MemberList = this.userAuthService.addFamilymembers({
        memberType: this.familyMemberForm.getRawValue().usermemberType,
        firstName: this.familyMemberForm.getRawValue().userfirstname,
        lastName: this.familyMemberForm.getRawValue().userlastname,
        address: this.familyMemberForm.getRawValue().useraddress,
        dob: this.familyMemberForm.getRawValue().userdob,
        countryCode:countryCode,
        mobile: phoneNumber,
        // countryCode:this.familyMemberForm.getRawValue().countryCode,
        // mobile: this.familyMemberForm.getRawValue().usermobile,
        gender: this.familyMemberForm.getRawValue().usergender,
        email: this.familyMemberForm.getRawValue().userEmail,
        registrationIds:regId
      }
    ).subscribe({
      next: (x: any) => {
          this.familyMemberForm.reset();
          this.familyMemberForm.controls['usermemberType'].setValue("");
          this.toastrService.success("Member added successfully");
          this.hideAddModal();
          //this.familyMemberForm.controls['userEmail'].setValue(this.myProfile.email);
          //if(this.myProfile.countryCode!=null && this.myProfile.countryCode!=undefined){ 
          //this.familyMemberForm.controls['countryCode'].setValue(this.myProfile.countryCode); 
          //this.familyMemberForm.controls['usermobile'].setValue(this.myProfile.mobile);
          this.getFamilymembers();
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }

  UpdateFamilymembers(): void {
    if (this.familyMemberFormEdit.invalid) {
      Object.keys(this.familyMemberFormEdit.controls).forEach(key => {
        const controlErrors: ValidationErrors = this.familyMemberFormEdit.get(key).errors;
        if (controlErrors != null) {
          Object.keys(controlErrors).forEach(keyError => {
          console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
          });
        }
      });

      this.toastrService.error('Please fill All required Field.');
      return;
    }
    var phone:any=this.familyMemberFormEdit.getRawValue().usermobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;
    var regId:any=[];
    var regId:any=[];
    regId.push(this.familyMemberFormEdit.getRawValue().registrationId);
    regId.push(this.familyMemberFormEdit.getRawValue().registrationIdBack);
    this.__MemberList = this.userAuthService.updateFamilymembers({
        familyMemberId: this.familyMemberFormEdit.getRawValue().familyMemberId,
        firstName: this.familyMemberFormEdit.getRawValue().userfirstname,
        lastName: this.familyMemberFormEdit.getRawValue().userlastname,
        dob: this.familyMemberFormEdit.getRawValue().userdob,
        countryCode:countryCode,
        mobile: phoneNumber,
        // countryCode:this.familyMemberFormEdit.getRawValue().countryCode,
        // mobile: this.familyMemberFormEdit.getRawValue().usermobile,
        gender: this.familyMemberFormEdit.getRawValue().usergender,
        email: this.familyMemberFormEdit.getRawValue().userEmail,
        registrationIds:regId
      }).subscribe({
      next: (x: any) => {
          this.memberSuccessMessage = 'Member updated successfully.';
          this.familyMemberFormEdit.reset();
          this.toastrService.success(this.memberSuccessMessage);
          this.hideEditModal();
          this.getFamilymembers();
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }

  OpenUpdateModal(obj:any){

    if(obj.countryCode.includes("+")){ 
      obj.countryCode.substring(1);
    }
    if(obj.mobile.includes("0")){ 
      obj.mobile.substring(1);
    }
    let country=this.country_List.filter(function (country:any) { return country.phonecode == obj.countryCode });
    this.iso=country[0].sortname;
    this.showEditModal();
    this.familyMemberFormEdit.controls['familyMemberId'].setValue(obj.familyMemberId);
    this.familyMemberFormEdit.controls['userfirstname'].setValue(obj.firstName);
    this.familyMemberFormEdit.controls['userlastname'].setValue(obj.lastName);
    this.familyMemberFormEdit.controls['userdob'].setValue(obj.dob);
    //this.familyMemberFormEdit.controls['countryCode'].setValue(obj.countryCode);//#####
    this.familyMemberFormEdit.controls['usermobile'].setValue(obj.mobile); //#####

    this.familyMemberFormEdit.controls['usergender'].setValue(obj.gender);
    this.familyMemberFormEdit.controls['usermemberType'].setValue(obj.memberType);
    this.familyMemberFormEdit.controls['userEmail'].setValue(obj.email);
    this.familyMemberFormEdit.controls['usergender'].setValue(obj.gender);
   
    var myarr:any;
    var myarr1:any;
    if(obj.registrationIds!=null && obj.registrationIds.length>0){
      if(obj.registrationIds[0]!=null && obj.registrationIds[0]!=""){
        myarr = obj.registrationIds[0].split("/");
        var myimg = myarr[myarr.length - 1] ? myarr[myarr.length - 1] : "";
        var myimgg = myimg.split(".");
        this.regIdType = myimgg[myimgg.length - 1] ? myimgg[myimgg.length - 1]: "";
      }
      if(obj.registrationIds[1]!=null && obj.registrationIds[1]!=""){
        myarr1 = obj.registrationIds[1].split("/");
        var myimg1 = myarr1[myarr1.length - 1] ? myarr1[myarr1.length - 1] : "";
        var myimgg1= myimg1.split(".");
        this.regIdTypeBack = myimgg1[myimgg1.length - 1] ? myimgg1[myimgg1.length - 1] : "";
      }
      this.familyMemberFormEdit.controls["registrationId"].setValue(obj.registrationIds[0]);
      this.familyMemberFormEdit.controls["registrationIdBack"].setValue(obj.registrationIds[1]);

      this.regIdFront1=obj.registrationIds[0];
      this.regIdBack1=obj.registrationIds[1];
    }
  }

  showAddModal(){
    $('#addMemberProfile').offcanvas('show');
    this.form_type="add";
  }
  showEditModal(){
    $('#editMemberProfile').offcanvas('show');
    this.form_type="edit";
  }

  hideAddModal(){
    $('#addMemberProfile').offcanvas('hide');
    this.form_type="";
    this.regIdType="";
    this.regIdTypeBack="";
  }
  hideEditModal(){
    $('#editMemberProfile').offcanvas('hide');
    this.form_type="";
     this.regIdType="";
    this.regIdTypeBack="";
  }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
           
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  }

  DeleteMember(obj:any){
      this.__MemberDelete = this.userAuthService.deleteFamilymember({
      familyMemberId: obj.familyMemberId,
      reason: ""
    }).subscribe({
      next: (x: any) => {
            this.memberSuccessMessage = 'Member Removed successfully.';
            this.toastrService.success(this.memberSuccessMessage);
            this.getFamilymembers();
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }

  confirmDialog(obj:any): void {
    const message = `Are you sure you want to remove this member?`;
    const dialogData = new ConfirmDialogModel("Confirm Removal!", message);
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });
    dialogRef.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
      if(this.result==true){
        this.DeleteMember(obj);
      } 
    });
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this.userAuthService.getuserByToken({
        token:this._user.token
    }).subscribe({
      next: (x: any) => {
        this.myProfile=x.data;
        
        if(x.data.countryCode.includes("+")){ 
          x.data.countryCode.substring(1);
        }
        if(x.data.mobile.includes("0")){ 
          x.data.mobile.substring(1);
        }
        let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
        this.iso=country[0].sortname;
        this.familyMemberForm.controls['userEmail'].setValue(this.myProfile.email);
        this.familyMemberForm.controls['usermobile'].setValue(this.myProfile.mobile);
        //this.familyMemberForm.controls['countryCode'].setValue(this.myProfile.countryCode); 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  uploadFile(event:any) {
    this.selectedFiles = event.target.files;
    if (this.selectedFiles !== undefined) {
      this.fileName = this.selectedFiles.item(0)?.name;
      const profile_imageh = event.target.files[0];
      const reader = new FileReader();
      reader.onload = (e) => (this.profile_image = reader.result);
      reader.readAsDataURL(profile_imageh);
    } else {
      this.fileName = "";
    }
    var type = "registrationId";
    this.updateProfilePic(type);
  }

  uploadFile1(event:any) {
    this.selectedFiles = event.target.files;
    if (this.selectedFiles !== undefined) {
      this.fileName = this.selectedFiles.item(0)?.name;
      const profile_imageh = event.target.files[0];
      const reader = new FileReader();
      reader.onload = (e) => (this.profile_image = reader.result);
      reader.readAsDataURL(profile_imageh);
    } else {
      this.fileName = "";
    }
    var type = "registrationIdBack";
    this.updateProfilePic(type);
  }

  updateProfilePic(type: any = ""): void {
    if (this.selectedFiles) {
      const file: File | null = this.selectedFiles.item(0);
      if (file) {
        this.profilePic = file;
      }
    }
    let docname = "";
    if(type=="registrationIdBack"){
      docname = "Registration ID Back";
    } else {
      docname = "Registration ID Front";
    }
    this._UploadPic = this.userAuthService
      .UploadDocument({
        docName: docname,
        userId: "",
        doc: this.profilePic,
        memberId: "",
      })
      .subscribe({
        next: (result: any) => {
          var myarr:any;
          var myarr1:any;
          if(type=="registrationIdBack"){
              
              if(result.data.docUrl!=null && result.data.docUrl!=""){
                myarr1 = result.data.docUrl.split("/");
                var myimg1 = myarr1[myarr1.length - 1] ? myarr1[myarr1.length - 1] : "";
                var myimgg1= myimg1.split(".");
                this.regIdTypeBack = myimgg1[myimgg1.length - 1] ? myimgg1[myimgg1.length - 1] : "";
              }

              if(this.form_type=="add"){
                this.regIdBack=result.data.docUrl;
                //this.familyMemberForm.controls["registrationId"].setValue(result.data.docUrl);
                this.familyMemberForm.controls["registrationIdBack"].setValue(result.data.docUrl);
              }else{
                this.regIdBack1=result.data.docUrl;
                //this.familyMemberFormEdit.controls["registrationId"].setValue(result.data.docUrl);
                this.familyMemberFormEdit.controls["registrationIdBack"].setValue(result.data.docUrl);
              }
            
          }else {
            if(result.data.docUrl!=null && result.data.docUrl!=""){
              myarr = result.data.docUrl.split("/");
              var myimg = myarr[myarr.length - 1] ? myarr[myarr.length - 1] : "";
              var myimgg = myimg.split(".");
              this.regIdType = myimgg[myimgg.length - 1] ? myimgg[myimgg.length - 1]: "";
            }

            if(this.form_type=="add"){
              this.regIdFront=result.data.docUrl;
              this.familyMemberForm.controls["registrationId"].setValue(result.data.docUrl);
              //this.familyMemberForm.controls["registrationIdBack"].setValue(result.data.docUrl);
            }else{
              this.regIdFront1=result.data.docUrl;
              this.familyMemberFormEdit.controls["registrationId"].setValue(result.data.docUrl);
              //this.familyMemberFormEdit.controls["registrationIdBack"].setValue(result.data.docUrl);
            }
            
            
          }
          return;
        },
        error: (err: any) => {
          if (err.error.error.profile_pic) {
            this.toastrService.error(err.error.error.profile_pic, "");
          } else {
            this.toastrService.error(err.error.message, "");
          }
        },
        complete: () => {},
      });
  }

}
