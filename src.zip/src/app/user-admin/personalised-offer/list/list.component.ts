import { Component, OnInit, ViewChild } from '@angular/core';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { SignaturePad } from 'angular2-signaturepad';
import { ToastrService } from 'ngx-toastr';
declare var $: any;
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  proposal_List: any=[];
  proposaloffer_List: any=[];
  signatureImg: string;
  @ViewChild(SignaturePad) signaturePad: SignaturePad;
  signaturePadOptions: Object = { 
    'minWidth': 2,
    'canvasWidth': 700,
    'canvasHeight': 300
  };
  currentOffer: any;
  selectedFiles: any;
  fileName: any;
  signeddoc_image: string | ArrayBuffer;
  profilePic: File;
  _UploadPic: any;
  Signed_Doc: any=[];
  Signed_DocType: any=[];
  constructor(private userAuthService:UserAuthService, private toasterService:ToastrService){

  }
  ngOnInit(): void {
    this.getLeadList();
  }


  panels = ['First', 'Second', 'Third'];
  __ProposalList: any;


  getLeadList(): void {
    this.__ProposalList = this.userAuthService.getLeadList({
      status:'',
      pageSize:100,
      pageCount:1
    }).subscribe({
     next: (x: any) => {
      this.proposal_List=x.data.leadsList;
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
       console.error(err)
       
     },
     complete: () => {
       //this.registerSubmitted = false;
     },
   });
   
 }
 
 getProposalOffer(obj:any){
  this.__ProposalList = this.userAuthService.getProposalOfferList({
    leadId:obj.leadId
  }).subscribe({
   next: (x: any) => {
    this.proposaloffer_List=x.data.proposalsList;
   },
   error: (err: Error) => {
     let errRes: any;
     errRes = err;
     console.error(err)
     
   },
   complete: () => {
     //this.registerSubmitted = false;
   },
 });
 }

 AcceptProposal(obj:any){
  if(this.Signed_Doc.length<1){
    this.toasterService.error('Please Upload Signed Document.');
    return;
  }
  this.__ProposalList = this.userAuthService.updateProposalState({
    proposalId:obj.proposalId,
    partnerId:obj.partnerId,
    proposalState:'SIGNED_DOCS',
    signedDoc:this.Signed_Doc,
  }).subscribe({
   next: (x: any) => {
    this.toasterService.success('Proposal Accepted successfully.');
    this.getProposalOffer(obj.leadDetails);
    $('#modal-doc-verification').modal('hide');
   },
   error: (err: Error) => {
     let errRes: any;
     errRes = err;
     //console.error(err)
     this.toasterService.error(errRes.error.error.clientErrorMessage);
     
   },
   complete: () => {
     //this.registerSubmitted = false;
   },
 });
 }
 OpenAcceptProposal(obj:any){
  this.currentOffer=obj;
$("#modal-doc-verification").modal('show');
 }

 OpenRejectProposal(obj:any){
  this.currentOffer=obj;
$("#modal-reject-proposal").modal('show');
 }

 RejectProposal(obj:any){
  
  this.__ProposalList = this.userAuthService.updateProposalState({
    proposalId:obj.proposalId,
    partnerId:obj.partnerId,
    proposalState:'REJECTED'
  }).subscribe({
   next: (x: any) => {
    this.toasterService.success('Proposal Reject successfully.');
    this.getProposalOffer(obj.leadDetails);
    $('#modal-reject-proposal').modal('hide');
   },
   error: (err: Error) => {
     let errRes: any;
     errRes = err;
     //console.error(err)
     this.toasterService.error(errRes.error.error.clientErrorMessage);
     
   },
   complete: () => {
     //this.registerSubmitted = false;
   },
 });
 }

 uploadFile(event) {
  this.selectedFiles = event.target.files;
    if (this.selectedFiles !== undefined) {
      this.fileName=this.selectedFiles.item(0)?.name;
      const profile_imageh=event.target.files[0];
      const reader = new FileReader();
      reader.onload = e => this.signeddoc_image = reader.result;
      reader.readAsDataURL(profile_imageh);
    }else{
      this.fileName="";
    }

    this.updateProfilePic();
}

updateProfilePic(type:any='') : void {
  if (this.selectedFiles) {
    const file: File | null = this.selectedFiles.item(0);
    if (file) {
      this.profilePic = file;
    }
  }
  this._UploadPic = this.userAuthService.UploadDocument({
    docName:'Signed Doc',
    userId:this.currentOffer?.memberDetails?.memberId,
    memberId:this.currentOffer?.leadDetails?.memberId,
    uploadedBy:'',
    doc:this.profilePic
  }).subscribe( {
      next: (result: any) => {

        this.Signed_Doc.push(result.data.docUrl);
        let doc:any=[];
        doc['doc']=result.data.docUrl;
        doc['doctype']=this.getExtension(result.data.docUrl);
        this.Signed_DocType.push(doc);
        //this.Signed_DocType=this.getExtension(result.data.docUrl);
       

     
        //this.toastrService.success("Profile Pic updated successfully!","");
        return;
      },
      error: (err: any) => {
        if(err.error.error.profile_pic){
          this.toasterService.error(err.error.error.profile_pic,"");
        }else{
          this.toasterService.error(err.error.message,"");
        }
      },
      complete: () => {
      }
  }); 
}

 getFileName(docurl:any){
  var myarr = docurl.split("/");
  //console.log(myarr.length);
  var myimg=myarr[myarr.length-1]?myarr[myarr.length-1]:'';
  return myimg;
}

getExtension(docurl:any){
  var myarr = docurl.split("/");
  
  var myimg=myarr[myarr.length-1]?myarr[myarr.length-1]:'';
  var myimgg = myimg.split(".");
 
  return myimgg[myimgg.length-1]?myimgg[myimgg.length-1]:'';
}

ngAfterViewInit() {
  // this.signaturePad is now available
  //this.signaturePad.set('minWidth', 2); 
 // this.signaturePad.clear(); 
}

drawComplete() {
  console.log(this.signaturePad.toDataURL());
}

drawStart() {
  console.log('begin drawing');
}

clearSignature() {
  this.signaturePad.clear();
}

savePad() {
  //$(".signature-container").hide();
  const base64Data = this.signaturePad.toDataURL();
  this.signatureImg = base64Data;
}

removeImg(index:any){
  if (index > -1) { // only splice array when item is found
    this.Signed_Doc.splice(index, 1); // 2nd parameter means remove one item only
    this.Signed_DocType.splice(index, 1); // 2nd parameter means remove one item only
  }
  return true;
}

}
