import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserAuthService } from 'src/app/_services/user-auth.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  offerId: any;
  _getDetail: any;
  proposalDetail: any=[];

constructor(private route:ActivatedRoute, private userAuthService:UserAuthService,private router:Router){
  this.offerId = this.route.snapshot.paramMap.get('OfferId');
}
  ngOnInit(): void {
   
	  if(this.offerId!=''){
      this.GetProposalDetail();
    }
  }

  GetProposalDetail(){
    this._getDetail = this.userAuthService.GetProposalDetail({
      proposalId: this.offerId
    }).subscribe({
      next: (x: any) => {
       this.proposalDetail=x.data;
       
       let res=x.data;
      
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        
      },
      complete: () => {
        
      },
    });
  }

  getFileName(docurl:any){
    var myarr = docurl.split("/");
    //console.log(myarr.length);
    var myimg=myarr[myarr.length-1]?myarr[myarr.length-1]:'';
    return myimg;
  }

  goBack(){
    console.log("here");
    this.router.navigate(["/user/personalised-offer"]);
  }

}
