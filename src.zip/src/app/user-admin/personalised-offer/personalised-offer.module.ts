import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { BrowserModule } from '@angular/platform-browser';
import { NgbModule, NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';

import { PersonalisedOfferRoutingModule } from './personalised-offer-routing.module';
import { ListComponent } from './list/list.component';
import { SignaturePadModule } from 'angular2-signaturepad';
import { ViewComponent } from './view/view.component';
//import { ListComponent } from './list/list.component';


@NgModule({
  declarations: [
    ListComponent,
    ViewComponent
  ],
  imports: [
    CommonModule,
   // BrowserModule,
    PersonalisedOfferRoutingModule,
    NgbModule,
    NgbAccordionModule,
    SignaturePadModule 
  ]
})
export class PersonalisedOfferModule { }
