import { NgModule } from '@angular/core';
import { ChildActivationEnd, RouterModule, Routes } from '@angular/router';
import { ListComponent } from './list/list.component';
import { HealthComponent } from './health/health.component';
import { TermLifeComponent } from './term-life/term-life.component';
import { GeneralComponent } from './general/general.component';
import { TravelComponent } from './travel/travel.component';
import { BuildingComponent } from './building/building.component';
import { RcHouseholdComponent } from './rc-household/rc-household.component';
//import { CarInsuranceComponent } from './car-insurance/car-insurance.component';
import { MotorVehicleComponent } from './car-insurance/motor-vehicle.component';
import { FamilyComponent } from './family/family.component';
import { ChildComponent } from './child/child.component';
import { LegalProtectionComponent } from './legal-protection/legal-protection.component';
import { BvgContractComponent } from './bvg-contract/bvg-contract.component';
import { LaaAaComponent } from './laa-aa/laa-aa.component';
import { LossEarningComponent } from './loss-earning/loss-earning.component';
import { ThirdPillarComponent } from './third-pillar/third-pillar.component';
import { SuccessProposalComponent } from './success-proposal/success-proposal.component';
import { BusinessCompaniesThingsComponent } from './business-companies-things/business-companies-things.component';
import { BusinessInsuranceComponent } from './business-insurance/business-insurance.component';
import { BusinessLegalProtectionComponent } from './business-legal-protection/business-legal-protection.component';
import { ConstructionComponent } from './construction/construction.component';
import { AnimalsWauMiauComponent } from './animals-wau-miau/animals-wau-miau.component';
import { QuotationRequestValuablesComponent } from './quotation-request-valuables/quotation-request-valuables.component';
import { HousingRentalComponent } from './housing-rental/housing-rental.component';

const routes: Routes = [
  {
    path: '',
    component: ListComponent
  },
  {
    path: 'list',
    component: ListComponent
  },
  {
    path: 'health/:Mrelation/:MemberId',
    component: HealthComponent
  },
  {
    path: 'term-life/:Mrelation/:MemberId',
    component: TermLifeComponent
  },
  {
    path: 'general/:Mrelation/:MemberId',
    component: GeneralComponent
  },
  {
    path: 'travel/:Mrelation/:MemberId',
    component: TravelComponent
  },
  {
    path: 'building/:Mrelation/:MemberId',
    component: BuildingComponent
  },
  {
    path: 'rc-household/:Mrelation/:MemberId',
    //path: 'rc-household',
    component: RcHouseholdComponent
  },
  // {
  //   path: 'car-insurance/:Mrelation/:MemberId',
  //   //path: 'car-insurance',
  //   component: CarInsuranceComponent
  // },
  {
    path: 'motor-vehicle/:Mrelation/:MemberId',
    //path: 'car-insurance',
    component: MotorVehicleComponent
  },
  
  {
    path: 'family',
    component: FamilyComponent
  },
  {
    path: 'child',
    component: ChildComponent
  },
  {
    path: 'legal-protection/:Mrelation/:MemberId',
    //path: 'legal-protection',
    component: LegalProtectionComponent
  },
  {
    path: 'bvg-contract',
    component: BvgContractComponent
  },
  {
    path: 'laa-aa',
    component: LaaAaComponent
  },
  {
    path: 'loss-earning',
    component: LossEarningComponent
  },
  {
    path: '3rd-piller/:Mrelation/:MemberId',
    //path: '3rd-piller',
    component: ThirdPillarComponent
  },
  {
    path: 'thanks-proposal',
    component: SuccessProposalComponent
  },
  
  {
    path: 'business-legal-protection/:Mrelation/:MemberId',
   // path: 'business-legal-protection',
    component: BusinessLegalProtectionComponent
  },
  {
    path: 'business-insurance/:Mrelation/:MemberId',
    //path: 'business-insurance',
    component: BusinessInsuranceComponent
  },
  {
    path: 'business-companies-things/:Mrelation/:MemberId',
    //path: 'business-companies-things',
    component: BusinessCompaniesThingsComponent
  },
  {
    path: 'construction/:Mrelation/:MemberId',
    //path: 'construction',
    component: ConstructionComponent
  },
  {
    path: 'animals-wau-miau/:Mrelation/:MemberId',
    //path: 'animals-wau-miau',
    component: AnimalsWauMiauComponent
  },
  {
    path: 'quotation-request-valuables/:Mrelation/:MemberId',
    //path: 'quotation-request-valuables',
    component: QuotationRequestValuablesComponent
  },
  {
    path: 'housing-rental/:Mrelation/:MemberId',
    //path: 'housing-rental',
    component: HousingRentalComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class RequestProposalRoutingModule {

 }
