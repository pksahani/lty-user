import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-construction',
  templateUrl: './construction.component.html',
  styleUrls: ['./construction.component.css']
})
export class ConstructionComponent implements OnInit  {
  country_List:any=[];
  durationList:any=["1 Year","2 Years","5 Years"];
  benefits:any=[];
  typeOfObjects:any=[];
  technique:any=[];
  underpinning:any=[];
  solarType:any=[];
  insuranceType: any='CONSTRUCTION';
  partnerId: string;
  memberId: string;
  relation: string;
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";

  isItCivilEngineerProject:any="";
  demolition:any="";
  search:any="";
  changesToStructure:any="";
  roofWork:any="";
  dangerZone:any="";
  conditionOfThirdPartyWork:any="";
  statutoryCivilLiability:any="";
  //desiredInsurance:any=[];
  
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {}

  constructorInsuranceForm = new FormGroup({
    policyHolder:new FormControl("Owner"),
    firstName: new FormControl(""),
    lastName: new FormControl(""),
    address: new FormControl(""),
    countryCode: new FormControl(""),
    mobile: new FormControl(""),
    email:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    effectiveDate: new FormControl("", [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    typeOfConstruction:new FormControl(""),
    landRegistryNo:new FormControl(""), //ProjectAddressDetails 
    streetNo:new FormControl(""),       //ProjectAddressDetails 
    location:new FormControl(""),       //ProjectAddressDetails 
    postalCode:new FormControl(""),     //ProjectAddressDetails 
    startDateOfWork:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //ProjectAddressDetails 
    endDateOfWork:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),   //ProjectAddressDetails 
    areTheWorkAccepted:new FormControl(""),
    hasWorkStarted:new FormControl(""),
    knownLoss:new FormControl(""),
    name_architect:new FormControl(""),
    email_architect:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    countryCode_architect: new FormControl(""),
    phone_architect:new FormControl(""),
    address_architect:new FormControl(""),
    name_Cengineer:new FormControl(""),
    email_Cengineer:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    countryCode_Cengineer: new FormControl(""),
    phone_Cengineer:new FormControl(""),
    address_Cengineer:new FormControl(""),
    masterOfWorkFor:new FormControl(""),
    name_Wmaster:new FormControl(""),
    email_Wmaster:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    countryCode_Wmaster: new FormControl(""),
    phone_Wmaster:new FormControl(""),
    address_Wmaster:new FormControl(""),
    constructionWork:new FormControl(""), //pending
    establishments:new FormControl(""),   //pending
    builderLiability:new FormControl(""), //pending
    ownerPartition:new FormControl(""),
    neighborhood:new FormControl(""),
    whichOne:new FormControl(""),
    totalCost:new FormControl(""),
    //isItCivilEngineerProject:new FormControl(""),
    distance:new FormControl(""),
    //demolition:new FormControl(""),
    topography:new FormControl(""),
    landToBuild:new FormControl(""),
    earthWork:new FormControl(""),
    earthWorkValue:new FormControl(""),
    upperFloors:new FormControl(""),
    execution:new FormControl(""),
    //technique:new FormControl(""),
    loweringOfWaterTable:new FormControl(""),
    structureFormula:new FormControl(""),
    stalling:new FormControl(""),
    //underpinning
    drillingForGeothermal:new FormControl(""),
    number:new FormControl(""),
    depth:new FormControl(""),
    areSolarInstalled:new FormControl(""),
    //solarType
    dangerZoneDetail:new FormControl(""),


    
    buildingInhabited: new FormControl(""),
    briefExplanation:new FormControl(""),
    civilEngineer:new FormControl(""),
    distanceto:new FormControl(""),
    earthworkRadio:new FormControl(""),
    earthworkOption:new FormControl(""),
    excavation:new FormControl(""),
    excavationOption:new FormControl(""),
    search:new FormControl(""),
    upperfloor:new FormControl(""),
    structureFoundations:new FormControl(""),
    waterTable:new FormControl(""),
  
    boreholes:new FormControl(""),
    boreholesNumber:new FormControl(""),
    depthBoreholes:new FormControl(""),
    solarInstallatins:new FormControl(""),
    duringTransformation:new FormControl(""),
    roofWork:new FormControl(""),
    dangerZone:new FormControl(""),
    pleaseSpecify:new FormControl(""),
    thirdPartyWork:new FormControl(""),
    railwayUndertaking:new FormControl(""),
    attachedFile:new FormControl(""),
    requirementClaim:new FormControl(""),
    requirementClaimWhy:new FormControl(""),
    docQuestionnaire:new FormControl(""),
    notes:new FormControl(""),
    quesDate:new FormControl(""),
    quesPlace:new FormControl(""),
    underpinning:new FormControl(""),
    totalCostChf:new FormControl(""),
    installationsInstalled:new FormControl(""),
    anchors:new FormControl(""),
    anchors1:new FormControl(""),
    drilling:new FormControl(""),
    vibrationsinking:new FormControl(""),
    threshing:new FormControl(""),
    excavationOption1:new FormControl(""),
    anchors2:new FormControl(""),
    drilling2:new FormControl(""),
    vibrationsinking2:new FormControl(""),
    vibrationsinking3:new FormControl(""),
    anchors4:new FormControl(""),
    drilling4:new FormControl(""),
    vibrationsinking4:new FormControl(""),
    threshing4:new FormControl(""),
    anchors5:new FormControl(""),
    nailing:new FormControl(""),
    anchors6:new FormControl(""),
    drilling6:new FormControl(""),
    vibrationsinking6:new FormControl(""),
    threshing6:new FormControl(""),
    withdrawal6:new FormControl(""),
    
  },{
     updateOn: "change",
  });

  async ngOnInit():Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
  }

  get constructorForm() { return this.constructorInsuranceForm.controls; }

  saveConstructionForm(){
    if (this.constructorInsuranceForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }
    this.toastrService.info("Under developement.");
    return;
    let desiredInsurance:any=[];
    desiredInsurance["Construction work insurance"]=this.constructorInsuranceForm.getRawValue().constructionWork;
    desiredInsurance["Cantons without cantonal insurance establishments: the risks fire/natural events must be insured?"]=this.constructorInsuranceForm.getRawValue().establishments;
    desiredInsurance["Builder's liability insurance (whether this insurance - for the amount of work planned - is not included in a combined Household, RC Company or other insurance)"]=this.constructorInsuranceForm.getRawValue().builderLiability;
   
   
   
    //save here 
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
        this.partnerId=x.data.partnerId;
        this.userId=x.data.userId;
        this.agentId=x.data.agentId;
       
        let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
        this.iso=country[0].sortname;
       
        this.constructorInsuranceForm.controls["firstName"].setValue(x.data.firstName);
        this.constructorInsuranceForm.controls["lastName"].setValue(x.data.lastName);
        this.constructorInsuranceForm.controls["address"].setValue(x.data.address);
        this.constructorInsuranceForm.controls["mobile"].setValue(x.data.mobile);
        this.constructorInsuranceForm.controls["email"].setValue(x.data.email);
        // this.constructorInsuranceForm.controls["maritalStatus"].setValue(x.data.maritalStatus);
        //this.quotationRequestForm.controls["duration"].setValue(x.data.duration); 
        this.constructorInsuranceForm.controls["effectiveDate"].setValue(x.data.effectiveDate);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
           
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }

  setisItCivilEngineerProject(items:any){
    if(items.target.checked){
      this.isItCivilEngineerProject=items.target.value;
    }else{ //remove unchecked value
      this.isItCivilEngineerProject="";
    }
  }

  setdemolition(items:any){
    if(items.target.checked){
      this.demolition=items.target.value;
    }else{ //remove unchecked value
      this.demolition="";
    }
  }

  setSearch(items:any){
    if(items.target.checked){
      this.search=items.target.value;
    }else{ //remove unchecked value
      this.search="";
    }
  }

  setchangesToStructure(items:any){
    if(items.target.checked){
      this.changesToStructure=items.target.value;
    }else{ //remove unchecked value
      this.changesToStructure="";
    }
  }

  setroofWork(items:any){
    if(items.target.checked){
      this.roofWork=items.target.value;
    }else{ //remove unchecked value
      this.roofWork="";
    }
  }

  setdangerZone(items:any){
    if(items.target.checked){
      this.dangerZone=items.target.value;
    }else{ //remove unchecked value
      this.dangerZone="";
    }
  }

  setconditionOfThirdPartyWork(items:any){
    if(items.target.checked){
      this.conditionOfThirdPartyWork=items.target.value;
    }else{ //remove unchecked value
      this.conditionOfThirdPartyWork="";
    }
  }

  setstatutoryCivilLiability(items:any){
    if(items.target.checked){
      this.statutoryCivilLiability=items.target.value;
    }else{ //remove unchecked value
      this.statutoryCivilLiability="";
    }
  }

  

  

  setTechnique(items:any){
    if(items.target.checked){
      this.technique.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.technique.length; i++) {
        let contact= this.technique[i];
        if(contact==items.target.value){
          this.technique.splice(i, 1);
        }
      }
    }
  }

  resetTechnique(items:any){
    this.technique=[];
  }

  setUnderpinning(items:any){
    if(items.target.checked){
      this.underpinning.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.underpinning.length; i++) {
        let contact= this.underpinning[i];
        if(contact==items.target.value){
          this.underpinning.splice(i, 1);
        }
      }
    }
  }

  setsolarType(items:any){
    if(items.target.checked){
      this.solarType.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.solarType.length; i++) {
        let contact= this.solarType[i];
        if(contact==items.target.value){
          this.solarType.splice(i, 1);
        }
      }
    }
  }





  



}
