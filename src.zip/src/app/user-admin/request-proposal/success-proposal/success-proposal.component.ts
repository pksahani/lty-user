import { Component } from '@angular/core';

@Component({
  selector: 'app-success-proposal',
  templateUrl: './success-proposal.component.html',
  styleUrls: ['./success-proposal.component.css']
})
export class SuccessProposalComponent {

}
