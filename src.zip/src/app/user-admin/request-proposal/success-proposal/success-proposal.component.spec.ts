import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessProposalComponent } from './success-proposal.component';

describe('SuccessProposalComponent', () => {
  let component: SuccessProposalComponent;
  let fixture: ComponentFixture<SuccessProposalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuccessProposalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SuccessProposalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
