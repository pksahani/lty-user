import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormGroup} from '@angular/forms';
import {FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-bvg-contract',
  templateUrl: './bvg-contract.component.html',
  styleUrls: ['./bvg-contract.component.css']
})
export class BvgContractComponent implements OnInit  {

  ngOnInit():void{
    window.scroll(0, 0);
  }

  familyInsuranceFormGroup = new FormGroup ({
    makeYourRequest: new FormControl('', [Validators.required]),
  });

  constructor(private _formBuilder: FormBuilder) {}

}
