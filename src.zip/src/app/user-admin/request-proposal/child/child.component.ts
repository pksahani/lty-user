import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormGroup} from '@angular/forms';
import {FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit  {

  ngOnInit():void{
    window.scroll(0, 0);
  }

  familyInsuranceFormGroup = new FormGroup ({
    makeYourRequest: new FormControl('', [Validators.required]),
  });

  constructor(private _formBuilder: FormBuilder) {}

}
