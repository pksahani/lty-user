import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { BrowserModule } from '@angular/platform-browser';
import { RequestProposalRoutingModule } from './request-proposal-routing.module';
import { HealthComponent } from './health/health.component';
import { ListComponent } from './list/list.component';
//import { CarInsuranceComponent } from './car-insurance/car-insurance.component';
import { MotorVehicleComponent } from './car-insurance/motor-vehicle.component';
import { TermLifeComponent } from './term-life/term-life.component';
import { GeneralComponent } from './general/general.component';
import { TravelComponent } from './travel/travel.component';
import { BuildingComponent } from './building/building.component';
import { RcHouseholdComponent } from './rc-household/rc-household.component';
import { FamilyComponent } from './family/family.component';
import { ChildComponent } from './child/child.component';
import { LegalProtectionComponent } from './legal-protection/legal-protection.component';
import { BvgContractComponent } from './bvg-contract/bvg-contract.component';
import { LaaAaComponent } from './laa-aa/laa-aa.component';
import { LossEarningComponent } from './loss-earning/loss-earning.component';
import { ThirdPillarComponent } from './third-pillar/third-pillar.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SuccessProposalComponent } from './success-proposal/success-proposal.component';
import { BusinessCompaniesThingsComponent } from './business-companies-things/business-companies-things.component';
import { BusinessInsuranceComponent } from './business-insurance/business-insurance.component';
import { BusinessLegalProtectionComponent } from './business-legal-protection/business-legal-protection.component';
import { NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { ConstructionComponent } from './construction/construction.component';
import { AnimalsWauMiauComponent } from './animals-wau-miau/animals-wau-miau.component';
import { QuotationRequestValuablesComponent } from './quotation-request-valuables/quotation-request-valuables.component';
import { HousingRentalComponent } from './housing-rental/housing-rental.component';
import { NgxIntlTelInputModule } from 'ngx-intl-tel-input';


@NgModule({
  declarations: [
    HealthComponent,
    ListComponent,
    //CarInsuranceComponent,
    MotorVehicleComponent,
    TermLifeComponent,
    GeneralComponent,
    TravelComponent,
    BuildingComponent,
    RcHouseholdComponent,
    FamilyComponent,
    ChildComponent,
    LegalProtectionComponent,
    BvgContractComponent,
    LaaAaComponent,
    LossEarningComponent,
    ThirdPillarComponent,
    SuccessProposalComponent,
    BusinessCompaniesThingsComponent,
    BusinessInsuranceComponent,
    BusinessLegalProtectionComponent,
    ConstructionComponent,
    AnimalsWauMiauComponent,
    QuotationRequestValuablesComponent,
    HousingRentalComponent
  ],
  imports: [
    CommonModule,
    //BrowserModule,
    RequestProposalRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbNavModule,
    NgxIntlTelInputModule
  ]
})
export class RequestProposalModule { }
