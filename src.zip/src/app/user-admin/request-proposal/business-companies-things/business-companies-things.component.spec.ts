import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessCompaniesThingsComponent } from './business-companies-things.component';

describe('BusinessCompaniesThingsComponent', () => {
  let component: BusinessCompaniesThingsComponent;
  let fixture: ComponentFixture<BusinessCompaniesThingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusinessCompaniesThingsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BusinessCompaniesThingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
