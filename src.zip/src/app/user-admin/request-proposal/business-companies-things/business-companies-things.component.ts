import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-business-companies-things',
  templateUrl: './business-companies-things.component.html',
  styleUrls: ['./business-companies-things.component.css']
})
export class BusinessCompaniesThingsComponent implements OnInit  {
  country_List:any=[];

  insuranceType: any='BUSINESS_COMPANY_THINGS';
  partnerId: string;
  memberId: string;
  relation: string;
  
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {}

  CompanyThingsFormGroup = new FormGroup({
    business: new FormControl(""),
    // countryCode:new FormControl("41"),
    // phone:new FormControl("", [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{9,13}$")]),
    countryCode:new FormControl(""),
    phone:new FormControl("", [Validators.required]),
    email:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    streetNo:new FormControl(""),
    zipLocation:new FormControl(""),
    responsible:new FormControl(""),
    startOfContract:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    effectiveDate:new FormControl("", [Validators.required,Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    sectorOfActivity:new FormControl(""),
    noOfEmployee:new FormControl(""),
    turnOver:new FormControl(""),
    payroll:new FormControl(""),
    activityArea:new FormControl(""),
    sumAssured:new FormControl(""),
    details:new FormControl(""),
    goods:new FormControl(""),
    facilities:new FormControl(""),
    lastInsurer:new FormControl(""),
    expiryDate:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    claims:new FormControl(""),
  },{
     updateOn: "change",
   });

  ngOnInit():void{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
    this.getCountries();
  }

  get companyThingsForm() { return this.CompanyThingsFormGroup.controls; }

  saveCompanyThings(){
    if (this.CompanyThingsFormGroup.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    var phone:any=this.CompanyThingsFormGroup.getRawValue().phone;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;

    this.userAuthService.addProposalRequest({
        partnerId:this.partnerId!=null ? this.partnerId:"",
        userId:this.userId,
        agentId:this.agentId!=null ? this.agentId: "",
        memberId: this.memberId,
        memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
        relation: this.relation,
        insuranceType: this.insuranceType,
        metadata: {
          type: this.insuranceType,
          insuredForLegal:"",
          companyDetails: {
            id:"",
            business:this.CompanyThingsFormGroup.getRawValue().business,
            //phone: (this.CompanyThingsFormGroup.getRawValue().phone).toString(),
            //countryCode: countryCode,
            phone: phoneNumber,
            email:this.CompanyThingsFormGroup.getRawValue().email,
            streetNo:this.CompanyThingsFormGroup.getRawValue().streetNo,
            address:"",
            zipLocation:this.CompanyThingsFormGroup.getRawValue().zipLocation,
            responsible:this.CompanyThingsFormGroup.getRawValue().responsible,
            startOfContract:this.CompanyThingsFormGroup.getRawValue().startOfContract,
            typeOfActivity:"",
            socialReason:"",
            effectiveDate:this.CompanyThingsFormGroup.getRawValue().effectiveDate,
          },
          companyLiabilityDetails:{
            sectorOfActivity:this.CompanyThingsFormGroup.getRawValue().sectorOfActivity,
            noOfEmployee:this.CompanyThingsFormGroup.getRawValue().noOfEmployee,
            turnOver:this.CompanyThingsFormGroup.getRawValue().turnOver,
            payroll:this.CompanyThingsFormGroup.getRawValue().payroll,
          },
          propertyDetails:{
            activityArea:this.CompanyThingsFormGroup.getRawValue().activityArea,
            sumAssured:this.CompanyThingsFormGroup.getRawValue().sumAssured,
            details:this.CompanyThingsFormGroup.getRawValue().details,
            goods:this.CompanyThingsFormGroup.getRawValue().goods,
            facilities:this.CompanyThingsFormGroup.getRawValue().facilities,
            lastInsurer:this.CompanyThingsFormGroup.getRawValue().lastInsurer,
            expiryDate:this.CompanyThingsFormGroup.getRawValue().expiryDate,
            claims:this.CompanyThingsFormGroup.getRawValue().claims,
          },
        
        }
      }).subscribe({
      next: (x: any) => {
          this.CompanyThingsFormGroup.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }


  //routerLink="/user/request-proposal/thanks-proposal"


  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries(): void {
    this.userAuthService.getcountries().subscribe({
     next: (x: any) => {
      this.country_List=x.data.countriesList;
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
     },
     complete: () => {
       
     },
   });
 }

 cancelFunction(){
  this.router.navigate(['/user/request-proposal/list']);
}

}
