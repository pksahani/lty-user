import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormGroup} from '@angular/forms';
import {FloatLabelType} from '@angular/material/form-field';
import {FormBuilder} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-health',
  templateUrl: './health.component.html',
  styleUrls: ['./health.component.css']
})
export class HealthComponent implements OnInit {

  email = new FormControl('', [Validators.required, Validators.email]);
  __AddList: any;
  SuccessMessage: string;
  SubmitBtn:boolean=false;
  Models_List:any=['STANDARD','HMO','TELMED','FAMILY DOCTOR'];
  Franchise_List:any=['0 CHF','100 CHF','200 CHF','300 CHF','400 CHF','500 CHF','600 CHF','700 CHF'];
  HealthFund_List:any=[];
  AgeOption_List:any=['0-18 Years','19-25 Years','26 and Above'];
  partnerId: string;
  memberId: string;
  relation: string;
  insuranceType: any='HEALTH';
  _getProfile: any;
  userId: any;
  agentId: any;
  _user: any;
  member_detail: any;
  disabledBtn: boolean=false;
  getErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }
    return this.email.hasError('email') ? 'Not a valid email' : '';
  }

  hide = true;

  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl('auto' as FloatLabelType);


  InsuranceFormGroup = new FormGroup ({
    healthFund: new FormControl('', [Validators.required]),
    postalCode: new FormControl('', [Validators.required]),
    selectAge: new FormControl('', [Validators.required]),
    withAccident: new FormControl('no', [Validators.required]),
    franchise: new FormControl(''),
    models: new FormControl(''),
  });

  constructor(private route:ActivatedRoute, private router:Router, private _formBuilder: FormBuilder, private toastrService:ToastrService, private userAuthService:UserAuthService) {}

ngOnInit(): void {
  this.memberId = this.route.snapshot.paramMap.get('MemberId');
  this.relation = this.route.snapshot.paramMap.get('Mrelation');
  this.getCurrentUser();
  this.GetProfileDetail();
  this.GetStaticDataList();
  
  this.GetmemberDetail();
}

GetStaticDataList():any{
  this._getProfile = this.userAuthService.GetStaticDataList(
    {
      type:'CURRENT_HEALTH_FUND'
    }
  ).subscribe({
    next: (x: any) => {
     this.HealthFund_List=x.data.data;
   
    },
    error: (err: Error) => {
     
      
    },
    complete: () => {
      
    },
  });
}

GetmemberDetail():any{
  this._getProfile = this.userAuthService.getFamilymember(
    {
      familyMemberId:this.memberId
    }
  ).subscribe({
    next: (x: any) => {
     this.member_detail=x.data;
   
    },
    error: (err: Error) => {
     
      
    },
    complete: () => {
      
    },
  });
}

getCurrentUser(): any {
  let data = localStorage.getItem('user');
  if (data != null) {
    this._user = JSON.parse(data);
    console.log(this._user);
  }
  return this._user;
}
  get ProposalError() { return this.InsuranceFormGroup.controls; }
  RequestProposal(): void {
    this.disabledBtn=true;
    if (this.InsuranceFormGroup.invalid ) {
      this.SubmitBtn=true;
      this.disabledBtn=false;
      this.toastrService.error('Please fill All required Field.');
      return;
    }
   
    this.__AddList = this.userAuthService.addProposalRequest({
        partnerId:this.partnerId!=null ? this.partnerId:"",
        userId:this.userId,
        agentId:this.agentId!=null ? this.agentId: "",
        memberId: this.memberId,
        memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
        relation: this.relation,
        insuranceType: this.insuranceType,
        metadata: {
          type: this.insuranceType,
          currenthealthFund: this.InsuranceFormGroup.getRawValue().healthFund,
          postalCode: this.InsuranceFormGroup.getRawValue().postalCode,
          age: this.InsuranceFormGroup.getRawValue().selectAge,
          withAccident: this.InsuranceFormGroup.getRawValue().withAccident,
          models: this.InsuranceFormGroup.getRawValue().models,
          franchise: this.InsuranceFormGroup.getRawValue().franchise
        }
      }
    ).subscribe({
     next: (x: any) => {
      this.SubmitBtn=false;
      //this.member_List=x.data.familyMemberList;
      this.SuccessMessage = 'Proposal Request sent successfully.';
          this.InsuranceFormGroup.reset();
          this.toastrService.success(this.SuccessMessage);
          //$('#addMemberProfile').offcanvas('hide');
          //this.getFamilymembers();
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
       //console.error(err)
       this.toastrService.error(errRes.error.error.clientErrorMessage);
     },
     complete: () => {
       //this.registerSubmitted = false;
     },
   });
  }

  GetProfileDetail(): any {
   
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
        console.log(x.data);
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;
     
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
        
      },
      complete: () => {
        
      },
    });
   
  }

}
