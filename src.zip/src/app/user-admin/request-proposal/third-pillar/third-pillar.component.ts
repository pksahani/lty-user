import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-third-pillar',
  templateUrl: './third-pillar.component.html',
  styleUrls: ['./third-pillar.component.css']
})
export class ThirdPillarComponent implements OnInit  {
  country_List:any=[];
  offerList:any=["Maturity Guarantee","Death Benefit","Maturity and Death"];
  paymentMethodList:any=["Monthly","Quarterly","Semester","Annuel"]
  insuranceType: any='THIRD_PILLAR';
  partnerId: string;
  memberId: string;
  relation: string;
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {}

  thirdPillerForm = new FormGroup({
    title: new FormControl("madam"),
    firstName: new FormControl("", [Validators.required]),
    lastName: new FormControl("", [Validators.required]),
    // countryCode: new FormControl("41", [Validators.required]),
    // mobile: new FormControl("", [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{9,13}$")]),
    countryCode: new FormControl(""),
    mobile: new FormControl("", [Validators.required]),
    dob: new FormControl("",[Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    address: new FormControl(""),
    city:new FormControl("", [Validators.required]),
    postCode:new FormControl("", [Validators.required]),
    nationality: new FormControl("", [Validators.required]),
    //effectiveDate: new FormControl("", [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    //duration: new FormControl("", [Validators.required]),
    whatYouWantInOffer:new FormControl(""),
    doYouWantPremium:new FormControl(""),
    paymentMethod:new FormControl("Monthly"),
    professionalSituation:new FormControl(""),
    job:new FormControl(""),
    areYourDetailsDifferent:new FormControl(""),
    howMuchYouWantToInsure:new FormControl(""),
  },{
     updateOn: "change",
   });
  
  async ngOnInit():Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
    
  }

  get pillarForm() { return this.thirdPillerForm.controls; }

  saveThirdPillarForm(){
    if (this.thirdPillerForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    var phone:any=this.thirdPillerForm.getRawValue().mobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;

    this.userAuthService.addProposalRequest({
      partnerId:this.partnerId!=null ? this.partnerId:"",
      userId:this.userId,
      agentId:this.agentId!=null ? this.agentId: "",
      memberId: this.memberId,
      memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
      relation: this.relation,
      insuranceType: this.insuranceType,
      metadata: {
        type: this.insuranceType,
        whatYouWantInOffer:this.thirdPillerForm.getRawValue().whatYouWantInOffer,
        doYouWantPremium:this.thirdPillerForm.getRawValue().doYouWantPremium,
        paymentMethod:this.thirdPillerForm.getRawValue().paymentMethod,
        professionalSituation:this.thirdPillerForm.getRawValue().professionalSituation,
        job:this.thirdPillerForm.getRawValue().job,
        areYourDetailsDifferent:this.thirdPillerForm.getRawValue().areYourDetailsDifferent,
        howMuchYouWantToInsure:this.thirdPillerForm.getRawValue().howMuchYouWantToInsure,
        personalDetails: {
          title: this.thirdPillerForm.getRawValue().title,
          firstName: this.thirdPillerForm.getRawValue().firstName,
          lastName: this.thirdPillerForm.getRawValue().lastName,
          // countryCode: this.thirdPillerForm.getRawValue().countryCode,
          // mobile: this.thirdPillerForm.getRawValue().mobile,
          countryCode: countryCode,
          mobile: phoneNumber,
          dob: this.thirdPillerForm.getRawValue().dob,
          address: this.thirdPillerForm.getRawValue().address,
          nationality: this.thirdPillerForm.getRawValue().nationality,
          city:this.thirdPillerForm.getRawValue().city,
          postCode:this.thirdPillerForm.getRawValue().postCode,
        }
      }
    }).subscribe({
    next: (x: any) => {
        this.thirdPillerForm.reset();
        this.toastrService.success('Proposal Request submitted successfully.');
        this.router.navigate(['/user/request-proposal/thanks-proposal']);
    },
    error: (err: Error) => {
      let errRes: any;
      errRes = err;
      this.toastrService.error(errRes.error.error.clientErrorMessage);
    },
    complete: () => {
    },
  });
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;

       let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
       this.iso=country[0].sortname;
       this.thirdPillerForm.controls["firstName"].setValue(x.data.firstName);
       this.thirdPillerForm.controls["lastName"].setValue(x.data.lastName);
       this.thirdPillerForm.controls["address"].setValue(x.data.address);
       this.thirdPillerForm.controls["dob"].setValue(x.data.dob);
       this.thirdPillerForm.controls["mobile"].setValue(x.data.mobile); 
       this.thirdPillerForm.controls["postCode"].setValue(x.data.postCode); 
       this.thirdPillerForm.controls["city"].setValue(x.data.city); 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  // getCountries(): void {
  //   this.userAuthService.getcountries().subscribe({
  //    next: (x: any) => {
  //     this.country_List=x.data.countriesList;
  //    },
  //    error: (err: Error) => {
  //      let errRes: any;
  //      errRes = err;
  //    },
  //    complete: () => {
       
  //    },
  //  });
  // }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  
  }

  

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }

 
}
