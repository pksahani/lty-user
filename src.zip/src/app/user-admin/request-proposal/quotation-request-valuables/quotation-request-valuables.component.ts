import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-quotation-request-valuables',
  templateUrl: './quotation-request-valuables.component.html',
  styleUrls: ['./quotation-request-valuables.component.css']
})
export class QuotationRequestValuablesComponent implements OnInit  {
  country_List:any=[];
  durationList:any=["1 Year","2 Years","5 Years"];
  // riskList:any=["1 Family House","Multi-Family House","Second Home","Other"];
  // sumList:any=["CHF 3'000'000","CHF 5'000'000"];
  benefits:any=[];
  typeOfObjects:any=[];
  insuranceType: any='QUOTATION_REQUEST';
  partnerId: string;
  memberId: string;
  relation: string;
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";

  selectedFiles: any;
  profilePic: File;
  _UploadPic: any;
  fileName: any;
  profile_image: string | ArrayBuffer;
  regIdType: any;
  regIdTypeBack: any;
  regIdBack:any="";

  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();

  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {}

  quotationRequestForm = new FormGroup({
    firstName: new FormControl(""),
    lastName: new FormControl(""),
    dob: new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    maritalStatus:new FormControl("Single"),
    address: new FormControl(""),
    nationality: new FormControl(""),
    effectiveDate: new FormControl("", [ Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    duration: new FormControl(""),
    descriptionOfObject: new FormControl(""),
    sumsInsured: new FormControl(""),
    supportingDoc: new FormControl(""),
    areYouPastInsured: new FormControl(""),
    companyName: new FormControl(""),
    policyNo: new FormControl(""),
    reason: new FormControl(""),
    anyClaims: new FormControl(""),
    claimDetails: new FormControl(""),
    wereYouRefusedInsuranceProposal: new FormControl(""),
    remarks:new FormControl(""),
    
  },{
     updateOn: "change",
  });

  async ngOnInit():Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
  }

  get quotForm() { return this.quotationRequestForm.controls; }

  saveQuotationRequestForm(){
    if (this.quotationRequestForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    this.userAuthService.addProposalRequest({
      partnerId:this.partnerId!=null ? this.partnerId:"",
      userId:this.userId,
      agentId:this.agentId!=null ? this.agentId: "",
      memberId: this.memberId,
      memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
      relation: this.relation,
      insuranceType: this.insuranceType,
      metadata: {
        type: this.insuranceType,
        personalDetails: {
          firstName: this.quotationRequestForm.getRawValue().firstName,
          lastName: this.quotationRequestForm.getRawValue().lastName,
          dob: this.quotationRequestForm.getRawValue().dob,
          maritalStatus:this.quotationRequestForm.getRawValue().maritalStatus,
          address: this.quotationRequestForm.getRawValue().address,
          nationality: this.quotationRequestForm.getRawValue().nationality,
          effectiveDate: this.quotationRequestForm.getRawValue().effectiveDate,
          duration: this.quotationRequestForm.getRawValue().duration,
        },
        typeOfObjects:this.typeOfObjects,
        descriptionOfObject:this.quotationRequestForm.getRawValue().descriptionOfObject,
        sumsInsured:this.quotationRequestForm.getRawValue().sumsInsured,
        supportingDoc:this.quotationRequestForm.getRawValue().supportingDoc,
        benefits:this.benefits,
        areYouPastInsured:this.quotationRequestForm.getRawValue().areYouPastInsured,
        companyName:this.quotationRequestForm.getRawValue().companyName,
        policyNo:this.quotationRequestForm.getRawValue().policyNo,
        reason:this.quotationRequestForm.getRawValue().reason,
        anyClaims:this.quotationRequestForm.getRawValue().anyClaims,
        claimDetails:this.quotationRequestForm.getRawValue().claimDetails,
        wereYouRefusedInsuranceProposal:this.quotationRequestForm.getRawValue().wereYouRefusedInsuranceProposal,
        remarks: this.quotationRequestForm.getRawValue().remarks,
      }
    }).subscribe({
      next: (x: any) => {
          this.benefits=[];
          this.typeOfObjects=[];
          this.quotationRequestForm.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
        this.partnerId=x.data.partnerId;
        this.userId=x.data.userId;
        this.agentId=x.data.agentId;
        console.log(x.data);
        let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
        this.iso=country[0].sortname;
       
        this.quotationRequestForm.controls["firstName"].setValue(x.data.firstName);
        this.quotationRequestForm.controls["lastName"].setValue(x.data.lastName);
        this.quotationRequestForm.controls["address"].setValue(x.data.address);
        this.quotationRequestForm.controls["dob"].setValue(x.data.dob);
        this.quotationRequestForm.controls["nationality"].setValue(x.data.nationality);
        this.quotationRequestForm.controls["maritalStatus"].setValue(x.data.maritalStatus);
        //this.quotationRequestForm.controls["duration"].setValue(x.data.duration); 
        this.quotationRequestForm.controls["effectiveDate"].setValue(x.data.effectiveDate);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
           
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }

  setObjectType(items:any){
    if(items.target.checked){
      this.typeOfObjects.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.typeOfObjects.length; i++) {
        let contact= this.typeOfObjects[i];
        if(contact==items.target.value){
          this.typeOfObjects.splice(i, 1);
        }
      }
    }
  }

  setBenefits(items:any){
    if(items.target.checked){
      this.benefits.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.benefits.length; i++) {
        let contact= this.benefits[i];
        if(contact==items.target.value){
          this.benefits.splice(i, 1);
        }
      }
    }
  }

  uploadFile(event:any) {
    this.selectedFiles = event.target.files;
    if (this.selectedFiles !== undefined) {
      this.fileName = this.selectedFiles.item(0)?.name;
      const profile_imageh = event.target.files[0];
      const reader = new FileReader();
      reader.onload = (e) => (this.profile_image = reader.result);
      reader.readAsDataURL(profile_imageh);
    } else {
      this.fileName = "";
    }
    this.updateProfilePic();
  }

  updateProfilePic(type: any = ""): void {
    if (this.selectedFiles) {
      const file: File | null = this.selectedFiles.item(0);
      if (file) {
        this.profilePic = file;
      }
    }
    let docname = "Quotation supporting Doc";
   
    this._UploadPic = this.userAuthService
      .UploadDocument({
        docName: docname,
        userId: "",
        doc: this.profilePic,
        memberId: "",
      })
      .subscribe({
        next: (result: any) => {
         
          var myarr1:any;
          if(result.data.docUrl!=null && result.data.docUrl!=""){
            myarr1 = result.data.docUrl.split("/");
            var myimg1 = myarr1[myarr1.length - 1] ? myarr1[myarr1.length - 1] : "";
            var myimgg1= myimg1.split(".");
            this.regIdTypeBack = myimgg1[myimgg1.length - 1] ? myimgg1[myimgg1.length - 1] : "";
          }
          this.regIdBack=result.data.docUrl;
          this.quotationRequestForm.controls["supportingDoc"].setValue(result.data.docUrl);
          return;
        },
        error: (err: any) => {
          if (err.error.error.profile_pic) {
            this.toastrService.error(err.error.error.profile_pic, "");
          } else {
            this.toastrService.error(err.error.message, "");
          }
        },
        complete: () => {},
      });
  }

  


 

}
