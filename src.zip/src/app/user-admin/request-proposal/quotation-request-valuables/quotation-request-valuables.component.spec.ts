import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotationRequestValuablesComponent } from './quotation-request-valuables.component';

describe('QuotationRequestValuablesComponent', () => {
  let component: QuotationRequestValuablesComponent;
  let fixture: ComponentFixture<QuotationRequestValuablesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuotationRequestValuablesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuotationRequestValuablesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
