import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalsWauMiauComponent } from './animals-wau-miau.component';

describe('AnimalsWauMiauComponent', () => {
  let component: AnimalsWauMiauComponent;
  let fixture: ComponentFixture<AnimalsWauMiauComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnimalsWauMiauComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AnimalsWauMiauComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
