import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';


@Component({
  selector: 'app-travel',
  templateUrl: './travel.component.html',
  styleUrls: ['./travel.component.css']
})
export class TravelComponent implements OnInit  {
  country_List:any=[];
  desiredCovers:any=[];

  insuranceType: any='TRAVEL';
  partnerId: string;
  memberId: string;
  relation: string;
  
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;


  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {

  }

  travelInsuranceForm = new FormGroup({
    personsToBeInsured: new FormControl("individual", [Validators.required]),
    adultsCount: new FormControl(""),
    childrenCount: new FormControl(""),
    title: new FormControl(""),
    firstName: new FormControl("", [Validators.required]),
    lastName: new FormControl("", [Validators.required]),
    // countryCode: new FormControl("41", [Validators.required]),
    // mobile: new FormControl("", [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{9,13}$")]),
    countryCode: new FormControl(""),
    mobile: new FormControl("", [Validators.required]),
    dob: new FormControl("",[Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    address: new FormControl("", [Validators.required]),
    nationality: new FormControl("", [Validators.required]),
    effectiveDate: new FormControl("", [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    duration: new FormControl("", [Validators.required]),
  },{
     updateOn: "change",
  });

  async ngOnInit(): Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
    
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;
       
       let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
       this.iso=country[0].sortname;
       this.travelInsuranceForm.controls["firstName"].setValue(x.data.firstName);
       this.travelInsuranceForm.controls["lastName"].setValue(x.data.lastName);
       this.travelInsuranceForm.controls["address"].setValue(x.data.address);
       this.travelInsuranceForm.controls["dob"].setValue(x.data.dob);
       this.travelInsuranceForm.controls["mobile"].setValue(x.data.mobile); 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  get travelForm() { return this.travelInsuranceForm.controls; }

  savetravelInsurance(){
    if (this.travelInsuranceForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    var phone:any=this.travelInsuranceForm.getRawValue().mobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;

    this.userAuthService.addProposalRequest({
        partnerId:this.partnerId!=null ? this.partnerId:"",
        userId:this.userId,
        agentId:this.agentId!=null ? this.agentId: "",
        memberId: this.memberId,
        memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
        relation: this.relation,
        insuranceType: this.insuranceType,
        metadata: {
          type: this.insuranceType,
          personsToBeInsured: this.travelInsuranceForm.getRawValue().personsToBeInsured,
          adultsCount: this.travelInsuranceForm.getRawValue().adultsCount,
          childrenCount: this.travelInsuranceForm.getRawValue().childrenCount,
          desiredCovers:this.desiredCovers,
          personalDetails: {
            title: this.travelInsuranceForm.getRawValue().title,
            firstName: this.travelInsuranceForm.getRawValue().firstName,
            lastName: this.travelInsuranceForm.getRawValue().lastName,
            // countryCode: this.travelInsuranceForm.getRawValue().countryCode,
            // mobile: this.travelInsuranceForm.getRawValue().mobile,
            countryCode: countryCode,
            mobile: phoneNumber,
            dob: this.travelInsuranceForm.getRawValue().dob,
            address: this.travelInsuranceForm.getRawValue().address,
            nationality: this.travelInsuranceForm.getRawValue().nationality,
            effectiveDate: this.travelInsuranceForm.getRawValue().effectiveDate,
            duration: this.travelInsuranceForm.getRawValue().duration,
          }
        }
      }).subscribe({
      next: (x: any) => {
          this.desiredCovers=[];
          this.travelInsuranceForm.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }

//   getCountries(): void {
//     this.userAuthService.getcountries().subscribe({
//      next: (x: any) => {
//       this.country_List=x.data.countriesList;
//      },
//      error: (err: Error) => {
//        let errRes: any;
//        errRes = err;
//      },
//      complete: () => {
       
//      },
//    });
//  }

getCountries():  Promise<any> {
  return new Promise((resolve, reject) => {
    this.userAuthService.getcountries().subscribe({
        next: (result: any) => {
          return resolve(result.data.countriesList);
        },
        error: (err: any) => {
          return reject(err.error);
        },
        complete: () => {
        }
    }); 
  });
}

  setdesiredCovers(items:any){
    if(items.target.checked){
      this.desiredCovers.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.desiredCovers.length; i++) {
        let contact= this.desiredCovers[i];
        if(contact==items.target.value){
          this.desiredCovers.splice(i, 1);
        }
      }
    }
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }
    

}



