import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestProposalListComponent } from './request-proposal-list.component';

describe('RequestProposalListComponent', () => {
  let component: RequestProposalListComponent;
  let fixture: ComponentFixture<RequestProposalListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestProposalListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestProposalListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
