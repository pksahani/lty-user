import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserAuthService } from 'src/app/_services/user-auth.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

Relation_list:any=['SELF','FATHER','MOTHER','SPOUSE','CHILDREN'];
  __MemberList: any;
  member_List: any=[];
  searchMemberType:any="";
  searchMember:any="";
  constructor(private userAuthService:UserAuthService, private router:Router, private toasterService:ToastrService){

  }
  ngOnInit():void{
    window.scroll(0, 0);
    this.getFamilymembers();
  }

  GoToPermlainks(insurance:string){
    console.log(this.searchMemberType);
if(this.searchMemberType=='' || this.searchMember==''){
this.toasterService.error('Please select the Relation and Member');
return;
}

    let insurancetype='/user/request-proposal/'+insurance+'/'+this.searchMemberType+'/'+this.searchMember;

    this.router.navigate([insurancetype]);
  }

  getFamilymembers(): void {
    console.log(this.searchMemberType);
    this.__MemberList = this.userAuthService.getFamilymembers({
      relation:this.searchMemberType
    }).subscribe({
     next: (x: any) => {
      this.member_List=x.data.familyMemberList;
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
       console.error(err)
       
     },
     complete: () => {
       //this.registerSubmitted = false;
     },
   });
 }
}
