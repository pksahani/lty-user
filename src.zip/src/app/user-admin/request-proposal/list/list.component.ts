import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { NgbNavConfig, NgbNavModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

Relation_list:any=['SELF','SPOUSE','CHILDREN'];
  __MemberList: any;
  member_List: any=[];
  searchMemberType:any="SELF";
  searchMember:any="";
  _user:any;
  userId:any;
  userType:any="";
  activeId:any;
  userProfile:any;
  constructor(config: NgbNavConfig,private userAuthService:UserAuthService, private router:Router, private toasterService:ToastrService){
  config.destroyOnHide = false;
  config.roles = false;
  }
  ngOnInit():void{
    window.scroll(0, 0);
    this.getCurrentUser();
    this.GetProfileDetail();
    this.getFamilymembers();
    
    
  }

  GoToPermlainks(insurance:string){
    if(this.userProfile.postCode==null || this.userProfile==undefined || this.userProfile==''){
      this.toasterService.error('Please Complete your profile before sending proposal request.');
      return;
    }

    if(this.searchMemberType=='' || this.searchMember==''){
    this.toasterService.error('Please select the Relation and Member');
    return;
    }
    let insurancetype='/user/request-proposal/'+insurance+'/'+this.searchMemberType+'/'+this.searchMember;
    this.router.navigate([insurancetype]);
  }

  getFamilymembers(): void {
     
      this.__MemberList = this.userAuthService.getFamilymembers({
        relation:this.searchMemberType
      }).subscribe({
      next: (x: any) => {
        this.member_List=x.data.familyMemberList;
        console.log(x.data.familyMemberList);
        if(x.data.familyMemberList.length>0){
          for(var i=0;i<this.member_List.length;i++){
            if(this.member_List[i].userId==this.userId){
              this.searchMember= this.member_List[i].familyMemberId;
            }else{
              this.searchMember="";
            }
          }
        }else{
          this.searchMember="";
        }
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
      },
      complete: () => {
      },
    });
  }



 getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
      this.userId=this._user.userId
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this.userAuthService.getuserByToken({
        token:this._user.token
      }).subscribe({
      next: (x: any) => {
       this.userType=x.data.type;
       this.userProfile=x.data;
       if(this.userType!='Company'){
          this.activeId=1;
        }else{
          this.activeId=2;
        }

      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }


}

