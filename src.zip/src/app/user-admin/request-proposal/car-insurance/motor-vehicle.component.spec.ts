import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorVehicleComponent } from './car-insurance.component';

describe('MotorVehicleComponent', () => {
  let component: MotorVehicleComponent;
  let fixture: ComponentFixture<MotorVehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorVehicleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MotorVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
