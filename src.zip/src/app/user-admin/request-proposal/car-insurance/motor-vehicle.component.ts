import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';


@Component({
  selector: 'app-motor-vehicle',
  templateUrl: './motor-vehicle.component.html',
  styleUrls: ['./motor-vehicle.component.css']
})
export class MotorVehicleComponent  implements OnInit {
  country_List:any=[];
  damageIn:any=[];
  insuranceType: any='MOTOR_VEHICLE';
  reqTypeList:any=["New Business","Change of Vehicle","IP Setup","Company Change","Plates Number"];
  vehicleTypeList:any=["SUV","Hatchback","Crossover","Convertible","Sedan","Sports Car","Coupe","Minivan","Station Wagon","Pickup Truck"];
  brandBrandList:any=["Toyota","Maruti Suzuki","Hyundai","Tata Motors","Mahindra","Honda","Skoda","Volkswagen","Kia"];
  garageClosedList:any=["Non"," At Home","At Work","At Home and Work"];
  partnerId: string;
  memberId: string;
  relation: string;
  
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  selectedFiles: any;
  profilePic: File;
  _UploadPic: any;
  fileName: any;
  profile_image: string | ArrayBuffer;
  regIdType: any;
  regIdTypeBack: any;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";
  
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {
  }

  vehicleInsuranceForm = new FormGroup({
    reqType:new FormControl("New Business"),
    effectiveDate: new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    firstName: new FormControl("", [Validators.required]),
    lastName: new FormControl("", [Validators.required]),
    dob: new FormControl("",[Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    nationality: new FormControl("", [Validators.required]),
    address: new FormControl("", [Validators.required]),
    drivingLicenseDate:new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    paymentMethod:new FormControl("annual"),
    sourceOfFunding:new FormControl(""),
    leasingInstitution:new FormControl(""),
    contractNumber:new FormControl(""),
    otherDrivers:new FormControl(""),

    driverName:new FormControl(""),//not verified
    driverNumber:new FormControl(""),//not verified
    driverAddress:new FormControl(""),//not verified

    otherDriversOutsideCommonHousehold:new FormControl(""),
    anyDriversWithProvisionalLicense:new FormControl(""),
    haveGrayCard:new FormControl(""),
    attachCard:new FormControl(""),

    vehicleType:new FormControl("SUV"), //vehicle
    brandBrand:new FormControl("Toyota"), //vehicle
    registrationNumber:new FormControl(""), //vehicle
    placesNumber:new FormControl(""), //vehicle
    approvalNumber:new FormControl(""), //vehicle
    espSystem:new FormControl(""), //vehicle
    displacement:new FormControl(""), //vehicle
    oneTimeRelese:new FormControl(""), //vehicle
    priceCatelogue:new FormControl(""), //vehicle
    accessoriesPrice:new FormControl(""), //vehicle
    uploadWeight:new FormControl(""), //vehicle
    totalWeight:new FormControl(""), //vehicle
    garageClosed:new FormControl(""), //vehicle
    useOfVehicle:new FormControl(""), //vehicle
    annualMileage:new FormControl(""), //vehicle
    meterReading:new FormControl(""), //vehicle

    isSecondVehicleInsured:new FormControl(""),
    secondVehicleHaveGrayCard:new FormControl(""),
    attachSecondVehicleCard:new FormControl(""),

    vehicleType2:new FormControl("SUV"), //vehicle2
    brandBrand2:new FormControl("Toyota"), //vehicle2
    registrationNumber2:new FormControl(""), //vehicle2
    placesNumber2:new FormControl(""), //vehicle2
    approvalNumber2:new FormControl(""), //vehicle2
    espSystem2:new FormControl(""), //vehicle2
    displacement2:new FormControl(""), //vehicle2
    oneTimeRelese2:new FormControl(""), //vehicle2
    priceCatelogue2:new FormControl(""), //vehicle2
    accessoriesPrice2:new FormControl(""), //vehicle2
    uploadWeight2:new FormControl(""), //vehicle2
    totalWeight2:new FormControl(""), //vehicle2
    garageClosed2:new FormControl(""), //vehicle2
    useOfVehicle2:new FormControl(""), //vehicle2
    annualMileage2:new FormControl(""), //vehicle2
    meterReading2:new FormControl(""), //vehicle2

    areYouInsuredAsVehicleOwner:new FormControl(""),
    holderName:new FormControl(""), //vehicle owner
    companyName:new FormControl(""), //vehicle owner
    policyNo:new FormControl(""), //vehicle owner

    policyReplacedByAnotherCompany:new FormControl(""),
    licenceWithdrawn:new FormControl(""),

    reason:new FormControl(""), //LicenceWithdrawnDetails 
    duration:new FormControl(""), //LicenceWithdrawnDetails 
    amount:new FormControl(""), //LicenceWithdrawnDetails 

    involvedInTrafficAccident:new FormControl(""),

    date:new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),  //TrafficAccidentDetails 
    amount_traficAccident:new FormControl(""), //TrafficAccidentDetails 
    responsible:new FormControl(""), //TrafficAccidentDetails 
    in:new FormControl(""),   //TrafficAccidentDetails 

    alreadySufferedDamage:new FormControl(""),
    //in:new FormControl("") //checkbox array //SufferedDamageDetails 
    date_sufferDamage:new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),  //SufferedDamageDetails 
    amount_sufferDamage:new FormControl(""), //SufferedDamageDetails 

    bonusProtection:new FormControl(""),
    coverage:new FormControl(""),
    casco:new FormControl(""),
    cascoBonusProtection:new FormControl(""),
    parkingDamage:new FormControl(""),
    singleParkingDamage:new FormControl(""),
    headlightCover:new FormControl(""),
    freeChoiceOfGarage:new FormControl(""),
    replacementVehicleRental:new FormControl(""),
    partialCasco:new FormControl(""),
    personalEffects:new FormControl(""),
    personalEffectsValue:new FormControl(""),
    occupantProtection:new FormControl(""),
    waiverOfRecourse:new FormControl(""),
    remarks:new FormControl(""),

  },{
     updateOn: "change",
   });

  async ngOnInit(): Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
  }

  get vehicleForm() { return this.vehicleInsuranceForm.controls; }

  saveVehicleInsurance(){
    if (this.vehicleInsuranceForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    var driverPhone:any=this.vehicleInsuranceForm.getRawValue().driverNumber;
    var driverCountryCode=(driverPhone.dialCode);
    var driverPhoneNumber=driverPhone.number;

    this.userAuthService.addProposalRequest({
      partnerId:this.partnerId!=null ? this.partnerId:"",
      userId:this.userId,
      agentId:this.agentId!=null ? this.agentId: "",
      memberId: this.memberId,
      memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
      relation: this.relation,
      insuranceType: this.insuranceType,
      metadata: {
        type: this.insuranceType,
        reqType:this.vehicleInsuranceForm.getRawValue().reqType,
        personalDetails: {
          firstName: this.vehicleInsuranceForm.getRawValue().firstName,
          lastName: this.vehicleInsuranceForm.getRawValue().lastName,
          dob: this.vehicleInsuranceForm.getRawValue().dob,
          address: this.vehicleInsuranceForm.getRawValue().address,
          nationality: this.vehicleInsuranceForm.getRawValue().nationality,
          effectiveDate: this.vehicleInsuranceForm.getRawValue().effectiveDate
        },
        drivingLicenseDate: this.vehicleInsuranceForm.getRawValue().drivingLicenseDate,
        paymentMethod: this.vehicleInsuranceForm.getRawValue().paymentMethod,
        sourceOfFunding: this.vehicleInsuranceForm.getRawValue().sourceOfFunding,
        nameOfInstitution: this.vehicleInsuranceForm.getRawValue().leasingInstitution,
        contractNumber: this.vehicleInsuranceForm.getRawValue().contractNumber,
        otherDrivers: this.vehicleInsuranceForm.getRawValue().otherDrivers,
        driverInfo:{
          name:this.vehicleInsuranceForm.getRawValue().driverName,
          contactNumber:driverPhoneNumber, 
          address:this.vehicleInsuranceForm.getRawValue().driverAddress
        },
        otherDriversOutsideCommonHousehold:this.vehicleInsuranceForm.getRawValue().otherDriversOutsideCommonHousehold,
        anyDriversWithProvisionalLicense:this.vehicleInsuranceForm.getRawValue().anyDriversWithProvisionalLicense,
        haveGrayCard:this.vehicleInsuranceForm.getRawValue().haveGrayCard,
        attachCard:this.vehicleInsuranceForm.getRawValue().attachCard,
        vehicleDetails:{
          vehicleType:this.vehicleInsuranceForm.getRawValue().vehicleType,
          brandBrand:this.vehicleInsuranceForm.getRawValue().brandBrand,
          registrationNumber:this.vehicleInsuranceForm.getRawValue().registrationNumber,
          placesNumber:this.vehicleInsuranceForm.getRawValue().placesNumber,
          approvalNumber:this.vehicleInsuranceForm.getRawValue().approvalNumber,
          espSystem:this.vehicleInsuranceForm.getRawValue().espSystem,
          displacement:this.vehicleInsuranceForm.getRawValue().displacement,
          oneTimeRelese:this.vehicleInsuranceForm.getRawValue().oneTimeRelese,
          priceCatelogue:this.vehicleInsuranceForm.getRawValue().priceCatelogue,
          accessoriesPrice:this.vehicleInsuranceForm.getRawValue().accessoriesPrice,
          uploadWeight:this.vehicleInsuranceForm.getRawValue().uploadWeight,
          totalWeight:this.vehicleInsuranceForm.getRawValue().totalWeight,
          garageClosed:this.vehicleInsuranceForm.getRawValue().garageClosed,
          useOfVehicle:this.vehicleInsuranceForm.getRawValue().useOfVehicle,
          annualMileage:this.vehicleInsuranceForm.getRawValue().annualMileage,
          meterReading:this.vehicleInsuranceForm.getRawValue().meterReading
        },
        isSecondVehicleInsured:this.vehicleInsuranceForm.getRawValue().isSecondVehicleInsured,
        secondVehicleHaveGrayCard:this.vehicleInsuranceForm.getRawValue().secondVehicleHaveGrayCard,
        attachSecondVehicleCard:this.vehicleInsuranceForm.getRawValue().attachSecondVehicleCard, //pending
        secondVehicleDetails:{
          vehicleType:this.vehicleInsuranceForm.getRawValue().vehicleType2,
          brandBrand:this.vehicleInsuranceForm.getRawValue().brandBrand,
          registrationNumber:this.vehicleInsuranceForm.getRawValue().registrationNumber2,
          placesNumber:this.vehicleInsuranceForm.getRawValue().placesNumber2,
          approvalNumber:this.vehicleInsuranceForm.getRawValue().approvalNumber2,
          espSystem:this.vehicleInsuranceForm.getRawValue().espSystem2,
          displacement:this.vehicleInsuranceForm.getRawValue().displacement2,
          oneTimeRelese:this.vehicleInsuranceForm.getRawValue().oneTimeRelese2,
          priceCatelogue:this.vehicleInsuranceForm.getRawValue().priceCatelogue2,
          accessoriesPrice:this.vehicleInsuranceForm.getRawValue().accessoriesPrice2,
          uploadWeight:this.vehicleInsuranceForm.getRawValue().uploadWeight2,
          totalWeight:this.vehicleInsuranceForm.getRawValue().totalWeight2,
          garageClosed:this.vehicleInsuranceForm.getRawValue().garageClosed2,
          useOfVehicle:this.vehicleInsuranceForm.getRawValue().useOfVehicle2,
          annualMileage:this.vehicleInsuranceForm.getRawValue().annualMileage2,
          meterReading:this.vehicleInsuranceForm.getRawValue().meterReading2
        },
        areYouInsuredAsVehicleOwner:this.vehicleInsuranceForm.getRawValue().areYouInsuredAsVehicleOwner,
        vehicleOwnerDetails:{
          holderName:this.vehicleInsuranceForm.getRawValue().holderName,
          companyName:this.vehicleInsuranceForm.getRawValue().companyName,
          policyNo:this.vehicleInsuranceForm.getRawValue().policyNo
        },
        policyReplacedByAnotherCompany:this.vehicleInsuranceForm.getRawValue().policyReplacedByAnotherCompany,
        licenceWithdrawn:this.vehicleInsuranceForm.getRawValue().licenceWithdrawn,
        licenceWithdrawnDetails:{
          reason:this.vehicleInsuranceForm.getRawValue().reason,
          duration:this.vehicleInsuranceForm.getRawValue().duration,
          amount:this.vehicleInsuranceForm.getRawValue().amount
        },
        involvedInTrafficAccident:this.vehicleInsuranceForm.getRawValue().involvedInTrafficAccident,
        trafficAccidentDetails:{
          date:this.vehicleInsuranceForm.getRawValue().date,
          amount:this.vehicleInsuranceForm.getRawValue().amount_traficAccident,
          responsible:this.vehicleInsuranceForm.getRawValue().responsible,
          in:this.vehicleInsuranceForm.getRawValue().in
        },
        alreadySufferedDamage:this.vehicleInsuranceForm.getRawValue().alreadySufferedDamage,
        sufferedDamageDetails:{
          in:this.damageIn,
          date:this.vehicleInsuranceForm.getRawValue().date_sufferDamage,
          amount:this.vehicleInsuranceForm.getRawValue().amount_sufferDamage,
        },
        bonusProtection:this.vehicleInsuranceForm.getRawValue().bonusProtection,
        coverage:this.vehicleInsuranceForm.getRawValue().coverage,
        casco:this.vehicleInsuranceForm.getRawValue().casco,
        cascoBonusProtection:this.vehicleInsuranceForm.getRawValue().cascoBonusProtection,
        parkingDamage:this.vehicleInsuranceForm.getRawValue().parkingDamage,
        singleParkingDamage:this.vehicleInsuranceForm.getRawValue().singleParkingDamage,
        headlightCover:this.vehicleInsuranceForm.getRawValue().headlightCover,
        freeChoiceOfGarage:this.vehicleInsuranceForm.getRawValue().freeChoiceOfGarage,
        replacementVehicleRental:this.vehicleInsuranceForm.getRawValue().replacementVehicleRental,
        partialCasco:this.vehicleInsuranceForm.getRawValue().partialCasco,
        personalEffects:this.vehicleInsuranceForm.getRawValue().personalEffects,
        personalEffectsValue:this.vehicleInsuranceForm.getRawValue().personalEffectsValue,
        occupantProtection:this.vehicleInsuranceForm.getRawValue().occupantProtection,
        waiverOfRecourse:this.vehicleInsuranceForm.getRawValue().waiverOfRecourse,
        remarks:this.vehicleInsuranceForm.getRawValue().remarks,
      }
    }).subscribe({
      next: (x: any) => {
          this.damageIn=[];
          this.vehicleInsuranceForm.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {},
    });

  }

  setDamageIn(items:any){
    if(items.target.checked){
      this.damageIn.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.damageIn.length; i++) {
        let contact= this.damageIn[i];
        if(contact==items.target.value){
          this.damageIn.splice(i, 1);
        }
      }
    }
  }


  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;
       
       let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
      //  this.iso=country[0].sortname;
       this.vehicleInsuranceForm.controls["firstName"].setValue(x.data.firstName);
       this.vehicleInsuranceForm.controls["lastName"].setValue(x.data.lastName);
       this.vehicleInsuranceForm.controls["address"].setValue(x.data.address);
       this.vehicleInsuranceForm.controls["dob"].setValue(x.data.dob);
       this.vehicleInsuranceForm.controls["nationality"].setValue(x.data.nationality);
      //  this.travelInsuranceForm.controls["mobile"].setValue(x.data.mobile); 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }


  uploadFile(event:any) {
    this.selectedFiles = event.target.files;
    if (this.selectedFiles !== undefined) {
      this.fileName = this.selectedFiles.item(0)?.name;
      const profile_imageh = event.target.files[0];
      const reader = new FileReader();
      reader.onload = (e) => (this.profile_image = reader.result);
      reader.readAsDataURL(profile_imageh);
    } else {
      this.fileName = "";
    }
    let type="attachCard";
    this.updateProfilePic();
  }

  uploadFile2(event:any) {
    this.selectedFiles = event.target.files;
    if (this.selectedFiles !== undefined) {
      this.fileName = this.selectedFiles.item(0)?.name;
      const profile_imageh = event.target.files[0];
      const reader = new FileReader();
      reader.onload = (e) => (this.profile_image = reader.result);
      reader.readAsDataURL(profile_imageh);
    } else {
      this.fileName = "";
    }
    let type="attachSecondVehicleCard";
    this.updateProfilePic();
  }

  updateProfilePic(type: any = ""): void {
    if (this.selectedFiles) {
      const file: File | null = this.selectedFiles.item(0);
      if (file) {
        this.profilePic = file;
      }
    }

    let docname = "";
    if (type == "attachCard") {
      docname = "Attach Card";
    }else if(type=="attachSecondVehicleCard"){
      docname = "Attach second vehecle Card";
    } else {
      docname = "other";
    }
    this._UploadPic = this.userAuthService
      .UploadDocument({
        docName: docname,
        userId: "",
        doc: this.profilePic,
        memberId: "",
      })
      .subscribe({
        next: (result: any) => {
          if(type=="attachCard"){
            this.vehicleInsuranceForm.controls["attachCard"].setValue(result.data.docUrl);
          }else if(type=="attachSecondVehicleCard"){
            this.vehicleInsuranceForm.controls["attachSecondVehicleCard"].setValue(result.data.docUrl);
          }
          return;
        },
        error: (err: any) => {
          if (err.error.error.profile_pic) {
            this.toastrService.error(err.error.error.profile_pic, "");
          } else {
            this.toastrService.error(err.error.message, "");
          }
        },
        complete: () => {},
      });
  }



}

