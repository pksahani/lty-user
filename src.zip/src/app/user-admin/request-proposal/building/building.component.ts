import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-building',
  templateUrl: './building.component.html',
  styleUrls: ['./building.component.css']
})
export class BuildingComponent implements OnInit  {
  durationList:any=["1 Year","2 Year","5 Year"];
  buildingTypeList:any=["Rental Property","Terraced House"," Underground Car Park","1 Family House","Multi-Family House","Second Home"," Other"];
  securityList:any=['Fire Alarm With','Fire Alarm Without'];
  heatingSystemList:any=["Floor Heating","Ceiling Heating","Floor and ceiling heating","Other"];
  benefitList:any=['Fire/natural events','Flight','Water damage',' Broken glass','Earthquake','Technical installations','Casco cultures (gardens, hut, bushes, …)'];
  sumList:any=[' CHF 2,000,000'," CHF 3'000'000","CHF 5'000'000"," CHF 10'000'000"];
  franchiseList:any=["CHF 200","CHF 500"];

  benefits:any=[];
  insuranceType: any='BUILDING';
  partnerId: string;
  memberId: string;
  relation: string;
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {

  }
  buildingInsuranceForm=new FormGroup({
    firstName: new FormControl("", [Validators.required]),
    lastName: new FormControl("", [Validators.required]),
    dob: new FormControl("",[Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    address: new FormControl("", [Validators.required]),
    nationality: new FormControl("", [Validators.required]),
    effectiveDate: new FormControl("", [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    duration: new FormControl("", [Validators.required]),
    civilStatus:new FormControl("", [Validators.required]),
    buildingType:new FormControl(""),
    securityMeasures:new FormControl(""),
    heatingSystem:new FormControl(""),
    sumInsured:new FormControl(""),
    yearOfConstruction:new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    typeOfConstruction:new FormControl(""),
    typeOfRoof:new FormControl(""),
    sum:new FormControl(""),
    franchise:new FormControl(""),
    use:new FormControl("", [Validators.required]),
    noOfApartment:new FormControl("", [Validators.required]),
    noOfTrade:new FormControl("", [Validators.required]),
    commercialArea:new FormControl("", [Validators.required]),
    pastInsured:new FormControl(""),
    companyName:new FormControl(""),
    reason:new FormControl(""),
    anyClaims:new FormControl(""),
    claimDetails:new FormControl(""),
    remarks:new FormControl(""),
    spacifyClaim:new FormControl(""),
  },{
     updateOn: "change",
   });

  ngOnInit():void{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
    
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;

       this.buildingInsuranceForm.controls["firstName"].setValue(x.data.firstName);
       this.buildingInsuranceForm.controls["lastName"].setValue(x.data.lastName);
       this.buildingInsuranceForm.controls["address"].setValue(x.data.address);
       this.buildingInsuranceForm.controls["dob"].setValue(x.data.dob);
       //this.buildingInsuranceForm.controls["mobile"].setValue(x.data.mobile); 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  get buildingForm() { return this.buildingInsuranceForm.controls; }

  saveBuildingInsurance(){

    if (this.buildingInsuranceForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    var sum:any=[];
    if(this.buildingInsuranceForm.getRawValue().sum!=""){ 
      sum.push(this.buildingInsuranceForm.getRawValue().sum);
    }
    var franchise:any=[];
    if(this.buildingInsuranceForm.getRawValue().franchise!=""){
      franchise.push(this.buildingInsuranceForm.getRawValue().franchise);
    }
    

    this.userAuthService.addProposalRequest({
        partnerId:this.partnerId!=null ? this.partnerId:"",
        userId:this.userId,
        agentId:this.agentId!=null ? this.agentId: "",
        memberId: this.memberId,
        memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
        relation: this.relation,
        insuranceType: this.insuranceType,
        metadata: {
          type: this.insuranceType,
          buildingType:this.buildingInsuranceForm.getRawValue().buildingType,
          securityMeasures:this.buildingInsuranceForm.getRawValue().securityMeasures,
          heatingSystem:this.buildingInsuranceForm.getRawValue().heatingSystem,
          sumInsured:this.buildingInsuranceForm.getRawValue().sumInsured,
          yearOfConstruction:this.buildingInsuranceForm.getRawValue().yearOfConstruction,
          typeOfConstruction:this.buildingInsuranceForm.getRawValue().typeOfConstruction,
          typeOfRoof:this.buildingInsuranceForm.getRawValue().typeOfRoof,
          benefits:this.benefits,
          sum:this.buildingInsuranceForm.getRawValue().sum,
          franchise:this.buildingInsuranceForm.getRawValue().franchise,
          use:this.buildingInsuranceForm.getRawValue().use,
          noOfApartment:this.buildingInsuranceForm.getRawValue().noOfApartment,
          noOfTrade:this.buildingInsuranceForm.getRawValue().noOfTrade,
          commercialArea:this.buildingInsuranceForm.getRawValue().commercialArea,
          pastInsured:this.buildingInsuranceForm.getRawValue().pastInsured,
          companyName:this.buildingInsuranceForm.getRawValue().companyName,
          reason:this.buildingInsuranceForm.getRawValue().reason,
          anyClaims:this.buildingInsuranceForm.getRawValue().anyClaims,
          claimDetails:this.buildingInsuranceForm.getRawValue().claimDetails,
          remarks:this.buildingInsuranceForm.getRawValue().remarks,
          personalDetails: {
            title:"",
            firstName: this.buildingInsuranceForm.getRawValue().firstName,
            lastName: this.buildingInsuranceForm.getRawValue().lastName,
            dob: this.buildingInsuranceForm.getRawValue().dob,
            address: this.buildingInsuranceForm.getRawValue().address,
            nationality: this.buildingInsuranceForm.getRawValue().nationality,
            effectiveDate: this.buildingInsuranceForm.getRawValue().effectiveDate,
            duration: this.buildingInsuranceForm.getRawValue().duration,
            civilStatus:this.buildingInsuranceForm.getRawValue().civilStatus,
          }
        }
      }).subscribe({
      next: (x: any) => {
          this.benefits=[];
          this.buildingInsuranceForm.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });

  }


  //routerLink="/user/request-proposal/thanks-proposal"

  setBenefits(items:any){
    if(items.target.checked){
      this.benefits.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.benefits.length; i++) {
        let contact= this.benefits[i];
        if(contact==items.target.value){
          this.benefits.splice(i, 1);
        }
      }
    }
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }
 
  
}



