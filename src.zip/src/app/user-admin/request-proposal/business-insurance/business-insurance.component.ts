import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, FormArray} from '@angular/forms';

@Component({
  selector: 'app-business-insurance',
  templateUrl: './business-insurance.component.html',
  styleUrls: ['./business-insurance.component.css']
})
export class BusinessInsuranceComponent implements OnInit  {

  ngOnInit():void{
    window.scroll(0, 0);
  }

  businessInsurance = this._formBuilder.group({
    id:'',
    email:'',
    address:'',
    zipLocation:'',
    activeType:'',
    socialReason:'',
    policyNumber:'',
    near:'',
    allowanceDate:'',
    insuredCircle:'',
    annualSalary:'',
    salariesMan:'',
    salariesWomen:'',
    salaryCoverage:'',
    salaryCoverage1:'',
    salaryCoverage2:'',
    waitingDays:'',
    otherOption:'',
    maternitySupplement:'',
    blanket:'',
    lastName:'',
    firstName:'',
    dob:'',
    selfEmail:'',
    conventionalSalary:'',
    subjectAvs:'',
    accidentCover:'',
    participateSurpluses:'',
    desiredEntry:'',
    ubgPolicyNumber:'',
    ubgAllowanceDate:'',
    ubgNear:'',
    apInsuredCircle:'',
    apAnnualSalary:'',
    apSalariesMan:'',
    apSalariesWomen:'',
    apDesiredEntry:'',
    waitingTime:'',
    waitingTime1:'',
    accidentCoverAi:'',
    waitingTimeDays:'',
    insuredSalary:'',
    cointactLenght:'',
    contractLenght1:'',
    laaPolicyNumber:'',
    laaallowanceDate:'',
    laanear:'',
    insuredCircleLaa:'',
    annualSalaryLaa:'',
    salariesManLaa:'',
    salariesWomenLaa:'',
    processingFee:'',
    privateRoom:'',
    semiPrivateRoom:'',
    dailyAllowance2Days:'',
    dailyAllowance:'',
    waitingDaysTime:'',
    intoForce:'',
    salaryCoverageAi:'',
    additionalGuarantee:'',
    uvg:'',
    disabilityLumpSum:'',
    deathBenefits:'',
    progress:'',
    insuredCircleCoverage:'',
    annualSalaryCoverage:'',
    excessWages:'',
    menCoverage:'',
    womenCoverage:'',
    perDiem:'',
    waitingTimeDaysCoverage:'',
    deathBenefitsCoverage:'',
    disabilityLumpSumCoverage:'',
    disabilityPensionCoverage:'',
    survivorPensionCoverage:'',
    participationSurpluses:'',
    desireEntry1Day:'',
    contactDuration:'',
    pensionPolicyNumber:'',
    pensionallowanceDate:'',
    pensionnear:'',
    companyAffiliated:'',
    subjectLpp:'',
    forceEntry:'',
    pensionInstitution:'',
    contactExpire:'',
    asaMember:'',
    userLastName:'',
    userFirstName:'',
    userDob:'',
    userSelfEmail:'',
    userAnnualSalary:'',
    userActivityRate:'',
    userTotalAccumulated:'',
    userAccumulated:'',
    caseResume:'',
    attachedFile:'',
    whichOne:'',
    desireInsCoverage:'',
    hiCovering:'',
    contractLength:'',
    remark:'',
    genderType:'',
    multiaddress: this._formBuilder.array([this.addAddressGroup()])
  });



  constructor(private _formBuilder: FormBuilder) { }

  private addAddressGroup(): FormGroup {
    return this._formBuilder.group({
      userLastName: [],
      userFirstName: [],
      userDob: [],
      userSelfEmail: [],
      userAnnualSalary: [],
      userActivityRate: [],
      userTotalAccumulated: [],
      userAccumulated: [],
    });
  }
  //Add Fields
  addAddress(): void {
    this.addressArray.push(this.addAddressGroup());
  }

  //Remove Fields
  removeAddress(index: number): void {
    this.addressArray.removeAt(index);
  }
  //Fields Array
  get addressArray(): FormArray {
    return <FormArray>this.businessInsurance.get('multiaddress');
  }

}

