import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormGroup} from '@angular/forms';
import {FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-laa-aa',
  templateUrl: './laa-aa.component.html',
  styleUrls: ['./laa-aa.component.css']
})
export class LaaAaComponent implements OnInit  {

  ngOnInit():void{
    window.scroll(0, 0);
  }

  familyInsuranceFormGroup = new FormGroup ({
    makeYourRequest: new FormControl('', [Validators.required]),
  });

  constructor(private _formBuilder: FormBuilder) {}

}
