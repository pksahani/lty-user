import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LaaAaComponent } from './laa-aa.component';

describe('LaaAaComponent', () => {
  let component: LaaAaComponent;
  let fixture: ComponentFixture<LaaAaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LaaAaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LaaAaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
