import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LossEarningComponent } from './loss-earning.component';

describe('LossEarningComponent', () => {
  let component: LossEarningComponent;
  let fixture: ComponentFixture<LossEarningComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LossEarningComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LossEarningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
