import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-housing-rental',
  templateUrl: './housing-rental.component.html',
  styleUrls: ['./housing-rental.component.css']
})
export class HousingRentalComponent implements OnInit  {
  country_List:any=[];
  paymentMethodList:any=["Monthly","Quarterly","Semester","Annuel"];
  insuranceType: any='HOUSING_RENTAL';
  partnerId: string;
  memberId: string;
  relation: string;
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";

  otherPersonChecked:any="";

  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {}

  housingRentalForm = new FormGroup({
    fontData: new FormControl(""),
    existingFont: new FormControl(""),
    paymentMethod: new FormControl(""),
    desiredStart:new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    premiumDueDate:new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    title:new FormControl(""),
    language:new FormControl(""),
    firstName: new FormControl(""),
    lastName: new FormControl(""),
    countryCode: new FormControl(""),
    mobile: new FormControl(""),
    dob: new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    email:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    occupation:new FormControl(""),
    address: new FormControl(""),
    postCode: new FormControl(""),
    nationality: new FormControl(""),
    residencePermit:new FormControl(""),
    effectiveDate: new FormControl("", [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    //streetNo:new FormControl("", [Validators.required]),
    title_other:new FormControl(""),
    firstName_other: new FormControl(""),
    lastName_other: new FormControl(""),
    dob_other: new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    countryCode_other: new FormControl(""),
    mobile_other: new FormControl(""),
    email_other:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    occupation_other:new FormControl(""),

    rentedObjectAddress:new FormControl(""),
    rentedObjectZipLocation:new FormControl(""),

    lessor:new FormControl(""),// owenrDetail
    countryCode_owner: new FormControl(""),
    mobile_owner: new FormControl(""),
    email_owner:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    streetNo_owner: new FormControl(""),
    contactPerson_owner: new FormControl(""),
    zipLocation_owner: new FormControl(""),

    management_stewardship: new FormControl(""), // stewardship
    countryCode_stewardship: new FormControl(""),
    mobile_stewardship: new FormControl(""),
    email_stewardship:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    streetNo_stewardship: new FormControl(""),
    contactPerson_stewardship: new FormControl(""),
    zip_stewardship: new FormControl(""),
    monthlyRent: new FormControl(""),
    amountToDeposit: new FormControl(""),
    areYouCurrentlySued: new FormControl(""),
    pattern: new FormControl("")
     
  },{
     updateOn: "change",
  });

  async ngOnInit(): Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
  }

  get housingForm() { return this.housingRentalForm.controls; }

  saveHousingRentalForm(){
    if (this.housingRentalForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    //console.log(this.housingRentalForm.getRawValue().otherPersonCheck);
    
    var phone:any=this.housingRentalForm.getRawValue().mobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;

    var phone_other:any=this.housingRentalForm.getRawValue().mobile_other;
    var countryCode_other=(phone_other.dialCode);
    var phoneNumber_other=phone_other.number;

    var phone_owner:any=this.housingRentalForm.getRawValue().mobile_owner;
    var countryCode_owner=(phone_owner.dialCode);
    var phoneNumber_owner=phone_owner.number;

    var phone_stewardship:any=this.housingRentalForm.getRawValue().mobile_stewardship;
    var countryCode_stewardship=(phone_stewardship.dialCode);
    var phoneNumber_stewardship=phone_stewardship.number;

    
    this.userAuthService.addProposalRequest({
        partnerId:this.partnerId!=null ? this.partnerId:"",
        userId:this.userId,
        agentId:this.agentId!=null ? this.agentId: "",
        memberId: this.memberId,
        memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
        relation: this.relation,
        insuranceType: this.insuranceType,
        metadata: {
          type: this.insuranceType,
          fontData: this.housingRentalForm.getRawValue().fontData,
          existingFont: this.housingRentalForm.getRawValue().existingFont,
          paymentMethod: this.housingRentalForm.getRawValue().paymentMethod,
          desiredStart: this.housingRentalForm.getRawValue().desiredStart,
          premiumDueDate: this.housingRentalForm.getRawValue().premiumDueDate,
          language: this.housingRentalForm.getRawValue().language,
          tenantDetails: {
            title: this.housingRentalForm.getRawValue().title,
            firstName: this.housingRentalForm.getRawValue().firstName,
            lastName: this.housingRentalForm.getRawValue().lastName,
            countryCode: countryCode,
            mobile: phoneNumber,
            dob: this.housingRentalForm.getRawValue().dob,
            email:this.housingRentalForm.getRawValue().email,
            address: this.housingRentalForm.getRawValue().address,
            nationality: this.housingRentalForm.getRawValue().nationality,
            postCode: this.housingRentalForm.getRawValue().postCode,
            occupation: this.housingRentalForm.getRawValue().occupation,
            residencePermit: this.housingRentalForm.getRawValue().residencePermit,
            effectiveDate: this.housingRentalForm.getRawValue().effectiveDate,
          },
          residencePermit: this.housingRentalForm.getRawValue().residencePermit,
          otherPersonDetails:{
            title: this.housingRentalForm.getRawValue().title,
            firstName: this.housingRentalForm.getRawValue().firstName,
            lastName: this.housingRentalForm.getRawValue().lastName,
            countryCode: countryCode_other,
            mobile: phoneNumber_other,
            dob: this.housingRentalForm.getRawValue().dob,
            email:this.housingRentalForm.getRawValue().email,
            occupation: this.housingRentalForm.getRawValue().occupation,
          },
          rentedObjectAddress:this.housingRentalForm.getRawValue().rentedObjectAddress,
          rentedObjectZipLocation:this.housingRentalForm.getRawValue().rentedObjectZipLocation,
          ownerDetails:{
            lessor:this.housingRentalForm.getRawValue().lessor,
            //countryCode:countryCode_owner,
            phoneNo:phoneNumber_owner,
            email:this.housingRentalForm.getRawValue().email_owner,
            streetNo:this.housingRentalForm.getRawValue().streetNo_owner,
            contactPerson:this.housingRentalForm.getRawValue().contactPerson_owner,
            zipLocation:this.housingRentalForm.getRawValue().zipLocation_owner,
          },
          stewardshipDetails:{
             management:this.housingRentalForm.getRawValue().management_stewardship,
             //countryCode:countryCode_stewardship,
             phoneNo:phoneNumber_stewardship,
             email:this.housingRentalForm.getRawValue().email_stewardship,
             streetNo:this.housingRentalForm.getRawValue().streetNo_stewardship,
             contactPerson:this.housingRentalForm.getRawValue().contactPerson_stewardship,
             zipLocation:this.housingRentalForm.getRawValue().zip_stewardship,
          },
          monthlyRent:this.housingRentalForm.getRawValue().monthlyRent,
          amountToDeposit:this.housingRentalForm.getRawValue().amountToDeposit,
          areYouCurrentlySued:this.housingRentalForm.getRawValue().areYouCurrentlySued,
          pattern:this.housingRentalForm.getRawValue().pattern,
        }
      }).subscribe({
      next: (x: any) => {
          this.housingRentalForm.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });


  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
        this.partnerId=x.data.partnerId;
        this.userId=x.data.userId;
        this.agentId=x.data.agentId;
        console.log(x.data);
        let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
        this.iso=country[0].sortname;
        this.housingRentalForm.controls["title"].setValue(x.data.title);
        this.housingRentalForm.controls["firstName"].setValue(x.data.firstName);
        this.housingRentalForm.controls["lastName"].setValue(x.data.lastName);
        this.housingRentalForm.controls["address"].setValue(x.data.address);
        this.housingRentalForm.controls["dob"].setValue(x.data.dob);
        this.housingRentalForm.controls["mobile"].setValue(x.data.mobile); 
        this.housingRentalForm.controls["nationality"].setValue(x.data.nationality);
        this.housingRentalForm.controls["email"].setValue(x.data.email); 
        this.housingRentalForm.controls["postCode"].setValue(x.data.postCode); 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
           
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }

  onCheckOtherPerson(items:any){
    if(items.target.checked){
      this.otherPersonChecked=items.target.value;
    }else{ //remove unchecked value
      this.otherPersonChecked="";
    }
  }

 

  


}
