import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HousingRentalComponent } from './housing-rental.component';

describe('HousingRentalComponent', () => {
  let component: HousingRentalComponent;
  let fixture: ComponentFixture<HousingRentalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HousingRentalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HousingRentalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
