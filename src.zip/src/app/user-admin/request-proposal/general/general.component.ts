import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormGroup} from '@angular/forms';
import {FormBuilder} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.css']
})
export class GeneralComponent implements OnInit  {

  __AddList: any;
  SuccessMessage: string;
  SubmitBtn:boolean=false;
  partnerId: string;
  memberId: string;
  relation: string;
  insuranceType: any='GENERAL';
  _getProfile: any;
  userId: any;
  agentId: any;
  _user: any;
  InsuranceFormGroup = new FormGroup ({
    makeYourRequest: new FormControl('', [Validators.required])
  });
  member_detail: any;
  disabledBtn: boolean=false;

  constructor(private route:ActivatedRoute, private router:Router, private _formBuilder: FormBuilder, private toastrService:ToastrService, private userAuthService:UserAuthService) {}

ngOnInit(): void {
  this.memberId = this.route.snapshot.paramMap.get('MemberId');
  this.relation = this.route.snapshot.paramMap.get('Mrelation');
  this.getCurrentUser();
  this.GetProfileDetail();
  this.GetmemberDetail();
}

GetmemberDetail():any{
  this._getProfile = this.userAuthService.getFamilymember(
    {
      familyMemberId:this.memberId
    }
  ).subscribe({
    next: (x: any) => {
     this.member_detail=x.data;
   
    },
    error: (err: Error) => {
     
      
    },
    complete: () => {
      
    },
  });
}

getCurrentUser(): any {
  let data = localStorage.getItem('user');
  if (data != null) {
    this._user = JSON.parse(data);
    console.log(this._user);
  }
  return this._user;
}
  get ProposalError() { return this.InsuranceFormGroup.controls; }
  RequestProposal(): void {
    this.disabledBtn=true;
    if (this.InsuranceFormGroup.invalid ) {
      this.SubmitBtn=true;
      this.disabledBtn=false;
      this.toastrService.error('Please fill All required Field.');
      return;
    }
    this.__AddList = this.userAuthService.addProposalRequest(
      {
  partnerId:this.partnerId,
  userId:this.userId,
  agentId:this.agentId,
  memberId: this.memberId,
  memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
  relation: this.relation,
  insuranceType: this.insuranceType,
  metadata: {
    type: this.insuranceType,
    makeYourRequest: this.InsuranceFormGroup.getRawValue().makeYourRequest
  }
       
      }
    ).subscribe({
     next: (x: any) => {
      this.SubmitBtn=false;
      //this.member_List=x.data.familyMemberList;
      this.SuccessMessage = 'Proposal sent successfully.';
          this.InsuranceFormGroup.reset();
          this.toastrService.success(this.SuccessMessage);
          //$('#addMemberProfile').offcanvas('hide');
          //this.getFamilymembers();
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
       //console.error(err)
       this.toastrService.error(errRes.error.error.clientErrorMessage);
     },
     complete: () => {
       //this.registerSubmitted = false;
     },
   });
  }

  GetProfileDetail(): any {
   
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;
     
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
        
      },
      complete: () => {
        
      },
    });
   
  }

}
