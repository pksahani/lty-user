import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';


@Component({
  selector: 'app-legal-protection',
  templateUrl: './legal-protection.component.html',
  styleUrls: ['./legal-protection.component.css']
})
export class LegalProtectionComponent implements OnInit  {
  country_List:any=[];
  contractArr:any=[];

  contractList:any=["Private legal protection and circulation","Additional Multi Risk legal protection","Additional legal protection for the self-employed and small entrepreneurs","Legal protection for building occupied by an insured person at home*","Private legal protection","Additional Multi Risk legal protection","Additional legal protection for the self-employed and small entrepreneurs","Traffic legal protection"];
  insuranceType: any='LEGAL_PROTECTION';
  partnerId: string;
  memberId: string;
  relation: string;
  
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {}

  legalProtectionFormGroup = new FormGroup({
    proposalFor: new FormControl("New proposition"),
    fontData: new FormControl(""),
    replaceFont:new FormControl(""),
    firstName: new FormControl("", [Validators.required]),
    lastName: new FormControl("", [Validators.required]),
    gender:new FormControl("male"),
    maritalStatus:new FormControl("single"),
    countryCode: new FormControl(""),
    mobile: new FormControl("", [Validators.required]),
    email:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    fax:new FormControl(""),
    residencePermit:new FormControl(""),
    nationality: new FormControl("", [Validators.required]),
    streetNo:new FormControl("", [Validators.required]),
    postCode: new FormControl("", [Validators.required]),
    occupation:new FormControl("", [Validators.required]),
    bankCc:new FormControl(""),
    effectiveDate: new FormControl("", [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    contractData:new FormControl(""),
    contractDataList:new FormControl(""),
    typeOfCovers:new FormControl(""),
    number:new FormControl(""),
    address:new FormControl(""),
    insuredForLegal:new FormControl(""),
    risk:new FormControl(""),
    company:new FormControl(""),
    reason:new FormControl(""),
    involvedInLitigation:new FormControl(""),
    startDate: new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    endDate: new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    expireDate: new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    
  },{
     updateOn: "change",
  });
  
  async ngOnInit():Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
  }

  get legalForm() { return this.legalProtectionFormGroup.controls; }

  saveLegalProtectionForm(){
    if (this.legalProtectionFormGroup.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    var phone:any=this.legalProtectionFormGroup.getRawValue().mobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;

    this.userAuthService.addProposalRequest({
        partnerId:this.partnerId!=null ? this.partnerId:"",
        userId:this.userId,
        agentId:this.agentId!=null ? this.agentId: "",
        memberId: this.memberId,
        memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
        relation: this.relation,
        insuranceType: this.insuranceType,
        metadata: {
          type: this.insuranceType,
          fontData:this.legalProtectionFormGroup.getRawValue().fontData,
          replaceFont:this.legalProtectionFormGroup.getRawValue().replaceFont,
          personalDetails: {
            gender: this.legalProtectionFormGroup.getRawValue().gender,
            firstName: this.legalProtectionFormGroup.getRawValue().firstName,
            lastName: this.legalProtectionFormGroup.getRawValue().lastName,
            countryCode: countryCode,
            mobile: phoneNumber,
            maritalStatus: this.legalProtectionFormGroup.getRawValue().maritalStatus,
            address: this.legalProtectionFormGroup.getRawValue().email,
            nationality: this.legalProtectionFormGroup.getRawValue().nationality,
            effectiveDate: this.legalProtectionFormGroup.getRawValue().effectiveDate,
            fax:this.legalProtectionFormGroup.getRawValue().fax,
            residencePermit:this.legalProtectionFormGroup.getRawValue().residencePermit,
            streetNo:this.legalProtectionFormGroup.getRawValue().streetNo,
            postCode: this.legalProtectionFormGroup.getRawValue().postCode,
            occupation:this.legalProtectionFormGroup.getRawValue().occupation,
            bankCc:this.legalProtectionFormGroup.getRawValue().bankCc
          },
          contractData:this.legalProtectionFormGroup.getRawValue().contractData,
          contractDataList:this.contractArr,
          typeOfCovers:this.legalProtectionFormGroup.getRawValue().typeOfCovers,
          number:this.legalProtectionFormGroup.getRawValue().number,
          address:this.legalProtectionFormGroup.getRawValue().address,
          insuredForLegal:this.legalProtectionFormGroup.getRawValue().insuredForLegal,
          insuredDetails:{
            risk:this.legalProtectionFormGroup.getRawValue().risk,
            company:this.legalProtectionFormGroup.getRawValue().company,
            reason:this.legalProtectionFormGroup.getRawValue().reason
          },
          involvedInLitigation:this.legalProtectionFormGroup.getRawValue().involvedInLitigation,
          startDate:this.legalProtectionFormGroup.getRawValue().startDate,
          endDate:this.legalProtectionFormGroup.getRawValue().endDate,
          expireDate:this.legalProtectionFormGroup.getRawValue().expireDate
        }
      }).subscribe({
      next: (x: any) => {
          this.contractArr=[];
          this.legalProtectionFormGroup.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });

  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;

        let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
        this.iso=country[0].sortname;
        this.legalProtectionFormGroup.controls["firstName"].setValue(x.data.firstName);
        this.legalProtectionFormGroup.controls["lastName"].setValue(x.data.lastName);
        this.legalProtectionFormGroup.controls["gender"].setValue(x.data.gender);
        this.legalProtectionFormGroup.controls["maritalStatus"].setValue(x.data.maritalStatus);
        this.legalProtectionFormGroup.controls["mobile"].setValue(x.data.mobile); 
        this.legalProtectionFormGroup.controls["email"].setValue(x.data.email); 
        this.legalProtectionFormGroup.controls["fax"].setValue(x.data.fax); 
        this.legalProtectionFormGroup.controls["postCode"].setValue(x.data.postCode); 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  }

  setContracts(items:any){
    if(items.target.checked){
      this.contractArr.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.contractArr.length; i++) {
        let contact= this.contractArr[i];
        if(contact==items.target.value){
          this.contractArr.splice(i, 1);
        }
      }
    }
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }

  

}
