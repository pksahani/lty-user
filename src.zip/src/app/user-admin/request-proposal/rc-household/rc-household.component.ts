import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-rc-household',
  templateUrl: './rc-household.component.html',
  styleUrls: ['./rc-household.component.css']
})
export class RcHouseholdComponent implements OnInit  {

  country_List:any=[];
  durationList:any=["1 Year","2 Years","5 Years"];
  riskList:any=["1 Family House","Multi-Family House","Second Home","Other"];
  sumList:any=["CHF 3'000'000","CHF 5'000'000"];
  benefits:any=[];
  complementoryCover:any=[];
  insuranceType: any='RC_HOUSEHOLD';
  partnerId: string;
  memberId: string;
  relation: string;
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;

  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";

  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();

  constructor(private _formBuilder: FormBuilder,private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {}

  houseHoldForm = new FormGroup({
    firstName: new FormControl("", [Validators.required]),
    lastName: new FormControl("", [Validators.required]),
    dob: new FormControl("",[Validators.required,Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    maritalStatus:new FormControl("Single", [Validators.required]),
    address: new FormControl("", [Validators.required]),
    nationality: new FormControl("", [Validators.required]),
    effectiveDate: new FormControl("", [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    duration: new FormControl("", [Validators.required]),
    placeOfRisk:new FormControl(""),
    sumInsured:new FormControl(""),
    typeOfConstruction:new FormControl(""),
    civilLiability:new FormControl(""),
    sum:new FormControl(""),
    franchise:new FormControl(""),
    areYouOwner:new FormControl(""),
    pastInsured:new FormControl(""),
    company:new FormControl(""),
    reason:new FormControl(""),
    anyClaim:new FormControl(""),
    specifyTheClaim:new FormControl(""),
    wereYouRefused:new FormControl(""),
    remarks:new FormControl(""),
    
  },{
     updateOn: "change",
  });

  async ngOnInit():Promise<void>{
    window.scroll(0, 0);
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.country_List=await this.getCountries();
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
  }

  get hsForm() { return this.houseHoldForm.controls; }

  saveHouseHoldForm(){
    if (this.houseHoldForm.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    this.userAuthService.addProposalRequest({
      partnerId:this.partnerId!=null ? this.partnerId:"",
      userId:this.userId,
      agentId:this.agentId!=null ? this.agentId: "",
      memberId: this.memberId,
      memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
      relation: this.relation,
      insuranceType: this.insuranceType,
      metadata: {
        type: this.insuranceType,
        placeOfRisk: this.houseHoldForm.getRawValue().placeOfRisk,
        sumInsured: this.houseHoldForm.getRawValue().sumInsured,
        typeOfConstruction: this.houseHoldForm.getRawValue().typeOfConstruction,
        civilLiability: this.houseHoldForm.getRawValue().civilLiability,
        sum: this.houseHoldForm.getRawValue().sum,
        franchise: this.houseHoldForm.getRawValue().franchise,
        areYouOwner: this.houseHoldForm.getRawValue().areYouOwner,
        pastInsured: this.houseHoldForm.getRawValue().pastInsured,
        company: this.houseHoldForm.getRawValue().company,
        reason: this.houseHoldForm.getRawValue().reason,
        anyClaim: this.houseHoldForm.getRawValue().anyClaim,
        specifyTheClaim: this.houseHoldForm.getRawValue().specifyTheClaim,
        wereYouRefused: this.houseHoldForm.getRawValue().wereYouRefused,
        remarks: this.houseHoldForm.getRawValue().remarks,
        benefits:this.benefits,
        complementaryCovers:this.complementoryCover,
        
        personalDetails: {
          firstName: this.houseHoldForm.getRawValue().firstName,
          lastName: this.houseHoldForm.getRawValue().lastName,
          dob: this.houseHoldForm.getRawValue().dob,
          maritalStatus:this.houseHoldForm.getRawValue().maritalStatus,
          address: this.houseHoldForm.getRawValue().address,
          nationality: this.houseHoldForm.getRawValue().nationality,
          effectiveDate: this.houseHoldForm.getRawValue().effectiveDate,
          duration: this.houseHoldForm.getRawValue().duration,
        }
      }
    }).subscribe({
      next: (x: any) => {
          this.benefits=[];
          this.complementoryCover=[];
          this.houseHoldForm.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
        this.partnerId=x.data.partnerId;
        this.userId=x.data.userId;
        this.agentId=x.data.agentId;
        console.log(x.data);
        let country=this.country_List.filter(function (country:any) { return country.phonecode == x.data.countryCode });
        this.iso=country[0].sortname;
       
        this.houseHoldForm.controls["firstName"].setValue(x.data.firstName);
        this.houseHoldForm.controls["lastName"].setValue(x.data.lastName);
        this.houseHoldForm.controls["address"].setValue(x.data.address);
        this.houseHoldForm.controls["dob"].setValue(x.data.dob);
        this.houseHoldForm.controls["nationality"].setValue(x.data.nationality);
        this.houseHoldForm.controls["maritalStatus"].setValue(x.data.maritalStatus);
        //this.houseHoldForm.controls["duration"].setValue(x.data.duration); 
        this.houseHoldForm.controls["effectiveDate"].setValue(x.data.effectiveDate);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries():  Promise<any> {
    return new Promise((resolve, reject) => {
      this.userAuthService.getcountries().subscribe({
          next: (result: any) => {
           
            return resolve(result.data.countriesList);
          },
          error: (err: any) => {
            return reject(err.error);
          },
          complete: () => {
          }
      }); 
    });
  }

  cancelFunction(){
    this.router.navigate(['/user/request-proposal/list']);
  }

  setBenefits(items:any){
    if(items.target.checked){
      this.benefits.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.benefits.length; i++) {
        let contact= this.benefits[i];
        if(contact==items.target.value){
          this.benefits.splice(i, 1);
        }
      }
    }
  }

  setComplementoryCover(items:any){
    if(items.target.checked){
      this.complementoryCover.push(items.target.value);
    }else{ //remove unchecked value
      for (let i = 0; i < this.complementoryCover.length; i++) {
        let contact= this.complementoryCover[i];
        if(contact==items.target.value){
          this.complementoryCover.splice(i, 1);
        }
      }
    }
  }




}
