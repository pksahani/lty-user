import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RcHouseholdComponent } from './rc-household.component';

describe('RcHouseholdComponent', () => {
  let component: RcHouseholdComponent;
  let fixture: ComponentFixture<RcHouseholdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RcHouseholdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RcHouseholdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
