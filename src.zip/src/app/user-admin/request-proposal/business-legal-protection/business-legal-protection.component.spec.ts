import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessLegalProtectionComponent } from './business-legal-protection.component';

describe('BusinessLegalProtectionComponent', () => {
  let component: BusinessLegalProtectionComponent;
  let fixture: ComponentFixture<BusinessLegalProtectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusinessLegalProtectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BusinessLegalProtectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
