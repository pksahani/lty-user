import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FormControl, Validators, FormGroup,FormBuilder} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';

@Component({
  selector: 'app-business-legal-protection',
  templateUrl: './business-legal-protection.component.html',
  styleUrls: ['./business-legal-protection.component.css']
})
export class BusinessLegalProtectionComponent implements OnInit  {
  country_List:any=[];
  insuranceType: any='BUSINESS_LEGAL_PROTECTION';
  partnerId: string;
  memberId: string;
  relation: string;
  
  userId: any;
  agentId: any;
  _user: any;
  _getProfile: any;
  member_detail: any;
  disabledBtn: boolean=false;
  
  CountryISO = CountryISO;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  SearchCountryField = SearchCountryField;
  separateDialCode = true;
  PhoneNumberFormat = PhoneNumberFormat;
  iso:any="ch";
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();
  constructor(private route:ActivatedRoute, private router:Router,private userAuthService:UserAuthService,private toastrService:ToastrService) {

  }

  legalProtectionFormGroup = new FormGroup({
    proposalFor:new FormControl("New Proposition"),
    fontData:new FormControl(""),
    replaceFont:new FormControl(""),
    replaceNumber:new FormControl(""),
    proposalSubstitution:new FormControl(""),
    legalProRadio:new FormControl(""),
    fontNumber:new FormControl(""),
    business:new FormControl(""),
    firstName: new FormControl(""),
    lastName: new FormControl(""),
    // countryCode: new FormControl("41", [Validators.required]),
    // mobile: new FormControl("", [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{9,13}$")]),
    countryCode: new FormControl(""),
    mobile: new FormControl("", [Validators.required]),
    dob: new FormControl("",[Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]), //,this.ageValidator()
    email:new FormControl("", [Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    postCode:new FormControl(""),
    responsible:new FormControl(""),
    contractDate:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    effectiveDate:new FormControl("", [Validators.required,Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    insuredForLegal:new FormControl(""),
    risk:new FormControl(""),
    company:new FormControl(""),
    reason:new FormControl(""),
    involvedInLitigation:new FormControl(""),
    startDate:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    endDate:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    expireDate:new FormControl("", [Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]),
    streetNo:new FormControl(""),

  },{
     updateOn: "change",
   });


  ngOnInit():void{
    this.memberId = this.route.snapshot.paramMap.get('MemberId');
    this.relation = this.route.snapshot.paramMap.get('Mrelation');
    this.getCurrentUser();
    this.GetProfileDetail();
    this.GetmemberDetail();
    this.getCountries();
  }

  get lProtectionForm() { return this.legalProtectionFormGroup.controls; }

  saveProposalForLeagalProtection(){
    if (this.legalProtectionFormGroup.invalid) {
      this.toastrService.error("Please fill All the required Fields.");
      return;
    }

    var phone:any=this.legalProtectionFormGroup.getRawValue().mobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;

    this.userAuthService.addProposalRequest({
        partnerId:this.partnerId!=null ? this.partnerId:"",
        userId:this.userId,
        agentId:this.agentId!=null ? this.agentId: "",
        memberId: this.memberId,
        memberName:this.member_detail.firstName+' '+this.member_detail.lastName,
        relation: this.relation,
        insuranceType: this.insuranceType,
        metadata: {
          type: this.insuranceType,

          proposalFor: this.legalProtectionFormGroup.getRawValue().proposalFor,
          fontData: this.legalProtectionFormGroup.getRawValue().fontData,
          replaceFont: this.legalProtectionFormGroup.getRawValue().replaceFont,
          insuredForLegal:this.legalProtectionFormGroup.getRawValue().insuredForLegal,
          involvedInLitigation:this.legalProtectionFormGroup.getRawValue().involvedInLitigation,
          startDate:this.legalProtectionFormGroup.getRawValue().startDate,
          endDate:this.legalProtectionFormGroup.getRawValue().endDate,
          expireDate:this.legalProtectionFormGroup.getRawValue().expireDate,
          companyDetails: {
            // firstName: this.legalProtectionFormGroup.getRawValue().firstName,
            // lastName: this.legalProtectionFormGroup.getRawValue().lastName,
            //countryCode: this.legalProtectionFormGroup.getRawValue().countryCode,
            //dob: this.legalProtectionFormGroup.getRawValue().dob,
            //effectiveDate: this.legalProtectionFormGroup.getRawValue().effectiveDate,
            id:"",
            business:this.legalProtectionFormGroup.getRawValue().business,
            //phone: (this.legalProtectionFormGroup.getRawValue().mobile).toString(),
            //countryCode: countryCode,
            phone: phoneNumber,
            email:this.legalProtectionFormGroup.getRawValue().email,
            streetNo:this.legalProtectionFormGroup.getRawValue().streetNo,
          },
          insuredDetails:{
            risk:this.legalProtectionFormGroup.getRawValue().risk,
            company:this.legalProtectionFormGroup.getRawValue().company,
            reason:this.legalProtectionFormGroup.getRawValue().reason
          }
        }
      }).subscribe({
      next: (x: any) => {
        
          this.legalProtectionFormGroup.reset();
          this.toastrService.success('Proposal Request submitted successfully.');
          this.router.navigate(['/user/request-proposal/thanks-proposal']);
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }

  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  GetProfileDetail(): any {
    this._getProfile = this.userAuthService.getuserByToken(
      {
        token:this._user.token
      }
    ).subscribe({
      next: (x: any) => {
       this.partnerId=x.data.partnerId;
       this.userId=x.data.userId;
       this.agentId=x.data.agentId;
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        localStorage.removeItem('user')
        this.router.navigate(['/signin']);
      },
      complete: () => {
      },
    });
  }

  GetmemberDetail():any{
    this._getProfile = this.userAuthService.getFamilymember(
      {
        familyMemberId:this.memberId
      }
    ).subscribe({
      next: (x: any) => {
       this.member_detail=x.data;
      },
      error: (err: Error) => { 
      },
      complete: () => {
      },
    });
  }

  getCountries(): void {
    this.userAuthService.getcountries().subscribe({
     next: (x: any) => {
      this.country_List=x.data.countriesList;
     },
     error: (err: Error) => {
       let errRes: any;
       errRes = err;
     },
     complete: () => {
       
     },
   });
 }

 cancelFunction(){
  this.router.navigate(['/user/request-proposal/list']);
}
  

  

}
