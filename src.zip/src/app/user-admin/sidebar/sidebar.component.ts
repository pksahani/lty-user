import { Component } from '@angular/core';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';
import { Router} from '@angular/router';
import { UserAuthService } from '../../_services/user-auth.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  // standalone: true,
	// imports: [NgbDropdownModule, NgbAccordionModule]
})
export class SidebarComponent {
  _signOutSub:any;
  _user:any;
  logoutErrorMessage:any;
  constructor(private router:Router, private userAuthService:UserAuthService){
    this.getCurrentUser();
  }


  getCurrentUser(): any {
    let data = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
      // console.log(this._user);
    }
    return this._user;
  }
  SignOut(): any {
    //localStorage.clear();
    localStorage.removeItem('user');
    this._signOutSub = this.userAuthService.signout(
      {
        token:this._user.token,
        hardSignOut:true
      }
    ).subscribe({
      next: (x: any) => {
        localStorage.removeItem('user');
        localStorage.clear();

        setTimeout(() => {
          this.router.navigate(['/signin']);
      }, 2000);
        
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        // console.error(err)
        localStorage.clear();
        this.router.navigate(['/signin']);
        this.logoutErrorMessage = errRes.error.message;
      },
      complete: () => {
        localStorage.removeItem('user');
      },
    });
// console.log("hello");

   
     
   
  }
}
