import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DocumentsRoutingModule } from './documents-routing.module';
import { ListComponent } from './list/list.component';
import { ViewComponent } from './view/view.component';
import { ButtonComponent } from './list/button/button.component';
import { ButtonComponent as ViewButtonComponent } from './view/button/button.component';


@NgModule({
  declarations: [
    ListComponent,
    ViewComponent,
    ButtonComponent,
    ViewButtonComponent
  ],
  imports: [
    CommonModule,
    DocumentsRoutingModule,
    AgGridModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers:  [DatePipe]
})
export class DocumentsModule { }
