import { Component, HostListener } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import { Router, NavigationStart } from '@angular/router';
import { environment } from './../environments/environment';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'lty';



  firstFormGroup = this._formBuilder.group({
    firstCtrl: ['', Validators.required],
  });
  secondFormGroup = this._formBuilder.group({
    secondCtrl: '',
  });

  thirdFormGroup = this._formBuilder.group({
    secondCtrl: '',
  });

  isOptional = false;


  showHead: boolean = false;
  showFooter: boolean=false;

  constructor(private _formBuilder: FormBuilder,private router: Router) {

    router.events.forEach((event) => {
      if (event instanceof NavigationStart) {
        var usr=localStorage.getItem("user");
        
        if (event['url'] == '/dashboard' || event['url'] == '/' || event['url'] == '/signin' || event['url'] == '/signup'  || event['url'] == '/forgotPassword' || event['url'] == '/otpVerify' || event['url'] == '/setPassword' || event['url'] == '/onboarding') {
          this.showHead = false;
          this.showFooter=false;
          if(usr!=null){
            this.router.navigate(['/user']);
          }
        } else {
          this.showHead = true;
          this.showFooter=true;
        }

        // if (event['url'] == '/user' ) {
        //   this.showHead = false;
        //   this.showFooter=false;
        // }else{
        //   this.showHead = true;
        //   this.showFooter=true;
        // }
      }
    });
  }


  isShow: boolean = false;
  topPosToStartShowing = 100;

  @HostListener('window:scroll')
  checkScroll() {

    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

    //console.log('[scroll]', scrollPosition);

    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

onActivate(event:any) {
   window.scroll({ 
           top: 0, 
           left: 0, 
           behavior: 'smooth' 
    });
    //or document.body.scrollTop = 0;
    //or document.querySelector('body').scrollTo(0,0)
   
}


}
