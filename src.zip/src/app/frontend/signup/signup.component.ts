import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd} from '@angular/router';
import {FormControl, Validators, FormGroup, ValidationErrors,AbstractControl,ValidatorFn } from '@angular/forms';
import {FloatLabelType} from '@angular/material/form-field';
import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';
import {FormBuilder} from '@angular/forms';
import { UserAuthService } from '../../_services/user-auth.service';
import { CustomValidators } from '../../_helpers/CustomValidators';
import { ToastrService } from 'ngx-toastr';
import { MatStepper } from '@angular/material/stepper';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';
declare var $: any;

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: {showError: true},
    },
  ],
})

export class SignupComponent implements OnInit {

  imageUrl: string | ArrayBuffer;
  selectedFiles: any;
  profilePic: File;
  private _UploadPic: any;
  profile_image: string | ArrayBuffer;
  fileName: any;
  secondSubmitted: boolean=false;
  separateDialCode = true;
	SearchCountryField = SearchCountryField;
	CountryISO = CountryISO;
  PhoneNumberFormat = PhoneNumberFormat;
  hide = true;
  showcompany=false;
  hideRequiredControl = new FormControl(false);

  isEditable = true;
  __signUpSub: any;
  showPassword: boolean = false;
  showPasswordc: boolean = false;
  registerSubmitted: boolean = false;
  regSuccessMessage: string = '';
  regErrorMessage: string = '';
  __CountriesList:any;
  country_List:any;
  __StateList:any;
  state_List:any;
  __CityList:any;
  city_List:any;
  __AgentList:any;
  agent_List:any
  __PartnerList:any;
  partner_List:any;
  
	preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  floatLabelControl = new FormControl('auto' as FloatLabelType);
  
  email = new FormControl('', [Validators.required, Validators.email]);
  maxDate = new Date().getFullYear()+'-'+String(new Date().getMonth()).padStart(2, '0')+'-'+new Date().getDate();

  constructor(private toastrService: ToastrService, private _formBuilder: FormBuilder, private userAuthService: UserAuthService, private router: Router) {}

  firstFormGroupNew = new FormGroup({
    userfirstname:new FormControl("",[Validators.required]), 
    userlastname: new FormControl("",[Validators.required]), 
    dob: new FormControl("",[Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/),this.ageValidator()]),
    usersource: new FormControl("Personal",[Validators.required]),
    companyname: new FormControl(""),
    companywebsite: new FormControl(""),
    //address: ['', Validators.required],
    //gender: ['', Validators.required],
    //maritalStatus: ['', Validators.required],
    //state: ['', Validators.required],
    //postCode: ['', [Validators.required, Validators.maxLength(6)]],
    //city: ['', Validators.required],
    //country: ['', Validators.required],
    //numberemployee: [''],
    //companyid: [''],
    //legalentity: ['']
  },{
     updateOn: "change",
   });

   

  firstFormGroup = this._formBuilder.group({
    userfirstname: ['', Validators.required],
    userlastname: ['', Validators.required],
    dob: ['',[Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/),this.ageValidator()]],
    usersource: ['Personal'],
    companyname: [''],
    companywebsite: [''],
   
  });

  secondFormGroup = this._formBuilder.group({
    usermobile: ['', [Validators.required]],
    useremail1: ['', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
    countryCode: ['']
  });
  //, Validators.pattern("^((\\+91-?)|0)?[0-9]{9,13}$")
  thirdFormGroup = this._formBuilder.group({
    userpassword: ['', [Validators.required,Validators.minLength(8), CustomValidators.strong]],
    usercpass: ['', Validators.required],
  }, {
    validators: [CustomValidators.mustMatch('userpassword', 'usercpass')]
  });

ngOnInit(){
  this.router.events.subscribe((event) => {
    if (!(event instanceof NavigationEnd)) {
        return;
    }
    window.scrollTo(0, 0);
  });
  this.getCountries();
  this.firstFormGroup.controls['usersource'].setValue('Personal');
  this.setUserCategoryValidators();
 let a:any=41;
 this.secondFormGroup.controls['countryCode'].setValue(a);
}

get firstf() { return this.firstFormGroup.controls; }
get secondf() { return this.secondFormGroup.controls; }
get thirdf() { return this.thirdFormGroup.controls; }


getErrorMessage() {
  if (this.email.hasError('required')) {
    return 'You must enter a value';
  }
  return this.email.hasError('email') ? 'Not a valid email' : '';
}

setUserCategoryValidators() {
  const ComapanyControl = this.firstFormGroup.get('companyname');
  const WebsiteControl = this.firstFormGroup.get('companywebsite');
  const EmployeeControl = this.firstFormGroup.get('numberemployee');
  const CompanyIDControl = this.firstFormGroup.get('companyid');
  const LeagalEntityControl = this.firstFormGroup.get('legalentity');
  this.firstFormGroup.get('usersource').valueChanges
    .subscribe(usersource => {

      if (usersource === 'Personal') {
        ComapanyControl.setValidators(null);
        WebsiteControl.setValidators(null);
        EmployeeControl.setValidators(null);
        CompanyIDControl.setValidators(null);
        LeagalEntityControl.setValidators(null);
      }

      if (usersource === 'Company') {
        ComapanyControl.setValidators([Validators.required]);
        WebsiteControl.setValidators([Validators.required,,Validators.pattern("(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?")]);
        //EmployeeControl.setValidators([Validators.required, Validators.pattern("^[0-9]*$")]);
        //CompanyIDControl.setValidators([Validators.required]);
        //LeagalEntityControl.setValidators([Validators.required]);
      }

      ComapanyControl.updateValueAndValidity();
      WebsiteControl.updateValueAndValidity();
      //EmployeeControl.updateValueAndValidity();
      //CompanyIDControl.updateValueAndValidity();
      //LeagalEntityControl.updateValueAndValidity();
    });
  //   this.firstFormGroup.get('numberemployee').valueChanges
  //   .subscribe(numberemployee => {
  //    if(numberemployee!=''){
  //    this.firstFormGroup.controls['numberemployee'].setValue(numberemployee);
  //  }
   
  //  EmployeeControl.updateValueAndValidity({onlySelf : true});
  //   }); 
}

setEmployee(obj:any): void {
  //this.firstFormGroup.controls['numberemployee'].setValue(this.firstFormGroup.getRawValue().numberemployee);
}

getCountries(): void {
     this.__CountriesList = this.userAuthService.getcountries().subscribe({
      next: (x: any) => {
       this.country_List=x.data.countriesList;
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        
      },
      complete: () => {
        this.registerSubmitted = false;
      },
    });
  }
  getStates(): void {
    // this.__StateList = this.userAuthService.getstates(this.firstFormGroup.getRawValue().country).subscribe({
    //   next: (x: any) => {
    //     this.firstFormGroup.controls['state'].setValue('');
    //     this.firstFormGroup.controls['city'].setValue('');
    //     this.city_List=[];
    //    this.state_List=x.data.statesList;
    //   },
    //   error: (err: Error) => {
    //     let errRes: any;
    //     errRes = err;
    //     console.error(err)
        
    //   },
    //   complete: () => {
    //     this.registerSubmitted = false;
    //   },
    // });
  }
  getCities(): void {
    // this.__CityList = this.userAuthService.getcities(this.firstFormGroup.getRawValue().state).subscribe({
    //   next: (x: any) => {
    //    this.city_List=x.data.citiesList;
    //   },
    //   error: (err: Error) => {
    //     let errRes: any;
    //     errRes = err;
    //     console.error(err)
        
    //   },
    //   complete: () => {
    //     this.registerSubmitted = false;
    //   },
    // });
  }

  getAgents(obj:any): void {
    
    this.__AgentList = this.userAuthService.getagents(
      {
        agentId:'',
        searchBy:''
      }
    ).subscribe({
      next: (x: any) => {
       this.agent_List=x.data.usersList;
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        
      },
      complete: () => {
        this.registerSubmitted = false;
      },
    });
  }

  getPartners(obj:any): void {
    
    this.__PartnerList = this.userAuthService.getagents(
      {
        agentId:'',
        searchBy:''
      }
    ).subscribe({
      next: (x: any) => {
       this.partner_List=x.data.usersList;
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        console.error(err)
        
      },
      complete: () => {
        this.registerSubmitted = false;
      },
    });
  }
  
  regfSubmit(): void {
    if (this.firstFormGroup.invalid) {
      this.toastrService.error('Please fill All required Field.');
      return;
    }
  }

  regsSubmit(): void {
    if (this.secondFormGroup.invalid) {
      this.secondSubmitted=true;
      this.toastrService.error('Please fill All required Field.');
      return;
    }
  }

  regSubmit(): void {

    if (this.registerSubmitted) {
      return;
    }
    this.registerSubmitted = true;
    if (this.secondFormGroup.invalid) {
      this.toastrService.error('Please fill All required Field.');
      return;
    }
    // stop here if form is invalid
    if (this.thirdFormGroup.invalid) {
      this.toastrService.error('Please fill All required Field.');
      return;
    }
    var phone:any=this.secondFormGroup.getRawValue().usermobile;
    var countryCode=(phone.dialCode);
    var phoneNumber=phone.number;
    this.regSuccessMessage = '';
    this.regErrorMessage = '';
    let response: any;

    this.__signUpSub = this.userAuthService.registration(
      {
        firstName: this.firstFormGroup.getRawValue().userfirstname,
        lastName: this.firstFormGroup.getRawValue().userlastname,
        dob: this.firstFormGroup.getRawValue().dob,
        email: this.secondFormGroup.getRawValue().useremail1,
        // mobile: this.secondFormGroup.getRawValue().usermobile,
        // countryCode:this.secondFormGroup.getRawValue().countryCode,
        mobile: phoneNumber,
        countryCode:countryCode,
        password: this.thirdFormGroup.getRawValue().userpassword,
        type:this.firstFormGroup.getRawValue().usersource,
        source:'Individual',
        companyDetails:{
          companyName: this.firstFormGroup.getRawValue().companyname,
          website: this.firstFormGroup.getRawValue().companywebsite,
        },
        bankDetails: {
          iban: '',
          swift: '',
          bank: '',
          country: '',
          postCode: '',
          address: '',
          houseOwned: true
        }
      }
    ).subscribe({
      next: (x: any) => {
        this.registerSubmitted = false;
        if(x.data.processStage=='PENDING_ACTION' && x.data.processStageData.txnState=='OTP_VERIFICATION_REQUIRED'){

          let emailverify:any =this.secondFormGroup.getRawValue().useremail1;
          let mobileverify:any =this.secondFormGroup.getRawValue().usermobile;
                localStorage.setItem('verifyotp', JSON.stringify(x.data.processStageData.emailTxnStateData));
                localStorage.setItem('verifyMotp', JSON.stringify(x.data.processStageData.txnStateData));
                localStorage.setItem('verifyemail', emailverify);
                localStorage.setItem('verifymobile', phoneNumber);
                //this.regSuccessMessage = 'User Registration successfully.';
        this.firstFormGroup.reset();
        this.secondFormGroup.reset();
        this.thirdFormGroup.reset();
        //this.toastrService.success(this.regSuccessMessage);
                this.router.navigate(['/otpVerify']);
        
        }
        // let emailverify:any =this.secondFormGroup.getRawValue().useremail1;
        // localStorage.setItem('verifyotp', JSON.stringify(x.data));
        // localStorage.setItem('verifyemail', emailverify);
        // this.regSuccessMessage = 'User Registration successfully.';
        // this.firstFormGroup.reset();
        // this.secondFormGroup.reset();
        // this.thirdFormGroup.reset();
        // this.toastrService.success(this.regSuccessMessage);
        // this.router.navigate(['/otpVerify']);
        //if (this.isUserLoggedIn()) {
          //this.getCurrentUser();
        //}

        //this.modalService.dismissAll('Registration successfully..');
       // this.userAuthService.openSaveSearchModal.next();
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
       // console.error(err)
        this.registerSubmitted = false;
        //this.regErrorMessage = errRes.error.message;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
        $("#backtoEmail").trigger( "click" );
       // this.goBack();
        //this.toastrService.error('User Does not Exists.');
      },
      complete: () => {
        this.registerSubmitted = false;
      },
    });
  }

  goBack(stepper: MatStepper){
    //console.log(stepper);
    stepper.previous();
  }

uploadFile(event:any) {
  this.selectedFiles = event.target.files;
    if (this.selectedFiles !== undefined) {
      this.fileName=this.selectedFiles.item(0)?.name;
      const profile_imageh=event.target.files[0];
      const reader = new FileReader();
      reader.onload = e => this.profile_image = reader.result;
      reader.readAsDataURL(profile_imageh);
    }else{
      this.fileName="";
    }
    this.updateProfilePic();
  }


updateProfilePic() : void {
  if (this.selectedFiles) {
    const file: File | null = this.selectedFiles.item(0);
    if (file) {
      this.profilePic = file;
    }
  }
  this._UploadPic = this.userAuthService.UploadDocument({
    docName:'Registration ID',
    userId:'',
    memberId:'',
    doc:this.profilePic
  }).subscribe( {
      next: (result: any) => {
        localStorage.setItem('profile_pic',result.data.docUrl);
        this.secondFormGroup.controls['registrationId'].setValue(result.data.docUrl);
        //this.toastrService.success("Profile Pic updated successfully!","");
        return;
      },
      error: (err: any) => {
        if(err.error.error.profile_pic){
          this.toastrService.error(err.error.error.profile_pic,"");
        }else{
          this.toastrService.error(err.error.message,"");
        }
      },
      complete: () => {
      }
  }); 
}


ageValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) {
          return null;
      }
      var date = new Date();
      date.setFullYear( date.getFullYear() - 16 );
      var selectedDate = new Date(control.value);
      var invalidAge:any
      if (date > selectedDate ) {
        invalidAge=true;
       } else {
        invalidAge=false;
      }
      return !invalidAge ? {invalidAge:true}: null;
    };
}

}
