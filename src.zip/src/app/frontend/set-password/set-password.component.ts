import { Component } from '@angular/core';
import { NgxOtpInputConfig } from 'ngx-otp-input';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import { Router} from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from 'src/app/_helpers/CustomValidators';
@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.css']
})
export class SetPasswordComponent {
  otpInputConfig: NgxOtpInputConfig = {
    otpLength: 6,
    autofocus: true,
    classList: {
      inputBox: 'my-super-box-class',
      input: 'my-super-class',
      inputFilled: 'my-super-filled-class',
      inputDisabled: 'my-super-disable-class',
      inputSuccess: 'my-super-success-class',
      inputError: 'my-super-error-class',
    },
  };
  _email:any;
  _otpId:any;
  _otp:any='';
  __VerifyOtp:any;
  _resendOtpTime:any;
  _remainingAttempts:any;
  __ResendOtp:any;
  showPassword: boolean = false;
  showPasswordc: boolean = false;
  OTPSuccessMessage:any;
  firstFormGroup = this._formBuilder.group({
    password: ['', [Validators.required,Validators.minLength(8), CustomValidators.strong]],
    passwordc: ['', Validators.required]
  }, {
    validators: [CustomValidators.mustMatch('password', 'passwordc')]
  });

  ngOnInit(): void {
    window.scrollTo(0, 0);
    let verifyotps:any = localStorage.getItem('verifyotp');
    let verifyotp:any=JSON.parse(verifyotps);
   let verifyemail:any = localStorage.getItem('verifyemail');
   
    if(verifyotp!=null){
     this._otpId=verifyotp.otpId;
     this._email=verifyemail;
     this._resendOtpTime=verifyotp.resendOtpTime;
     this._remainingAttempts=verifyotp.remainingAttempts;
     let intervalId = setInterval(() => {
      this._resendOtpTime = this._resendOtpTime - 1;
      //console.log(this.counter)
      if(this._resendOtpTime === 0){ 
        clearInterval(intervalId);
        //this.checkRemainTime=true;
      }
  }, 2000)
  }
}
  constructor(private _formBuilder: FormBuilder, private userAuthService:UserAuthService, private router:Router, private toastrService: ToastrService){

  }
  handeOtpChange(value: string[]): void {
    console.log(value);
  }

  handleFillEvent(value: string): void {
    console.log(value);
    this._otp=value;
  }
  
  get firstf() { return this.firstFormGroup.controls; } 
SetPasswordOTP(){

  if (this.firstFormGroup.invalid) {
    this.toastrService.error('Please fill All required Field.');
    return;
  }
 
  if(this._otp ==''){
    this.toastrService.error('Please Enter OTP.');
    return;
  }

  this.__VerifyOtp = this.userAuthService.setpassword(
    {
      email:this._email,
      password:this.firstFormGroup.getRawValue().password,
      forgotPasswordOtpDetails:{
        otp: this._otp,
        otpId: this._otpId
      }
      
    }
  ).subscribe({
    next: (x: any) => {
      
      //localStorage.setItem('user', JSON.stringify(x.data));
      this.OTPSuccessMessage = 'Password set successfully.Please login with New Password';
      this.toastrService.success(this.OTPSuccessMessage);
        this.router.navigate(['/signin']);
      
    },
    error: (err: Error) => {
      let errRes: any;

      
      errRes = err;
      console.log(errRes.error.error.clientErrorMessage);
      this.toastrService.error(errRes.error.error.clientErrorMessage);
    },
    complete: () => {
      //this.registerSubmitted = false;
    },
  });
}

}
