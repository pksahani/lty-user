import { Component, VERSION } from "@angular/core";
import { NgxOtpInputConfig } from "ngx-otp-input";
import { UserAuthService } from "src/app/_services/user-auth.service";
import { Router } from "@angular/router";
import { FormBuilder, Validators } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { environment } from "src/environments/environment";
import { AngularFireDatabase } from "@angular/fire/compat/database";
import { AngularFireMessaging } from "@angular/fire/compat/messaging";
@Component({
  selector: "app-otp-verify",
  templateUrl: "./otp-verify.component.html",
  styleUrls: ["./otp-verify.component.css"],
})
export class OtpVerifyComponent {
  otpInputConfig: NgxOtpInputConfig = {
    otpLength: 6,
    autofocus: true,
    classList: {
      inputBox: "my-super-box-class",
      input: "my-super-class",
      inputFilled: "my-super-filled-class",
      inputDisabled: "my-super-disable-class",
      inputSuccess: "my-super-success-class",
      inputError: "my-super-error-class",
    },
  };
  _email: any = "";
  _mobile: any = "";
  _otpId: any = "";
  _otpMId: any = "";
  _otp: any;
  _otpmobile: any;
  __VerifyOtp: any;
  counter: any;
  checkCurrentLesson1: boolean = false;
  checkCurrentLesson2: boolean = false;
  checkRemainTime: boolean = false;
  regErrorMessage: any;
  OTPSuccessMessage: any;
  _resendOtpTime: any;
  _remainingAttempts: any;
  __ResendOtp: any;
  fcmKey: any = "";
  firstFormGroup = this._formBuilder.group({
    userotp: ["", Validators.required],
  });
  _getProfile: any;

  constructor(
    private toastrService: ToastrService,
    private userAuthService: UserAuthService,
    private router: Router,
    private _formBuilder: FormBuilder,
    private angularFireDatabase: AngularFireDatabase,
    private angularFireMessaging: AngularFireMessaging
  ) {}

  ngOnInit(): void {
    window.scrollTo(0, 0);
    this.askForPermissioToReceiveNotifications();
    let verifyotps: any = localStorage.getItem("verifyotp");
    let verifyMotps: any = localStorage.getItem("verifyMotp");
    let verifyemail: any = localStorage.getItem("verifyemail");
    let verifymobile: any = localStorage.getItem("verifymobile");
    let verifyotp: any = JSON.parse(verifyotps);
    let verifyMotp: any = JSON.parse(verifyMotps);

    if (verifyotp != null && verifyMotp != null) {
      this._otpId = verifyotp.otpId;
      this._otpMId = verifyMotp.otpId;
      this._email = verifyemail;
      this._mobile = verifymobile;
      this._resendOtpTime = verifyotp.resendOtpTime;
      this._remainingAttempts = verifyotp.remainingAttempts;
      let intervalId = setInterval(() => {
        this._resendOtpTime = this._resendOtpTime - 1;
       
        if (this._resendOtpTime === 0) {
          clearInterval(intervalId);
          this.checkRemainTime = true;
        }
      }, 2000);
    } else if (verifyMotp != null) {
      this._otpMId = verifyMotp.otpId;
      this._mobile = verifymobile;
      this._email = verifyemail;
      this._resendOtpTime = verifyMotp.resendOtpTime;
      this._remainingAttempts = verifyMotp.remainingAttempts;
      let intervalId = setInterval(() => {
        this._resendOtpTime = this._resendOtpTime - 1;
        //console.log(this.counter)
        if (this._resendOtpTime === 0) {
          clearInterval(intervalId);
          this.checkRemainTime = true;
        }
      }, 2000);
    }

    //this._otpId='OTPID104149469803';
    // this._email='raghav@yopmail.com';
    // this._resendOtpTime='30';
    //this.counter='30';
    // this._remainingAttempts='5';
  }

  async askForPermissioToReceiveNotifications() {
    await this.angularFireMessaging.requestPermission.subscribe(
      (response) => {
        //console.log(response);
      },
      (error) => {
        console.error(error);
      }
    );
    const token = await this.angularFireMessaging.getToken.subscribe(
      (token: any) => {
        //console.log(token);
        this.fcmKey = token ? token : "";
      },
      (error) => {
        console.error(error);
      }
    );
  }

  UpdateOTP(obj: any, verifyis: any): void {
    if (verifyis == "mobile") {
      this._otpMId = obj.otpId;
    } else if (verifyis == "email") {
      this._otpId = obj.otpId;
    }

    this._resendOtpTime = obj.resendOtpTime;
    this._remainingAttempts = obj.remainingAttempts;
    let intervalId = setInterval(() => {
      this._resendOtpTime = this._resendOtpTime - 1;
      if (this._resendOtpTime === 0) {
        clearInterval(intervalId);
        this.checkRemainTime = true;
      }
    }, 2000);
  }

  handeOtpChange(value: string[]): void {
    var count=0;
    for(var i=0;i<value.length;i++){
      if(value[i]!=null && value[i]!=''){
        count++;
      }
    }
    if(count==6){
      this.checkCurrentLesson2=true;
    }else{
      this.checkCurrentLesson2=false;
    }
  }
  handeOtpChangeEml(value: string[]): void{
    var count=0;
    for(var i=0;i<value.length;i++){
      if(value[i]!=null && value[i]!=''){
        count++;
      }
    }
    if(count==6){
      this.checkCurrentLesson1=true;
    }else{
      this.checkCurrentLesson1=false;
    }
  }

  handleFillEvent(value: string): void {
    this.checkCurrentLesson1 = true;
    this._otp = value;
  }

  handleFillMEvent(value: string): void {
    this.checkCurrentLesson2 = true;
    if (this._otpId == "") {
      this.checkCurrentLesson1 = true;
    }
    this._otpmobile = value;
  }

  VerifyOtp() {
    if (this._otpmobile == "") {
      this.toastrService.error("Please fill Mobile OTP.");
      return;
    }
    if (this._otp == "") {
      this.toastrService.error("Please fill Email OTP.");
      return;
    }
    let obj: any;

    if (this._otpId != "" && this._otpMId != "") {
      obj = {
        email: this._email,
        action: "VERIFY_OTP",
        actionParams: {
          otp: this._otpmobile,
          otpId: this._otpMId,
        },
        emailActionParams: {
          otp: this._otp,
          otpId: this._otpId,
        },
      };
    } else if (this._otpMId != "") {
      obj = {
        email: this._email,
        action: "VERIFY_OTP",
        actionParams: {
          otp: this._otpmobile,
          otpId: this._otpMId,
        },
      };
    } else {
      return;
    }

    this.__VerifyOtp = this.userAuthService.verifyotpwithaction(obj).subscribe({
      next: (x: any) => {
        let res: any = x.data.processStageData.txnStateData;
        localStorage.setItem(
          "user",
          JSON.stringify(x.data.processStageData.txnStateData)
        );
        this.OTPSuccessMessage = "Otp Verified successfully.";
        if (this.userAuthService.isUserLoggedIn()) {
          
          this.userAuthService.getCurrentUser();
          this._getProfile = this.userAuthService
            .getuserByToken({
              token: res.token,
            })
            .subscribe({
              next: (x: any) => {
                let loggedin_data: any = x.data;
                this.angularFireDatabase
                  .list("Users")
                  .update(loggedin_data.userId, {
                    email: this._email,
                    name:
                      loggedin_data.firstName + " " + loggedin_data.lastName,
                    fcmKey: this.fcmKey,
                    pic: loggedin_data.profilePic,
                    type: "CUSTOMER",
                  })
                  .then(() => {
                    window.location.href = "/user";
                  })
                  .catch(() => {
                    window.location.href = "/user";
                  });
              },
              error: (err: Error) => {
              },
              complete: () => {},
            });
          return;
          /* Firebase activity */
        }

        //if (this.isUserLoggedIn()) {
          //this.getCurrentUser();
        //}
        //this.modalService.dismissAll('Registration successfully..');
        //this.userAuthService.openSaveSearchModal.next();
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
      },
    });
  }



  ResendOTP(otpId: any, verifyis: any) {
    this.checkRemainTime = false;
    this.__ResendOtp = this.userAuthService
      .resendotp({
        otpId: otpId,
      })
      .subscribe({
        next: (x: any) => {
          this.UpdateOTP(x.data, verifyis);
          this.toastrService.success("OTP Sent Successfully.");
        },
        error: (err: Error) => {
          let errRes: any;
          errRes = err;
          this.toastrService.error(errRes.error.error.clientErrorMessage);
        },
        complete: () => {
          //this.registerSubmitted = false;
        },
      });
  }



}
