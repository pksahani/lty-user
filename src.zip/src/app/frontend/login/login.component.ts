import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import {FormControl, Validators, FormGroup} from '@angular/forms';
import {FloatLabelType} from '@angular/material/form-field';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
export const environment = {
  production: false,
  recaptcha: {
      siteKey: '6LeBxCglAAAAABe3t7-yZcuQeOGw6p7NS5ZZJkds',
  },
};

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
_signInSub: any;
showPassword: boolean = false;
loginSubmitted: boolean = false;
loginSuccessMessage: string = '';
loginErrorMessage: string = '';
_isUserLoggedIn: boolean = false;
  _openLoginForm: any;
  _getAccount:any;
  _user: any = {};
loginForm = new FormGroup({
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required,
      //Validators.minLength(6)
    ]),
  });
  

  hide = true;

  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl('auto' as FloatLabelType);
  ngOnInit(): void {
    window.scrollTo(0, 0);

    if (this.isUserLoggedIn()) {
      this.getCurrentUser();
      this.router.navigate(['/user']);
    }
  }
  
  constructor(private userAuthService: UserAuthService, private router: Router, private toastrService:ToastrService){
  
  }
  
  resolved(captchaResponse: string) {
    console.log(`Resolved captcha with response: ${captchaResponse}`);
  }
  
  isUserLoggedIn(): boolean {
    let data = localStorage.getItem('user');
    
    if (data != null) {
      return this._isUserLoggedIn = true;
    }
    return this._isUserLoggedIn = false;
  }
  getCurrentUser(): any {
    let data:any = localStorage.getItem('user');
    if (data != null) {
      this._user = JSON.parse(data);
    }
    return this._user;
  }

  verifytoken(): any {
    this._getAccount = this.userAuthService.getuserDByToken().subscribe({
      next: (x: any) => {
       let res=x.data;
	 
      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        this.router.navigate(['/signin']);

      },
      complete: () => {
        
      },
    });
  }
   get rlf() { return this.loginForm.controls; }
  loginSubmit(): void {
    if (this.loginSubmitted) {
      return;
    }
localStorage.clear();
    this.loginSubmitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      alert('Login form is not valid.');
      return;
    }

    this.loginSuccessMessage = '';
    this.loginErrorMessage = '';

    let response: any;

    this._signInSub = this.userAuthService.login(
      {
        email: this.loginForm.getRawValue().email,
        password: this.loginForm.getRawValue().password
      }
    ).subscribe({
      next: (x: any) => {
    
        this.loginSubmitted = false;
        if(x.data.processStage=='PENDING_ACTION' && x.data.processStageData.txnState=='OTP_VERIFICATION_REQUIRED'){

          let mobileverify:any ='Mobile number ';
          let emailverify:any =this.loginForm.getRawValue().email;
          localStorage.setItem('verifyMotp', JSON.stringify(x.data.processStageData.txnStateData));
          localStorage.setItem('verifymobile', mobileverify);
          localStorage.setItem('verifyemail', emailverify);
          this.router.navigate(['/otpVerify']);

      }


      //   localStorage.setItem('user', JSON.stringify(x.data));
      //   this.loginSuccessMessage = 'Login successfully..';
      //   this.loginForm.reset();
      //   this.toastrService.success(this.loginSuccessMessage);
      //   if (this.isUserLoggedIn()) {
		  // if(this.getCurrentUser()){
      //    window.location.href = "/user";
		  // }
      //  }
        
        //this.modalService.dismissAll('Login successfully.');
        //this.modalService.dismissAll('Login successfully..');
        //this.userAuthService.openSaveSearchModal.next();
        //this.userAuthService.getUserWishListObs.next();

      },
      error: (err: Error) => {
        let errRes: any;
        errRes = err;
        //console.error(err)
        this.loginSubmitted = false;
       this.toastrService.error(errRes.error.error.clientErrorMessage);
      },
      complete: () => {
        this.loginSubmitted = false;
      },
    });
  }
  
}
