import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SetPasswordComponent } from './set-password/set-password.component';
import { OtpVerifyComponent } from './otp-verify/otp-verify.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        component: LoginComponent
      } , {
        path: 'signin',
        component: LoginComponent
      }, {
        path: 'signup',
        component: SignupComponent
      }, {
        path: 'setPassword',
        component: SetPasswordComponent
      }, {
        path: 'otpVerify',
        component: OtpVerifyComponent
      },  {
        path: 'forgotPassword',
        component: ForgotpasswordComponent
      },
    ]
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FrontendRoutingModule { }
