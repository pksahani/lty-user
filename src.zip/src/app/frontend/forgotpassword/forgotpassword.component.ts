import { Component,VERSION } from '@angular/core';
import { NgxOtpInputConfig } from 'ngx-otp-input';
import { Router} from '@angular/router';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import { UserAuthService } from 'src/app/_services/user-auth.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent {
  otpInputConfig: NgxOtpInputConfig = {
    otpLength: 4,
    autofocus: true,
    classList: {
      inputBox: 'my-super-box-class',
      input: 'my-super-class',
      inputFilled: 'my-super-filled-class',
      inputDisabled: 'my-super-disable-class',
      inputSuccess: 'my-super-success-class',
      inputError: 'my-super-error-class',
    },
  };
  __ForgetPass:any;
  firstFormGroup = this._formBuilder.group({
    useremail: ['', Validators.required]
  });
constructor(private _formBuilder: FormBuilder, private router:Router, private userAuthService: UserAuthService, private toastrService:ToastrService){}
  handeOtpChange(value: string[]): void {
    console.log(value);
  }

  handleFillEvent(value: string): void {
    console.log(value);
  }
  
  ngOnInit(): void {
    window.scrollTo(0, 0);
  }

  ForgetPassword(): void {
  
    if(this.firstFormGroup.getRawValue().useremail==''){

      this.toastrService.error('Please fill required field.');
      return;
    }
      this.__ForgetPass = this.userAuthService.forgetpassword(
        {
          email: this.firstFormGroup.getRawValue().useremail,
        }
      ).subscribe({
        next: (x: any) => {
        
          let emailverify:any = this.firstFormGroup.getRawValue().useremail
          localStorage.setItem('verifyotp', JSON.stringify(x.data));
          localStorage.setItem('verifyemail', emailverify);
          
          this.firstFormGroup.reset();
          this.router.navigate(['/setPassword']);
          
        },
        error: (err: Error) => {
          let errRes: any;
          errRes = err;
         
          this.toastrService.error('User Does not Exists.');
        },
        complete: () => {
         
        },
      });
    
  }

}
