export class AppConfig {
    public static get USERAPIENDPOINT(): string { return "https://identity.dev.ltytech.ch/api/ims/v1/"; }
    public static get COMMUNICATORAPIURL(): string { return "https://communicator.dev.ltytech.ch/api/communicator/v1/"; }
    public static get DOCUMENTAPIURL(): string { return "https://document-store.dev.ltytech.ch/api/document-store/v1/"; }
    public static get INSURANCEAPIURL(): string { return "https://insurance-aggregator.dev.ltytech.ch/api/insurance/v1/"; }
    public static get FILEPATHPOINT(): string { return "http://44.203.193.10/backend/uploads/"; }
	public static get errorMessage(): string { return 'Some error occurred.'; }
}
