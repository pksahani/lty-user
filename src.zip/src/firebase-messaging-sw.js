// Give the service worker access to Firebase Messaging.
// Note that you can only use Firebase Messaging here, other Firebase libraries
// are not available in the service worker.
importScripts('https://www.gstatic.com/firebasejs/9.0.2/firebase-app-compat.js'); 
importScripts('https://www.gstatic.com/firebasejs/9.0.2/firebase-messaging-compat.js');

// Initialize the Firebase app in the service worker by passing in the
// messagingSenderId.

firebase.initializeApp({
    apiKey: "AIzaSyADkb1y-3LbJymHtDfRs7waUU4WU1LsJUc",
      authDomain: "ltypartner.firebaseapp.com",
      databaseURL: "https://ltypartner-default-rtdb.firebaseio.com",
      projectId: "ltypartner",
      storageBucket: "ltypartner.appspot.com",
      messagingSenderId: "359287358840",
      appId: "1:359287358840:web:a2f6f2b56c84211f9b348d",
      measurementId: "G-YF9MG7SK5G"
});

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();

